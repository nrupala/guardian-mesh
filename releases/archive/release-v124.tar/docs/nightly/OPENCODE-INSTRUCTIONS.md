# Guardian Mesh — Nightly Build Instructions (for OpenCode and worker lanes)

This file is the single work order for Guardian Mesh development. It unifies
two sources, refreshed nightly by Wright:

- **Part A — the repo's own pending build/update list**: `specs/` (formal
  spec, architecture v2, gap analysis), `revised_project_scope.md`, the
  CHANGELOG, and gaps verified against the shipped code.
- **Part B — Guardian Mesh Spec Inputs (GMSI) from the release gate**: the
  release-gate thread is Guardian Mesh's source of specs. Every gate run
  across the fleet files what Guardian Mesh must be able to *prove* — the
  evaluation input, the ALLOW/BLOCK rule, the sealed-proof fields, the
  tamper behaviour, and the certificate-lifecycle impact.

Owner direction (2026-10-14): this pack is worked **nightly**. Wright runs
worker lanes (OpenCode primary builder; DeepSeek for bulk drafting and
first-pass generation on dev material only; Claude/OpenAI lanes for review
and hard protocol work), then **independently verifies** every lane's output
from a fresh checkout of the pushed branch. Nothing merges on a lane's own
tests. Nothing merges red. Every release carries a release-gate verdict.

## Guardrails (never violated)

1. **Honesty boundary.** Public surfaces claim only what the machinery does.
   TEE attestation, multi-node/BFT consensus, external anchoring, and
   Lean 4 verification are design, not shipped — never present them as built.
2. **Liability boundary.** A certificate warrants only the exact item tested,
   against the policy named, on the date stamped — never deployment choices.
3. **License: Apache 2.0 + Payment Rider** (owner's decision
   2026-10-16, replacing the former AGPL/Apache split). The whole
   repo — core, interface, specs — is Apache License, Version 2.0
   plus the AIMLDS Payment Rider (`LICENSE-RIDER.md`): free to use,
   modify, and self-host at any scale; offering Guardian Mesh
   verdicts/certification as a service to third parties, or issuing
   certificates under the Guardian Mesh name, requires a paid
   commercial license. New files carry the Apache-2.0 SPDX header.
   Never describe the license as unmodified Apache 2.0.
4. **Fail closed.** No answer from the daemon means BLOCK. Undecided means
   BLOCK. A check that cannot run is reported NOT RUN, never PASS.
5. **Deterministic enforcement.** No LLM in any verdict path.
6. **No secrets in the repo or in logs.** Pattern + location only.
7. Every change lands as a draft PR, full CI green, Wright-verified, then
   merged. Version bump + CHANGELOG entry + public release-log update ride
   with every release.
8. **System-level language only.** Guardian Mesh is a system-level product
   and the daemon is Rust because execution speed is a security property
   (owner's doctrine, 2026-10-14). No Python — or any slow interpreted
   language — in the product runtime: core and performance/security-
   critical components are Rust (POSIX-class system languages only: Rust,
   C, C++). The browser interface is TypeScript because that is the
   browser's native layer. Interpreted languages may appear only as
   throwaway scaffolding outside the shipped product (test harnesses,
   one-off verification scripts) and are never shipped as components.

## Part A — Work orders from the repo

### WO-1 (P0) Verify the request signature on Evaluate
The client envelope carries an ML-DSA-65 signature over
`crc32c_le_bytes || payload`, and the WebUI produces a real one — but the
daemon never verifies it. Close the authentication gap:
- Gatekeeper (or Witness step) verifies the envelope signature against the
  public key bound at Handshake time; Handshake therefore also registers the
  caller's ML-DSA-65 public key with the session.
- Missing, malformed, or non-verifying signature → `permission_denied` with
  a plain reason; the evaluation never reaches the Arbiter.
- Acceptance: unit + integration tests — valid signature evaluates;
  tampered payload, wrong key, and unsigned envelope each BLOCK; the
  existing 32-test suite stays green.

### WO-2 (P0) Enforce the Protocol Firewall rule table
`specs/GUARDIAN_MESH_FORMAL_SPEC.md` §1.4 defines PF-1…PF-18. The shipped
Sentinel enforces only the subset adapted to client envelopes (structure/
size, timestamp drift, context size, target traversal). Implement the
remainder as they apply to the Evaluate path, each with a named test:
- PF-1/PF-5 size and payload-length bounds (64 KiB envelope budget);
  PF-6 CRC32C already checked — keep and test.
- PF-12 unknown-field rejection and PF-13 nesting depth ≤ 4 for the payload.
- PF-14 nonce uniqueness: sliding window of the last 10,000 nonces per
  session; reuse → reject.
- PF-15/PF-16 timestamp windows per spec (stale > 5 s, future > 1 s) for the
  envelope timestamp, kept distinct from the existing drift counter.
- PF-17 signature format budget (ML-DSA-65 length in [2420, 3500]).
- PF-18 rate limit: 100 msg/s per external session → THROTTLE-grade reject.
- Every rejection logs step + error code into the audit trail (spec §1.4).

### WO-3 (P1) Persistent daemon signing key
The Witness/daemon signing key is currently generated per boot, so proofs
verify only against the running instance. Persist it:
- On first start, generate the ML-DSA-65 keypair into the daemon workspace
  (file permissions 0600); load it on later starts.
- Health reports the signing-key fingerprint (hash, never key material).
- Document generation, storage, backup, and rotation in the guide.
- Acceptance: restart the daemon; a proof issued before the restart still
  verifies VALID after it.

### WO-4 (P1) Audit trail read path
The Vault appends to a hash-chained audit log but exposes no read RPC, and
the panel's "View Audit Log" therefore does not exist in live mode.
- Add a read RPC returning audit entries (and chain-verification status).
- Wire the live panel's audit view to it.
- Acceptance: entries from real evaluations list in order; a hand-edited
  log line makes chain verification report the break.

### WO-5 (P1) Real THROTTLE and ESCALATE verdicts
Both verdicts exist in the protocol but no code path emits them.
- THROTTLE: PF-18 rate breaches and a policy-configurable per-session rate.
- ESCALATE: a policy list of action types/targets that require a human;
  the verdict carries the reason and the proof records the escalation.
- Acceptance: tests drive each verdict end to end; panel renders both with
  plain words.

### WO-6 (P1) Release-evidence certification (from Part B, GMSI-1)
See Part B. Spec first (certificate schema binding a gate evidence pack),
then the minimal implementation.

### WO-7 (P2) Reconcile stale scope docs with shipped reality
`revised_project_scope.md` predates the shipped system: it names a
different enclave set, says "License: MIT", and lists audit logging and
the policy engine as not implemented — all superseded. Rewrite it to the
shipped Sentinel/Gatekeeper/Witness/Arbiter/Vault design and the
Apache License 2.0 + Payment Rider licensing (2026-10-16). Remove
the duplicate
`specs/GUARDIAN_MESH_GAP_ANALYSIS (1).md` (byte-identical copy).

### WO-8 (P2) Fuzz the boundaries (hardening rule H6)
Add fuzz targets (cargo-fuzz / libFuzzer) for envelope decoding, payload
parsing, and proof verification; a nightly CI job runs them briefly.
Crashes become P0 work orders.

### WO-9 (P1) Public release log on the site
Standing fleet rule: every product keeps a public release log — changes
plus the testing record (gate verdict, what was tested, counts, journey
proof). Add a `/releases` page to the WebUI fed from the CHANGELOG and
gate records; update it as part of each release, not after.

### Designed, not yet scheduled (do not build without owner direction)
TEE attestation (SEV-SNP/TDX/Nitro), enclave-to-enclave mTLS, remote
attestation verification, multi-node consensus, external proof anchoring,
Lean 4 formal verification, Rego/OPA policy engine.

## Part C — Work orders from the Revised Specification v3.0 (2026-10-15)

`specs/GUARDIAN_MESH_REVISED_SPEC.md` is the governing target spec
(owner-approved 2026-10-15). It folds in the data-center readiness set,
the hyperscaler-aligned checkpoint catalogue (CP-01…CP-24), the
trust-boundary map with the two-confirmation rule, pluggable
authorization (PGP/GPG included), and the release gate as criteria of
record. Owner direction of 2026-10-15 supersedes the "designed, not
yet scheduled" line above for the items below (clustered verdicts,
attestation package, workload mTLS) — they are scheduled here.
Work these after Part A, in this order, one per night unless the
nightly run's judgment says otherwise:

### WO-19 (P1) Firewall session eviction + measured Health counters
Closes v0.4.0 gate findings F1/F2: call ProtocolFirewall::evict_session
on bus session expiry (or TTL-sweep), and make Health report measured
per-rule pass/fail counts instead of constants (spec EV-5 groundwork).

### WO-10 (P1) Simulate call + structured verdict reasons
Simulate/dry-run RPC running identical verdict logic, marked as
simulation in its proof (spec DC-9); every denial carries structured
rule IDs + "what would have to change" fields (DC-10).

### WO-11 (P1) Policy governance
Signed, versioned policy bundles; dual-control change path;
publication endpoint so judged agents can read current policy
(spec DC-18, DC-19, BM-6/BM-12).

### WO-12 (P1) Revocation service
Session/key/certificate revocation with a propagation bound
(default ≤ 60 s), behaviour-proven by test (spec DC-14, EV-4).

### WO-14 (P2) Boundary authenticators
SPIFFE/mTLS workload identity (AZ-3) and PGP/GPG administrator
authorization (AZ-4) plugged into the handshake as second-factor
framework (spec BM-9, §5).

### WO-13 (P2) Guardian attestation package
Signed, reproducible release builds with provenance published per
release (spec CP-19/CP-21, DC-17). Builds on the cargo-zigbuild
cross-build route recorded in the ledger.

### WO-15 (P2) Multi-tenancy
Tenant-scoped policy, keys, rate budgets, audit partitions, with
isolation behaviour-proven in tests (spec DC-15, DC-16, CP-14).
Status 2026-10-31: built, Wright-verified, gated PASS WITH
FINDINGS and merged as v0.14.0 (PR #78) — but the deploy was
ROLLED BACK at production proof (gate F6: the tenant budget
pre-empted Gatekeeper THROTTLE verdicts under burst, box E2E
PF-18). Production remained on v0.13.0. Status 2026-11-02:
COMPLETE — WO-15.1 shipped as v0.14.1 (PR #81) and deployed
the same night; production proof PF-18 PASS (100/15/0). See
the 2026-11-02 ledger entry.

### WO-15.1 (P1) Tenant-budget ordering fix (WO-15 completion)
Move the per-tenant budget check AFTER Gatekeeper evaluation:
the budget gates only requests the Gatekeeper allowed, so
THROTTLE verdicts are never converted to resource_exhausted
errors (gate F6 / GMSI-100). Acceptance: box-E2E PF-18 verdict
mix restored (excess = THROTTLE, other = 0) in Wright's
pre-merge wire proof AND on the box after deploy; WO-15's
tenant tests stay green. Then v0.14.0 (or the next patch
version) deploys with the standing attestation + certification
ceremony. Also carries WO-15 F4 if it falls out naturally
(bogus-session budget burn) — otherwise F4 stays fodder.
Status 2026-11-02: SHIPPED as v0.14.1 (PR #81, merged
b8d5d067) and deployed the same night; box-E2E PF-18 PASS
(allowed=100 throttled=15 other=0) in Wright's pre-merge
proof AND on the box after deploy; F4 proven closed
(bogus-session regression test in tree). The fix also
converted the tenant budget from a lifetime quota to a
per-window rate budget (gate F2 of the WO-15.1 gate).

### WO-16 (P2) Clustered verdicts + degraded modes
Multi-node verdict issuance per architecture v2 consensus levels;
declared fail-closed degraded modes (spec DC-1…DC-5).
Status: **v1 SHIPPED 2026-11-03 as v0.15.1** — the DC-4 declared
degraded modes + DC-5 entry/exit audit events + DC-2 issuing-node
slice (PR #84 v0.15.0 + PR #85 fix, gate PASS WITH FINDINGS —
guardian-mesh-wo16-2026-11-03). v0.15.0 was deployed and rolled back
the same night (its full-history startup chain check degraded the
daemon on the production audit archive; the fix scopes the startup
check to the live tail segment — GMSI-118). **WO-16 stays OPEN** for
the DC-1/DC-3 cluster slice (multi-node verdict issuance per
architecture v2 consensus levels — a phase-scale build, sequenced
with the cluster program, not a nightly slice).

### WO-17 (P2) Conformance suite + chaos drills
Spec-as-tests in CI: PF table, boundary rules, authorization
combinations, tenant isolation, tamper behaviour; kill-mid-verdict
chaos cases (spec RG-7, RG-8).
Status: **v1 SHIPPED 2026-11-04 as v0.16.0** — the named
conformance suite (13 `conformance_` tests: PF table per implemented
rule, payload/signature/timestamp boundaries, §5 authorization
matrix, DC-16 tenant isolation, EV-2 proof-tamper table) plus the
in-process RG-8 chaos slice (restart-fails-closed, corrupt-log
detection, revoked-session stop), a dedicated CI step
(`cargo test conformance_`), and docs/CONFORMANCE.md (PR #88, gate
PASS WITH FINDINGS — guardian-mesh-wo17-2026-11-04). Multi-node
chaos is NOT built (no cluster exists — WO-16 DC-1/DC-3 open);
CM-8 non-catalogued probes remain WO-27. **WO-17 stays OPEN** for
those extensions.

### WO-18 (P3) Deployment matrix
Sidecar form (DP-3), edge profile (DP-6), CLI (CC-4), MCP server
surface (CC-5) — one profile per run, in that order.
Status 2026-11-06: **profile 1 (DP-3 sidecar form) SHIPPED as
v0.17.0** — PR #91 merged 3dd6aeb9. The 2026-11-05 gate was
BLOCKED on the never-built image; the 2026-11-06 retry built
the shipped Dockerfile unmodified (podman on Wright's VM) and
behaviour-proved the container end to end: Health SERVING with
PF counters 18/18 and build identity 0.17.0@9bda0b22, signed
Evaluate ALLOW + proof VALID, restart on the same volume kept
the fingerprint/node_id and the pre-restart proof verifies
VALID, daemon uid 10001, no secret in the image env. Gate PASS
WITH FINDINGS (guardian-mesh-wo18-retry-2026-11-06): F1 PF-18
local-environmental (standing; PASS on the production box at
this deploy, 100/15/0); F2 base-image tags float (low,
standing); kubectl dry-run NOT RUN (no cluster context).
Production v0.17.0 live 2026-11-06: build 0.17.0@3dd6aeb9,
binary sha256 a2374b93... == installed == attested,
attestation VALID signer == pin dd2cf1a3..., self-cert
cert-20261107-000046 ACTIVE, box E2E 15/16 (sole miss the
standing stale Health-fields harness check), box dist asset
== merged build == Pages asset, site 302. RC soak to
2026-11-13. WO-18 stays OPEN; the next run takes profile 2
(DP-6 edge profile).


Status 2026-11-07: **profile 2 (DP-6 edge profile) SHIPPED as
v0.18.0** — PR #94 merged 6107c602. deploy/edge/ carries the
systemd form (MemoryMax=256M / CPUQuota=50% / TasksMax=64
ceilings, loopback bind default, hardening) and the compose
form (mem_limit 256m / cpus 0.5), an env example with the
handshake secret comment-only, and docs/EDGE.md. The honest
core: ceilings are enforced by systemd/the container runtime —
the daemon has NO ceiling setting in config.rs — and no
edge-to-core sync is built (BM-7 design). Gate PASS WITH
FINDINGS (guardian-mesh-wo18-edge-2026-11-07): offline verdict
operation behaviour-proven in a loopback-only network
namespace (Health SERVING, Evaluate ALLOW, proof VALID, all
egress unreachable); measured footprint RSS 5.8–10.2 MB, peak
10.6 MB (>24x headroom under the 256M ceiling); container
proof on the shipped image (fingerprint stable across a
same-volume re-run, pre-restart proof VALID). F3: ceiling
enforcement NOT RUN in the verifying sandbox (nested cgroup
controllers not delegated) — GMSI-122 filed. Production
v0.18.0 live 2026-11-07: build 0.18.0@6107c602, binary sha256
3083e08d... == installed == attested, attestation VALID
signer == pin dd2cf1a3..., self-cert cert-20261108-000047
ACTIVE, box E2E 15/16 (PF-18 PASS 100/15/0), box dist asset
== merged build == Pages asset, site 302. RC soak to
2026-11-14. WO-18 stays OPEN; the next run takes profile 3
(CC-4 CLI).

Status 2026-11-08: **profile 3 (CC-4 CLI) SHIPPED as v0.19.0**
— PR #97 merged f25cfd51c69af370b551faeb64b1d58d1653fe6b. The
`gm` operator CLI (guardian-meshd/src/bin/gm.rs, no new
dependencies) provides health / handshake / evaluate (real +
--simulate) / verify / audit over gRPC: JSON on stdout, exit
0 success / 1 refusal-or-invalid / 2 usage-transport-session
errors with stderr-only diagnostics, session file 0600 holding
the session key + signing seed as bearer secrets (never
printed), proof envelopes saved as hex JSON. Gate PASS WITH
FINDINGS (guardian-mesh-wo18-cli-2026-11-08): F1 (High, FIXED
in the Wright carry) the lane's gm did not compile — build.rs
generated server-only stubs; fixed with build_client(true) +
the sealed_envelope encode idiom; F2 (Low, open) evaluate
stdout does not name the proof file written; F3 base-image
tags float (low, standing). Production v0.19.0 live
2026-11-08: build 0.19.0@f25cfd51, binary sha256 e280e5c8...
== installed == attested, attestation VALID signer == pin
dd2cf1a3..., self-cert cert-20261109-000048 ACTIVE, box E2E
15/16 (PF-18 PASS 100/15/0), **gm itself proven against the
production daemon on the box** (health SERVING, handshake,
evaluate TOOL_CALL -> ALLOW, verify VALID; its audit read
reports the standing F4 production-history interleave — first
break at entry 557, the documented 2026-10-26/27 segment,
live tail clean by design since v0.15.1), box dist asset ==
merged build == Pages asset, site 302. RC soak to
2026-11-15. WO-18 stays OPEN; the next run takes profile 4
(CC-5 MCP server surface) — the last WO-18 profile.

Status 2026-11-09: **profile 4 (CC-5 MCP server surface)
SHIPPED as v0.20.0 — WO-18 COMPLETE.** PR #100 merged
6f107e4f55ef882414c74ff53a50b4a019d26cb5. The `gm-mcp` binary
(guardian-meshd/src/bin/gm-mcp.rs, no new dependencies) is a
stdio MCP server (newline-delimited JSON-RPC 2.0) and an
ordinary client of the existing daemon: four tools
(guardian_health / guardian_evaluate / guardian_verify /
guardian_audit), in-memory lazy handshake sessions with TTL
and one re-handshake/retry (session key + seed never printed,
logged or written), fail-closed evaluate (no answer =
isError stating no verdict was issued; treat as BLOCK; the
server keeps serving). docs/MCP.md documents the surface and
its non-claims; docs/CLI.md's two "MCP not built" sentences
updated. **GMSI-124 absorbed for the CLI + MCP surfaces**:
scripts/smoke.sh + scripts/smoke_mcp.py are in-repo (9 legs;
9/9 in Wright's verification). Gate PASS WITH FINDINGS
(guardian-mesh-wo18-mcp-2026-11-09): F1 (Low, process; FIXED
in-run) the laptop lane's git push failed — the fresh clone
carries no GitHub credentials — so Wright carried the push
via bundle + git-data API with the pushed tree proven
identical to the lane's commit tree (41ce166c, modes
included); F2 base-image tags float (low, standing). NO code
findings — the lane's code compiled and passed as written.
Production v0.20.0 live 2026-11-09: build 0.20.0@6f107e4f,
binary sha256 0503ce5d... == installed == attested,
attestation VALID signer == pin dd2cf1a3..., self-cert
cert-20261110-000049 ACTIVE, box E2E 15/16 (PF-18 PASS
100/15/0), **gm-mcp itself proven against the production
daemon on the box** (live legs 6/6 via the shipped smoke
driver: initialize, tools/list, health, evaluate ALLOW,
verify VALID, audit), box dist asset == merged build ==
Pages asset, site 302. RC soak to 2026-11-16. **WO-18 is
CLOSED — all four profiles shipped (DP-3 v0.17.0, DP-6
v0.18.0, CC-4 v0.19.0, CC-5 v0.20.0).**

## Part D — Work orders from the v3.1 amendment (2026-10-15)

Owner-directed the same day as v3.0: the product boundary charter
(spec §0.5), Doctrine 0 (only desired paths exist), complete
mediation (unguarded path = vulnerability), securing the guardian,
and the product-completeness set. Spec §§11–13 + map §9A.

### WO-30 (P1) Threat model of record
Author `specs/THREAT_MODEL.md` (SG-1): named adversaries, assets,
countermeasure mapping to spec requirement IDs. Maintained per
release thereafter; docs-only, Wright lane acceptable.

### WO-22 (P1) Secure by default
Production posture MUST refuse the built-in default handshake
secret (SG-4); add the posture doctor (config scan naming insecure
settings). Behaviour-prove: default secret + production posture =
refusal to start.

### WO-20 (P1) Complete-mediation core
Execution tokens bound to the sealed action hash + tool-side
checker (CM-2); credential escrow mode (CM-1); resource-side
identity lockdown hooks (CM-3).

### WO-27 (P2) Mediation conformance
Direct-access (skip-the-guardian) probe + non-catalogued
invocation suite as gate MUSTs (CM-8); extends WO-17.

### WO-21 (P2) Coverage + reconciliation
Coverage inventory + drift alarms (CM-6), receipt reconciliation
with bypass alarms (CM-5), coverage statement in certificates
(CM-7). After WO-6 (certificate schema).

### WO-23 (P2) External witnessing
Periodic anchoring of the audit chain head to an operator-external
witness, with verification (SG-5).

### WO-24 (P2) Payload data protection
Secret/PII detection in payloads, audit redaction by default,
exfiltration block rules (PC-1).

### WO-25 (P2) Tool/model supply chain
Tool manifest pinning + change detection; MODEL_LOAD signed
provenance verification (PC-2).

### WO-26 (P2) Admin RBAC + agent registry
Role model on the guardian's own surfaces (PC-6); agent
enrollment/owner/risk-tier lifecycle (PC-5).

### WO-28 (P3) Delegation attenuation
Subset-only delegated capability tokens, chain recorded in the
proof (PC-3).

### WO-29 (P3) Compliance exports + alerting
CP-catalogue auditor evidence packs, SIEM formats, OTel export
(PC-7); anomaly alerting hooks (PC-10).

### WO-31 (P2) Standards alignment upkeep
From the 2026-10-16 standards compliance review
(`specs/STANDARDS_COMPLIANCE_REVIEW.md`): add a terminology annex
to the revised specification adopting ISO/IEC 22989 terms (AI
agent, AI system, human oversight, verification vs validation,
trustworthiness characteristics) with Guardian Mesh's product
terms defined against them; add 22989 + the SC 42 family to the
§3 standards spine. Keep the compliance review refreshed per
release (RG-3). Docs-only; Wright lane acceptable.

### Compliance development plan items (2026-10-16)
From `specs/COMPLIANCE_DEVELOPMENT_PLAN.md` — build the missing
compliances as evidence-producing machinery, never as prose:

### WO-32 (P1) AI risk register + process
`specs/RISK_REGISTER.md` per ISO/IEC 23894: risks scored, owned,
tied to THREAT_MODEL entries and their mitigations; reviewed at
every release gate run, review recorded in the gate verdict.
After WO-30. Docs-only; Wright lane acceptable.

### WO-33 (P2) NIST AI RMF profile
Profile doc mapping Govern/Map/Measure/Manage to real Guardian
Mesh mechanisms only (gate, risk register, policy governance);
zero aspirational mappings. After WO-32. Docs-only.

### WO-35 (P2) Validated-module crypto path (FIPS 140-3)
Cryptographic provider boundary in the daemon + PKCS#11 provider
so keys can live in an HSM/KMS; documented validated-module
deployment profile (validation is the module vendor's, cited,
never implied ours). Acceptance: daemon runs end-to-end with
signing keys in an external PKCS#11 token (software token in
test). After WO-3. Laptop lane.

### WO-36 (P3) EU AI Act deployer pack
Customer-facing mapping from the WO-29 evidence export to
deployer obligations (Art. 9/12/14/15), generated from a real
export — framed "supports deployer obligations", never
"compliant product". After WO-29.

Note on WO-29: the compliance plan sets its acceptance bar —
every CP-01…CP-24 checkpoint emits a machine-readable result per
deployment (PASS/FAIL/N/A/NOT RUN + evidence pointer), exportable
mapped to NIST CSF 2.0 + SP 800-53 + ISO 27001 Annex A themes.

### WO-37 (P1) Touchpoint wiring program (dogfood coverage)
Owner's directive 2026-10-16: Guardian Mesh connected at every
touchpoint. The map of record is the goal file
`touchpoint-wiring-map.md` (T1 release gate, T2 publishing
pipeline, T3 Conduit, T4 fleet repos, T5 nightly lane, T6
oc-bridge, T7 MyMilo loop, T8 GM's own surfaces). Wire one
touchpoint per run in map order: verdict before the action, proof
after it, coverage entry updated. A touchpoint counts as wired
only when its proof verifies offline (CM-6/CM-7 discipline
applied to our own fleet first).

## Part B — Spec inputs from the release gate (GMSI)

Guardian Mesh evolves with the gate. Each item below states what Guardian
Mesh must be able to prove. A capability becomes a gate MUST only after it
is behaviour-proven here (valid → VALID, tampered → NOT VALID, no answer →
BLOCK).

- **GMSI-1 — Certify a release evidence pack.** Input: product, version,
  gate verdict, evidence-pack hash, test counts. Rule: ALLOW (certificate
  issues) only when the pack hash matches the presented evidence and the
  verdict is recorded; BLOCK otherwise. Proof fields: product, version,
  verdict, evidence hash, policy (gate version), timestamp, issuer.
  Lifecycle: issuing a certificate for a newer release supersedes the old;
  a gate verdict of BLOCKED revokes. → implemented by WO-6.
- **GMSI-2 — Hash-verifiable handoff of one-time secrets.** Born of a real
  escape (reviewer keys corrupted in transcription). Any key or secret
  Guardian Mesh issues or carries must ship with a fingerprint the holder
  can check (SHA-256 of the value), and verification tooling must compare
  the *copy presented*, not the copy at mint. → lands with WO-3
  (fingerprint in Health) and WO-6 (fingerprint field in certificates).
- **GMSI-3 — Independent re-verification.** Proofs must verify on a second
  lane that never built them (the Arch evidence-bench doctrine). Until the
  bench exists, VerifyProof from a separate client/process is the stand-in
  — keep proofs self-contained (all fields needed to verify travel inside
  the sealed envelope).
- **GMSI-4 — Auth-attack resistance is evaluated, not assumed.** Login and
  session surfaces must prove rate limiting and lockout actually fire.
  For Guardian Mesh itself: Handshake attempt throttling and session
  abuse limits → covered by WO-2 (PF-18) and WO-5 (THROTTLE).
- **GMSI-5 — History is part of the artifact.** A secret ever committed
  stays in git history; certification of a repository must state whether
  history was scanned, not only the working tree. Certificate schema
  (WO-6) carries a `scope` field: `working-tree` | `full-history`.

The founding set above (GMSI-1…5) dates to 2026-10-14. GMSI-6…47 were
filed by the WO-1/WO-2 gate runs and the release gate's 2026-10-15
fleet re-gate (13 product packs: RA/devinfo, codetopo, Conduit
filings, Conduit DCR, dogear, FareSutra, KalaBodha, LetsAskIt,
Linktary, MyKey, site tier, thinkwithfinance, Verdict). Repeats are
consolidated into one canonical item with every filing named;
onsmartgrid and the Conduit Router re-run filed none. These inputs
queue behind the Part A work orders: they land as proof fields in
WO-6's certificate schema and as standing probe sets in the gate,
and none becomes a gate MUST until behaviour-proven here.

- **GMSI-6 — The gate scanner must detect inline Rust tests.**
  WO-1 and WO-2 both drew a false scanner BLOCKED ("no test suite")
  on a repo whose tests are Rust `#[test]` functions. Gate tooling
  input, filed from both runs: the scanner learns inline-test
  detection so the class cannot false-block a third release.
- **GMSI-7 — Evidence packs bind measured firewall outcomes.**
  WO-6 certificates carry the daemon's measured per-rule PF
  pass/fail counts, never constants (WO-2 gate finding F2). The
  measurement itself is WO-19 (Health counters + session eviction).
  CLOSED 2026-11-10 (WO-19 completion, v0.21.0): issuance now
  snapshots the live counters into the sealed certificate body
  (canonical `RULE:passed=<n>,failed=<n>` string; null when
  nothing measured — never constants). Proven on the wire twice:
  local proof 18/18 and the production certificate's sealed
  pf_outcomes equal to the production Health counters exactly.
- **GMSI-8 — Transport floor proof.** Filed seven times in one day
  (aimlds M1, Conduit filings F-R1, codetopo F-R1, FareSutra,
  LetsAskIt N1, KalaBodha, thinkwithfinance M3): GM must prove, per
  host and from outside, that plain HTTP refuses or redirects, HSTS
  is served, the TLS floor holds, and a baseline header set exists —
  on every origin, workers.dev and second origins included. Header
  inventories read off HTTPS responses alone missed this class
  repeatedly; the probe set includes an http:// fetch of every host.
- **GMSI-9 — Deployed == gated, continuously.** (aimlds worker-drift
  sentinel + source-of-record census; Conduit filings currency
  markers; dogear cross-surface version census.) Deployed artifacts
  are hash/marker-compared against the repo of record on a cadence;
  where hashes are unavailable from outside, behaviour markers (a
  response only current code produces) are the standing check.
  Every deployment maps to a repo + commit; unmapped deployments
  are findings by construction.
- **GMSI-10 — A claimed safeguard must be proven armed.** (aimlds
  gate-activation probe; Linktary provisioned-safeguard sentinel.)
  Every safeguard whose code says "activates when configured" gets
  a production probe proving it is ON — key/discovery endpoints
  fetched on a cadence, an empty published key set on a product
  claiming signed artifacts is an alert. Code review cannot see
  config; only the probe can.
- **GMSI-11 — Public-claims / copy-vs-state differ.** (KalaBodha
  public-claims sentinel; Conduit filings cross-surface copy;
  codetopo copy-vs-code drift incl. executing the published
  quickstart against the current CLI; site-tier claims-vs-state;
  thinkwithfinance claims-vs-record; dogear claims-vs-config.)
  Load-bearing public claims — what is live, who the processor is,
  licence, price, feature availability, "no tracking" — are diffed
  against the live surface, the served bytes, the zone config, and
  the repo of record at every gate and on a cadence.
- **GMSI-12 — Release-record completeness.** (codetopo C-P1;
  thinkwithfinance M4; Linktary release-log monitor.) GM diffs every
  product's public release record against the gate register: an
  entry must carry changes + testing record + gate verdict + GM
  verifier record, and the log's freshness is monitored against
  deploys. A release whose notes carry no verdict word is
  detectable mechanically — C-P1 escaped because nobody diffed.
- **GMSI-13 — Payment-state truth.** (codetopo built-but-not-live;
  LetsAskIt payment-mode proof; site-tier checkout-liveness.) GM
  distinguishes *code exists* / *deployed* / *purchasable* for every
  payment surface, proves a rail's mode (test vs live) from the
  deployed surface + config-in-VC, and flags present-tense sales
  copy that outruns it. A checkout configured with a zero or
  placeholder vendor id, or sitting on a closed rail, is detectable
  from served bytes alone and pages the owner.
- **GMSI-14 — Rate-limit proof that survives reality.** (Conduit
  filings egress rotation; Verdict F1 eventual consistency.) Per-IP
  caps are unprovable from a rotating egress: GM needs a
  fixed-egress probe lane (or a counter-state test hook) so cap
  proofs are live, not code-read — and must state and prove the
  enforcement bound a counter actually delivers under eventual
  consistency.
- **GMSI-15 — Soft-404, catch-all, and well-known correctness.**
  (Conduit filings F-R2; dogear catch-all detector; LetsAskIt
  well-known.) Unknown paths and the /.well-known/* space are
  probed against the product's declared documents, never assumed:
  a 200 + homepage (or HTML shell) on an unknown path hides missing
  privacy/changelog/security pages behind green statuses.
- **GMSI-16 — Auth-surface proof runs on the deployed server.**
  (Conduit DCR 1–3, the 2026-10-15 escape class.) Validation rules
  on registration/auth endpoints are behaviour-proven on the
  DEPLOYED server at every auth-surface release — fragment,
  userinfo, non-loopback http, and loopback redirect variants
  probed with requests + responses filed; the served consent
  screen's content is proven (redirect hostname + unverified-client
  warning present); token-binding negative probes (code reuse,
  wrong PKCE verifier, mismatched redirect_uri) must all fail live
  before an OAuth release may call itself tested. The 2026-10-14
  gate shipped a rate cap on this endpoint without ever probing its
  validation rules.
- **GMSI-17 — Silent-failure sentinel.** (dogear F1.) Surfaces whose
  core act depends on a runtime capability (browser speech voices
  is the filed case) are probed from a capability-less vantage, and
  a user-visible fallback message is required. The defect was
  invisible to every code-level check.
- **GMSI-18 — Deploy attestation coverage.** (dogear.) Every
  production deployment id maps to a ledger certificate; an
  unattested production deployment is a mechanical management
  signal, not a judgment call.
- **GMSI-19 — Exposure proofs, probed from the internet side.**
  (FareSutra H1/H2.) GM enumerates unauthenticated WRITE endpoints
  and "private to this deployment" data stores on public URLs, and
  flags any public GET returning accumulated operator/user activity
  (search history, watches, ledgers), classifying what it discloses.
  The single-tenant assumption is probed, never read off the code
  comment that asserts it.
- **GMSI-20 — Amplification accounting.** (FareSutra.) Features that
  convert anonymous reads into recurring operator spend
  (auto-watch → daily re-search is the filed shape) carry a cost
  proof: entries minted per anonymous request × recheck cost ×
  retention, plus cap-eviction effects on legitimate entries.
- **GMSI-21 — One product, one verdict.** (FareSutra H3.) When two
  engines emit judgments, GM diffs them on identical inputs in the
  served response; a contradiction (BUY NOW vs WAIT on the same
  item) is a finding.
- **GMSI-22 — Fallback truth per route.** (FareSutra M2.) A
  fixture/demo fallback is verified against the REQUESTED route,
  not merely labelled in the response — an honest warning over the
  wrong city's deals is still a wrong answer.
- **GMSI-23 — Artifact-link liveness.** (FareSutra M6.) Links
  presented as verifiable proof (certificates) are re-fetched after
  an isolate-recycle interval; in-memory registries fail this by
  construction.
- **GMSI-24 — Audit-chain independent verification.** (KalaBodha.)
  A hash-chained audit log is re-computed independently from its
  public endpoint as a standing GM proof for any product claiming
  tamper-evidence (done by hand there for entries 1–4). For
  Guardian Mesh itself this lands with WO-4's audit read path.
- **GMSI-25 — Public-metadata exposure census.** (KalaBodha
  Medium 4 class.) For transparency endpoints, what an
  unauthenticated seq/id walk actually discloses per tenant is
  enumerated and measured, so "public by design" is a measured
  quantity, not a posture.
- **GMSI-26 — Fingerprint-binding probe.** (KalaBodha; extends
  GMSI-2.) For envelope stores, a probe stores under a mismatched
  registered fingerprint and records accept/reject; GM holds the
  standing probe-key pattern for it (the probe needs an
  operator-minted key).
- **GMSI-27 — Returning-user data rights.** (LetsAskIt F4/N2, an
  escape that survived in-session-only testing twice.) GM's probe
  identity returns in a NEW session with persisted state
  (cookie/localStorage) and re-tests read/delete; deletion proven
  in-session is not deletion proven.
- **GMSI-28 — Origin parity.** (LetsAskIt.) Any origin serving the
  same worker is exposure: GM inventories every origin and probes
  each at parity; the parity itself needs a standing proof.
- **GMSI-29 — Subprocessor differ.** (Linktary.) Third-party origins
  extracted from served pages (fonts/CDN/analytics) are diffed
  against the privacy page's declared subprocessor list; drift is
  an alert.
- **GMSI-30 — SSRF probe set, reusable.** (Linktary spelling
  battery; Verdict SSRF class.) For any feature fetching a
  user-supplied URL: integer/octal/hex IPv4, IPv6 tunnelled forms,
  metadata hosts, and private ranges must all be refused before
  fetch — proven as a battery, not spot-checked.
- **GMSI-31 — Data-minimisation proofs.** (Verdict 2 + 6.) A
  share/summary token must provably contain no source content, and
  a channel reply (the email channel is the filed case) must
  contain no raw source content beyond the derived verdict
  summary — proven by rendering inspection, not by code reading.
- **GMSI-32 — Signed-token tamper proof.** (Verdict 4; extends
  GMSI-1.) A signed verdict/certificate token must fail
  verification after ANY payload mutation — proven by forgery
  probes (mutated payload + stale signature reads NOT VALID, never
  partially verified).
- **GMSI-33 — Connector-bound parity.** (Verdict 5.) A connector
  endpoint (MCP is the filed case) enforces the same free-tier /
  rate bound as the web surface it mirrors; the bound is proven on
  the connector, not inferred from shared code.
- **GMSI-34 — Encrypted-file tamper battery.** (MyKey, passed 9/9 by
  hand there.) Nine mutations — bitflip per blob class, cross-entry
  blob swap, header/KDF downgrade, version downgrade, truncation —
  all must reject. GM runs this battery against any encrypted-file
  product and diffs the outcomes.
- **GMSI-35 — Dependency-ceiling detector.** (MyKey M1.) Auditors
  report vulnerable versions; nobody flags a pin whose upper bound
  excludes *every* patched release, which makes the vuln
  unfixable-by-construction. GM diffs pin ranges against
  fix-version sets.
- **GMSI-36 — Version-label integrity.** (MyKey F7; Linktary
  version-coherence.) One version string names exactly one code
  state across tag, main, and shipped artifacts; /health vs
  service-descriptor vs package/tag coherence is checked per
  product with a drift alarm.
- **GMSI-37 — Claim-vs-binary permission diff.** (MyKey.) A
  capability claim ("makes no network calls") is diffed against the
  shipped binary's permission manifest. Filed as PROVEN aligned
  there — keep the check; it is cheap and decisive.
- **GMSI-38 — Bootstrap-trust asymmetry.** (MyKey F9.) When two
  import paths protect the same asset, their fresh-device trust
  requirements are diffed; the weaker one is a finding even when
  each is defensible alone.
- **GMSI-39 — Download-chain pinning.** (MyKey F4.) Binaries and
  their checksums served from one mutable source are a single point
  of compromise: GM requires at least one out-of-band pinned value
  per shipped artifact and flags branch-tip download URLs.
- **GMSI-40 — Advertised-endpoint liveness.** (site-tier DNS
  sentinel.) Hosts/paths advertised in well-known / llms.txt /
  discovery docs are continuously resolved + probed; a dead
  advertised API host or an HTML-serving keys URL is mechanically
  detectable drift.
- **GMSI-41 — Policy-behind-form census.** (site-tier.) Live POST
  routes are enumerated fleet-wide and each form-hosting page is
  checked for a linked privacy policy; three of five properties in
  the filed run collected PII with no policy.
- **GMSI-42 — Attribution-line verifier.** (site-tier.) The footer
  attribution line is fetched on every public surface and its link
  targets + referral code verified against the standing rule (it
  was absent on the flagship and stripped on AxiomCode in the
  filed run).
- **GMSI-43 — Integrity-enrolment census.** (site-tier.) Every live
  customer host appears in the site-integrity baselines; an
  unenrolled live host is the gap this census catches mechanically.
- **GMSI-44 — Liveness beyond reachability.** (thinkwithfinance
  M1/M2.) A publisher/scheduled job whose last-run age exceeds ~2×
  its cadence alerts, and N consecutive scheduled-run failures
  alert — the filed site was HTTP-200 and dead for 5 days, its
  filler failing 7 straight days unnoticed. Reachability
  monitoring is structurally blind to this class.
- **GMSI-45 — Doctrine-source monitor.** (aimlds H1.) A scheduled
  sample of served output asserts the declared provenance/source
  equals the doctrine registry's production source; a silent
  fallback to a development-only source is a finding, never a
  default.
- **GMSI-46 — Paid-surface probe.** (aimlds.) An unauthenticated
  request to every endpoint the product copy calls paid/gated
  expects 401 — run at every gate and weekly in the sweep.
- **GMSI-47 — Capability-token storage.** (codetopo F-R3.) Bearer
  tokens stored as lookup keys are hashed at rest by default; GM's
  store inspection flags any table whose key column is itself a
  live capability.

GMSI-48…52 were filed by the release gate's 2026-10-17 independent
re-gate of Verdict (pack: release-gate-runs/verdict-regate-2026-10-17;
verdict BLOCKED on F-R1, with the v1.2.2 fix-batch addendum the same
evening). They queue behind the Part A work orders exactly as
GMSI-6…47 do, and none becomes a gate MUST until behaviour-proven
here.

- **GMSI-48 — Served-script parse proof.** (Verdict re-gate F-R1;
  the verdict.md item 7 there.) GM must be able to prove a served
  page's scripts PARSE — extract every script from every served
  page and parse it byte-exact; a green API must never again
  certify a dead page. (Third fleet occurrence of the dead-page
  class; also Gate 1's served-script parse + deployed==tree proof.)
- **GMSI-49 — SSRF literal-spelling + resolution posture.** (Verdict
  re-gate item 8.) GM's SSRF proof must span the full literal
  spelling space (IPv6 loopback/ULA/link-local/v4-mapped in both
  spellings, bracketed forms) and must state each product's
  resolution-based (DNS→private) posture explicitly:
  guard-covered, platform-covered, or uncovered.
- **GMSI-50 — Judgment differential battery.** (Verdict re-gate
  item 9.) For verdict products, GM must carry a JUDGMENT
  DIFFERENTIAL battery: direction pairs (payment vs prize, demand
  vs receipt), brand placement (subdomain label / hyphen label /
  subdomain-of-brand / path / punycode), cross-surface consistency,
  and calibration bounds (single weak flag ceiling;
  canonical-script floor). The fixed owner-case regression set
  from the Verdict v1.2.1 escape is this battery's first case set.
- **GMSI-51 — Concurrent fresh-identity rate proof.** (Verdict
  re-gate item 10.) GM must prove a rate bound from a FRESH
  identity under CONCURRENCY, not only sequentially from a warm
  identity.
- **GMSI-52 — Pattern-coverage canaries.** (Verdict re-gate
  item 11.) Canonical scam scripts (ransom note, advance-fee,
  prize lure) in their most common phrasings, including
  apostrophe/contraction variants — a one-word spelling variant
  must not flip a verdict class.

GMSI-54…67 were filed by the release gate's 2026-10-19 billing
sweep and adjudication runs (packs: release-gate-runs/
linktary-billing-2026-10-19, mykey-billing-2026-10-19,
sovereign-billing-2026-10-19, twf-pro-2026-10-19,
codetopo-2026-10-19, codetopo-2026-10-19-delta-email, and
verdict-v130-adjudication-2026-10-19). GMSI-53 was filed by the
WO-5 gate the same day and is recorded in that ledger entry.
They queue behind the Part A work orders exactly as GMSI-6…52
do, and none becomes a gate MUST until behaviour-proven here.

- **GMSI-54 — Money-path config-layer proof.** (Linktary billing
  gate; confirmed by the TWF Pro gate and the Sovereign Core
  inventory MUST.) Money-path operability is proven at the
  CONFIG layer, not inferred from unauthenticated probes: every
  money batch's probe set includes (a) a secret-name inventory
  of the production worker (names only) against the code's
  required/accepted secret list, and (b) an authenticated
  negative-shape probe (bogus session → provider-shaped error,
  never a config 503). An armed-but-unprovisioned code path is
  a defect class of its own.
- **GMSI-55 — Duplicate-delivery / replay-safety probe.**
  (MyKey billing gate.) Every webhook consumer carries a spec'd
  duplicate-delivery probe: the same verified event delivered
  twice must change state at most once.
- **GMSI-56 — Test/live credential separation invariant.**
  (Sovereign Core billing gate, CRITICAL F-SC-1.) A production
  verifier's accepted-secret set is exactly {its own live
  secret}; test proofs run on separate test deployments, never
  production. GM must be able to prove that separation.
- **GMSI-57 — Cross-product mint probe.** (Sovereign Core
  billing gate.) Issuance handlers must bind the event to the
  product's own price/product (and to completed payment) before
  minting; a spec'd cross-product mint probe belongs in the
  money-batch battery wherever one payment account serves many
  products.
- **GMSI-58 — Buy-entry smoke first.** (TWF Pro billing gate.)
  The Subscribe/checkout route must reach the provider; this
  smoke runs FIRST in every money batch — a dead front door
  makes the deeper battery moot.
- **GMSI-59 — Ack-on-error check.** (TWF Pro billing gate.)
  Every webhook handler is probed so a post-signature failure
  must not ack 2xx.
- **GMSI-60 — Claim-prefill escaped-reflection proof.**
  (codetopo gate.) Any buyer-facing form rendering a
  redirect-carried value must prove escaped-only reflection by
  a live probe, not only by unit test.
- **GMSI-61 — Stale-timestamp webhook delivery probe.**
  (codetopo gate.) A stale-timestamp delivery probe (outside
  the bridge's freshness tolerance) belongs in the standard
  webhook battery for every billing bridge.
- **GMSI-62 — Concurrent-distinct-events send-once probe.**
  (codetopo delta-email gate.) "Sent exactly once" proofs in
  the fleet are sequential; GM should issue a
  concurrent-distinct-events probe for any send-once side
  channel, so the race window is measured, not reasoned about.
- **GMSI-63 — Config-family lint.** (codetopo delta-email
  gate.) Half-configured integration families must fail loudly
  at startup; the residual shape (encryption-off plus
  credentials present) is a mechanical config-lint case for
  every env-configured integration.
- **GMSI-64 — Assertion-message hygiene.** (codetopo
  delta-email gate.) No format-interpolation of
  credential-bearing content in test failure messages, fixtures
  included — a greppable scanner class.
- **GMSI-65 — Stable-egress vantage for rate-bound probes.**
  (Verdict v1.3.0 adjudication.) Rate-bound probes require a
  stable-egress vantage; spec a fixed-egress probe node so
  per-IP counters can be falsified honestly.
- **GMSI-66 — Fleet-controlled redirector.** (Verdict v1.3.0
  adjudication.) A fleet-controlled redirector is recurring
  gate infrastructure (the SRF-REDIRECT battery), not a
  per-product improvisation.
- **GMSI-67 — Health-endpoint methods as declared surface.**
  (Verdict v1.3.0 adjudication, F-V130-1.) Declared-method
  inventories treat health endpoints' methods as declared
  surface in every product contract.
- **GMSI-68 — Mixed-traffic chain proof.** (WO-6 gate, this
  run.) Any work order that adds a new audit-log writer or
  event type must prove the chain under MIXED traffic (existing
  writers + the new writer interleaved on one daemon, verified
  through ReadAuditLog). Single-writer chain state is an
  invariant: two chain-writer instances over one log is a
  defect class of its own (WO-6 F4, fixed in round 2).
- **GMSI-69 — Chain integrity under concurrency.** (WO-6
  post-deploy production proof, this run.) The hash chain must
  verify after CONCURRENT verdict traffic: one 115-request
  burst against v0.8.0 produced 32 consecutive duplicate chain
  hashes and a verification break at position 2, because
  seal() reads and updates the last chain hash under separate
  short locks and concurrent writers interleave on the same
  predecessor. The chain append must be atomic per entry
  (the predecessor read, digest, persist, and predecessor
  update as one critical section) for every writer, verdicts
  and certificate events alike. Production history carries
  burst-race breaks from position 557 (first sealed by
  v0.7.0's THROTTLE bursts). Filed as WO-6.1 (P1, next run,
  ahead of WO-7); a concurrent-burst chain proof is its
  acceptance test.
- **GMSI-70 — Parity differential for fact-products.** (codetopo
  0.6.0 gate, 2026-10-20.) Playbook §7's consistency leg,
  generalised: for products whose output is measurements rather
  than verdicts, Guardian Mesh must be able to prove a standing
  cross-surface equality corpus — the same input presented to
  every surface the product exposes (CLI / HTTP / MCP), with
  byte-equal structured answers — as the analogue of the
  judgment-differential corpus.
- **GMSI-71 — Test-context resolution before a secret can
  block.** (codetopo 0.6.0 gate, 2026-10-20; the gate scanner's
  sixth context miss of this class.) A certification input that
  reports a secret in code must state whether the hit's module
  context was resolved (e.g. inside a `#[cfg(test)]` fixture
  module) before the hit can block issuance; a pattern hit whose
  context was never read is a lead, not a finding.
- **GMSI-72 — Vulnerability-data freshness.** (codetopo 0.6.0
  gate, 2026-10-20.) Both RUSTSEC advisories in that gate
  postdated the product's previous gate by days. Dependency-
  vulnerability data presented at certification must be pulled
  fresh at that gate — never inherited from a prior run's pack —
  and the evidence must state the pull date.
- **GMSI-73 — Owed-probe obligations ride the certificate
  record.** (codetopo 0.6.0 gate, 2026-10-20.) Where a gate
  defers attacker-view probes because the surface is not yet
  deployed, the deferral must be carried as a named owed-probe
  obligation (the routes and the probe set) attached to the
  release record, discharged by a delta gate at deploy — never
  as an unowned NOT RUN line.
- **GMSI-74 — Concurrency proofs must be synchronised or
  graded.** (WO-6.1 gate, 2026-10-20.) An un-synchronized small
  burst passes probabilistically on racy code: Wright's
  16-thread × 8 in-process repro against the pre-fix vault
  failed once (126/128 entries persisted) and passed once
  against the same binary, while the barrier-synchronized
  32-thread version failed deterministically. Any concurrency
  acceptance proof (chain integrity, send-once, rate limits)
  must release its writers simultaneously (barrier or
  equivalent) or be run N times with every run reported — one
  green run of an un-synchronized burst is not evidence.
- **GMSI-75 — Test counts must name their invocation root.**
  (WO-7 gate, 2026-10-21.) A suite run from a crate subdirectory
  and from the workspace root can legitimately differ (the WO-7
  lane ran `cargo test` inside `guardian-meshd/` and got 79 lib
  tests; the workspace-root invocation — CI's, and Wright's
  verification — runs 80). A release record's counts are evidence
  only when they name the invocation; the canonical invocation
  is the one CI uses (workspace root). A lane reporting counts
  from any other root — and especially "correcting" previously
  verified counts from one — is a finding, not an update. Third
  lane count slip of the class (WO-6, WO-6.1 F1, WO-7 F1).
- **GMSI-76 — Pack drift watch.** (DogEar v1.2.0 gate,
  2026-10-22.) Content served from an operator bucket must be
  provably equal to its pinned manifest on a schedule, not only
  at upload: Guardian Mesh must be able to prove per-file hash
  equality between the served bucket objects and the pin of
  record (the pack-hosting route class).
- **GMSI-77 — Price-totality probe.** (DogEar v1.2.0 gate,
  2026-10-22.) A price change must be provably total across
  served bytes: Guardian Mesh must be able to prove that every
  served page's price text equals the configuration constant
  of record, with zero occurrences of a superseded price.
- **GMSI-78 — Seam-activation watch.** (DogEar v1.2.0 gate,
  2026-10-22.) A verification seam that honestly answers
  not-verified while a credential is absent must alert if it
  still answers not-verified after that credential is
  provisioned: Guardian Mesh must be able to prove a seam's
  activation state against its provisioning state.
- **GMSI-79 — Pairing integrity.** (DogEar v1.2.0 gate,
  2026-10-22.) Where a native shell depends on a served
  companion asset, Guardian Mesh must be able to prove the
  served asset's bytes equal the gated bytes of record — the
  pair staying in sync is a standing proof, not a deploy-time
  check.
- **GMSI-80 — Certified-shell identity.** (DogEar v1.4.0
  beta.4 gate, 2026-10-22.) A client-side cache name that
  nothing mechanically bumps is a silent stale-shell channel:
  Guardian Mesh must be able to prove the shell a client runs
  is the shell that was certified (served cache string vs
  certified bundle) as a standing probe, not a release-time
  grep.
- **GMSI-81 — Capability-tier proof.** (DogEar v1.4.0 beta.4
  gate, 2026-10-22.) A capability offered at a tier must be
  provable loadable/runnable on a reference device class for
  that tier: Guardian Mesh must carry the tier matrix as a
  re-runnable proof — offered implies proven, never merely
  listed.
- **GMSI-82 — Unbuilt test infrastructure is not a
  capability.** (WO-8 gate, 2026-10-22.) A fuzz (or any
  test-harness) work order closes only with a build + brief-run
  proof of the harness itself on its home surface, executed by
  the verifying lane: the WO-8 lane's package could not build in
  three independent ways (missing cargo-fuzz package metadata,
  an undeclared crate dependency, a missing trait import), its
  nightly workflow invoked cargo-fuzz from a directory where it
  cannot run, and its proof target's input layout made the real
  verification path unreachable — while reporting the targets as
  delivered. A lane's claim that targets exist is not evidence
  they compile or run.
- **GMSI-83 — A published release-status claim must name
  its status artifact.** (WO-9 gate, 2026-10-23.) The
  release log's per-release status (Released vs Release
  candidate) was inferred from CHANGELOG narrative and was
  wrong for four releases (v0.8.0–v0.8.3 marked "Released"
  while still RELEASE CANDIDATES in soak); the status of
  record lived in the RC register. Guardian Mesh
  certificates and public status surfaces must bind every
  lifecycle/status field to the artifact that is its
  source of truth (register/ledger), name that artifact
  in the record, and treat a status published without a
  named source as a finding — the GMSI-2 discipline (the
  copy presented, not the copy at mint) applied to status
  claims.
- **GMSI-84 — A fix outside the build path is a silent
  no-op ship.** (DogEar v1.2.0 beta.5 gate, 2026-10-24.) A fix
  that lands outside the path the build actually compiles was
  exercised in review and then shipped as bytes that never
  contained it (case F-B5-1). Guardian Mesh must be able to
  prove "the bytes CI built contain the fix the exercise
  exercised" — path + hash attestation of the named fix
  files against the exercise record — as a standing probe.
  A fix claim without a build-path attestation is a finding.
- **GMSI-85 — State divergence after restore must be
  provable.** (DogEar v1.1.0 final gate, 2026-10-24.) After a
  forced process death + restore, the restored surface's
  page / core / session state diverged silently (case
  F-B6-1, carried as an accepted RC risk). Guardian Mesh must
  be able to prove page/core/session agreement after a
  death + restore cycle — or catch the divergence
  mechanically and name the disagreeing layer — as a
  standing probe. A restore that merely resumes is not
  evidence the restored state agrees.
- **GMSI-86 — A scanner candidate's context labels must be
  proven against the source before it can block.** (codetopo
  v0.7.0 gate, 2026-10-25.) The release-gate scanner reported
  a Rust `#[test]` fixture plaintext as a secret candidate
  labelled `in_test: false` and blocked on it — the GMSI-6
  family on a new leg: test-suite detection was taught, but
  secret-candidate context labelling was not. Guardian Mesh
  must be able to prove a scanner's candidate labels
  (in-test / in-fixture / in-example) against the actual
  source context before a candidate blocks a gate; a label
  asserted without a source read is a finding.
- **GMSI-87 — A privacy-doc check must state its scope and
  accept the published policy location.** (codetopo v0.7.0
  gate, 2026-10-25.) The scanner's privacy-policy check
  passes/fails on repo files only, without stating that
  scope, and accepts no evidence of a policy published at a
  site route or a README section — so its verdict reflects
  the filing cabinet, not the product. Guardian Mesh
  certificates must bind a privacy-evidence claim to its
  scope (repo files | published location) and to the
  location checked, and treat an unscoped PASS/FAIL as a
  finding.
- **GMSI-88 — A selling surface's legal pages are a live,
  pre-sale proof.** (Sanity Check legal-pages gate,
  2026-10-25.) That product passed its 2026-10-23 gate with
  no /privacy or /terms pages at all; the gap was caught
  post-release by the daily asset-compliance check. Any
  surface that sells (checkout, licence sale, subscription)
  must present live /privacy and /terms naming the legal
  entity in the body BEFORE first sale — proven on the live
  surface, never from source files. Guardian Mesh must be
  able to issue that proof per selling surface; the gate
  catches it pre-release, compliance only confirms it
  post-release.
- **GMSI-89 — Generated-artifact completeness.** (WO-10
  gate, 2026-10-25.) When a service definition changes,
  EVERY generated artifact must be diffed against it —
  message types AND the client stub — and the proof is a
  clean-tree build (`npm ci` from nothing), never the
  builder's incremental tree. Founding case: WO-10's lane
  hand-updated the message file but not the client file —
  the new RPC was missing from the client and, the new
  method sitting at service index 1, seven existing client
  method indices silently pointed at the wrong RPCs —
  while the lane reported its build green (Wright's clean
  build failed TS2339). Guardian Mesh must be able to
  prove a shipped client stub's method table equals the
  service definition of record.
- **GMSI-90 — A paid deliverable's rendering is part of
  the product.** (Sanity Check report-formats gate,
  2026-10-26.) That gate's flagship deliverable — the
  customer report — had its code paths checked while the
  rendered artifact itself, in every offered format, went
  ungenerated and unread pre-release; the gap was caught
  by the Director reading a customer report, not by any
  automated check. Guardian Mesh certificates must be
  able to bind a deliverable-rendering claim: the flagship
  artifact itself, generated in EVERY format the surface
  offers and read back, with the formats enumerated in
  the evidence — a code-path PASS without the artifact
  read-back is a finding, not a proof.

- **GMSI-91 — A generated file under @ts-nocheck
  defeats the type checker's completeness proof.**
  (Guardian Mesh WO-11 gate, 2026-10-26.) The lane's
  hand-updated generated TS message file carried the
  seven new policy message INTERFACES and the three
  new service methods but NO protobuf-ts MessageType
  classes for them, and AuditProof's MessageType
  lacked its new field — yet the WebUI build and lint
  were green, because the file is @ts-nocheck and
  Rollup treats the undefined class identifiers as
  external globals; the shipped bundle would have
  thrown ReferenceError at module import, and TS
  wire clients silently dropped the new proof field
  on decode. Client-stub completeness must be proven
  BY EXECUTION — import the built module, or drive
  every method of the table — never by a green build
  alone. This is GMSI-89's class, second occurrence.

- **GMSI-92 — Revocation-effect proofs must cover
  the negative space.** (Guardian Mesh WO-12 gate,
  2026-10-27.) A revocation is proven in three
  separate legs: EFFECT — every capability the
  revoked credential had is re-attempted and
  refused (a revoked session's Evaluate denied; a
  revoked key's Handshake refused); NON-EFFECT — an
  unrelated credential is shown still working
  (revocation is surgical, not a outage); and
  DURABILITY — the revocation is shown surviving a
  restart from its persisted record. Any one leg
  alone is not a revocation proof. Founding case:
  the WO-12 wire proof (36/36 through the shipped
  TS client) ran all three legs for sessions and
  keys, and effect + durability for certificates.

- **GMSI-93 — A lane build counts as BUILT only when
  the full test suite compiles and passes from the
  workspace root.** (Guardian Mesh WO-14 gate,
  2026-10-28.) The lane's commit did not compile its
  bin test suite (81 errors: a dropped import used by
  40 test sites; 41 pre-existing initializers never
  updated for the new proto fields), all 16 of its
  new unit tests failed, and its WebUI caller did not
  compile — while its result file reported the work
  order complete. `cargo test` from the workspace
  root (not `cargo build`, not `--lib`) is the
  minimum lane evidence; a commit whose tests do not
  compile or pass is reported NOT BUILT with the
  failing output attached. The work-order checklist
  (UI surface, release-log entry, README/CHANGELOG
  accuracy against the shipped proto) is part of
  "built", and lane result files stay untracked.

- **GMSI-94 — Hand-rolled calendar conversions are
  a defect class: validity-window code must
  round-trip known epoch vectors in both
  directions.** (Guardian Mesh WO-14 gate,
  2026-10-28.) The shipped civil-to-unix conversion
  was ≈93 days off for 2023-11-14; the unit tests
  passed against themselves because the test encoder
  shared the same wrong math's inverse image. Any
  date conversion feeding a security decision
  (certificate validity, token expiry, audit
  timestamps) carries at least one externally-known
  epoch vector per code path, asserted in both
  directions (encode and decode).

- **GMSI-95 — Authenticator proofs separate effect,
  non-target survival, and refusal naming.**
  (Guardian Mesh WO-14 gate, 2026-10-28.) A
  second-factor mechanism is proven in three legs:
  EFFECT — the attested/enrolled path works end to
  end (attested session evaluates; enrolled admin's
  change applies); NON-TARGET SURVIVAL — principals
  and sessions outside the factor behave exactly as
  before it existed; REFUSAL NAMING — every refusal
  states the missing or invalid confirmation
  (BM-11). A happy-path-only proof does not evidence
  a boundary mechanism. This mirrors GMSI-92's
  three-leg rule for revocations.

- **GMSI-96 — A shipped script is evidence only after
  its author lane has executed it end to end.**
  (Guardian Mesh WO-13 gate, 2026-10-29.) A lane's
  deliverable script or tool is NOT RUN until the lane
  itself has run it once, successfully, on the record;
  source that merely reads correctly is a claim, not
  evidence. (Founding case: WO-13's
  reproducible-build.sh shipped with two fatal defects
  — a relative path broken by its own `cd`, and a
  rustc flag passed to cargo — and no recorded run;
  Wright's carry fixed both and the double build then
  produced identical hashes.)
- **GMSI-97 — A platform block on one suite is
  NOT RUN for that suite, named with its platform.**
  (Guardian Mesh WO-13 gate, 2026-10-29.) When an
  OS/AV/EDR block prevents a test suite from executing
  (founding case: Windows Defender os error 225 on a
  fresh Rust bin test executable), the lane reports
  that suite NOT RUN with the blocker named — never
  folded into a neighbouring suite's pass, and never
  silently dropped from the counts a release records.
- **GMSI-98 — A proto field addition is diffed against
  every shipped client call site before done.**
  (Guardian Mesh WO-15 gate, 2026-10-31.) When a work
  order adds a field to a wire message, every shipped
  client that constructs that message (TS gmClient,
  Rust, Python) is diffed and updated in the same
  change — a required-field addition that breaks a
  client's build is a work-order defect, found in
  WO-14 (F4) and again in WO-15 (F2).
- **GMSI-99 — Partitioned audit appends on EVERY
  Ok return path.** (Guardian Mesh WO-15 gate,
  2026-10-31.) When audit is partitioned by any key
  (tenant here), the append must be proven on every
  Ok verdict return path — final, policy-deny,
  throttle, simulation-block. A partition that
  undercounts BLOCK/THROTTLE verdicts is a silent
  evidence gap.
- **GMSI-100 — Production harness contracts are
  part of the shipped spec.** (Guardian Mesh WO-15
  deploy, 2026-11-01.) The box E2E's observable
  contracts (e.g. the PF-18 burst verdict mix:
  excess returns THROTTLE verdicts, never errors)
  bind every work order. A change to limiter
  ordering or verdict routing re-proves those
  contracts in Wright's pre-merge behaviour proof —
  never discovers them at deploy. (Founding case:
  WO-15's tenant budget ran before the Gatekeeper
  and converted burst excess to resource_exhausted;
  deploy rolled back, gate F6.)
- **GMSI-101 — Scanner secret candidates are
  classified by code context before they block.**
  (codetopo 0.8.0 gate, 2026-11-02; third consecutive
  occurrence, fourth at the release-PR gate.) A
  `generic-secret-assign` hit inside a Rust
  `#[cfg(test)]` / `#[test]` fixture is emitted as a
  lead, not a blocker — the scanner classifies test
  context before raising a secret candidate.
- **GMSI-102 — Call-resolution fidelity is a tracked
  measurement, not an anecdote.** (codetopo 0.8.0
  gate, 2026-11-02.) A probe reports per-language
  call-resolution rates (resolved vs stubbed) over
  pinned corpora at each gate, so a builder change
  is measured before/after.
- **GMSI-103 — Dependency-advisory freshness between
  releases.** (codetopo 0.8.0 gate, 2026-11-02.) The
  weekly fleet sweep re-runs the OSV pass against
  shipped lockfiles, not only at release time — an
  advisory that post-dates a gate is caught by the
  sweep, not by the next build's gate alone.
- **GMSI-104 — Cross-surface value parity.**
  (codetopo 0.9.0 gate, 2026-11-02.) For any
  measurement product, a value crossing a
  serialization boundary (CLI / HTTP / MCP) must
  round-trip bit-identically; the mesh proves parity
  across every surface the product exposes.
  (Founding case: serde_json's default float parser,
  1 ULP across the HTTP boundary.)
- **GMSI-105 — Absence integrity.** (codetopo 0.9.0
  gate, 2026-11-02.) A non-converged or over-ceiling
  answer is an absence with a reason — never a zero
  or a partial result presented as an answer.
- **GMSI-106 — A release workflow that builds an
  artifact without running the test suite is
  provable from the workflow file.** (Nov-3 Play
  apps gate, 2026-11-02; founding case: all four
  vault children.) The mesh checks workflow steps
  mechanically before a release artifact counts.
- **GMSI-107 — Manifest-vs-declared permission
  diff.** (Nov-3 Play apps gate, 2026-11-02.) The
  shipped artifact's merged-manifest permissions
  are diffed automatically against the pack's
  declared set.
- **GMSI-108 — Framework-version advisory watch at
  gate time.** (Nov-3 Play apps gate, 2026-11-02.)
  Framework versions in lockfiles (Capacitor and
  peers) are checked against GHSA ranges at gate
  time; the boundary arithmetic is never done by
  hand at the gate.
- **GMSI-109 — Bundle-vs-privacy disclosure diff.**
  (Nov-3 Play apps gate, 2026-11-02.) Remote
  references inside a shipped bundle are diffed
  against the product's privacy disclosures; an
  undisclosed remote reference is a finding.
- **GMSI-110 — Workflow-literal secret watch,
  history-aware.** (Nov-3 Play apps gate,
  2026-11-02.) Credentials as literals in workflow
  files are proven absent in the working tree AND
  in history — tree scans alone miss the history
  half.
- **GMSI-111 — Channel-string sweep for money
  surfaces.** (Nov-3 Play apps gate, 2026-11-02.) A
  store-channel bundle must contain no
  direct-checkout URL strings for channels that
  forbid them; proven mechanically, not by hand.

- **GMSI-112 — Wall-clock-window contracts are
  tested by controlling the window or the clock.**
  (Guardian Mesh WO-15.1 gate, 2026-11-02.) A test of a
  rate limiter, budget window, or freshness window must
  not race real time: sequential pre-signed envelopes
  aged past the PF-15 5 s window before reaching the
  rate window, and a concurrent variant raced the 1 s
  window under full-suite CPU contention — the same
  test passed and failed on identical code. Unit tests
  prove ordering deterministically (configure the window
  or the rate so the outcome cannot race); scale and
  volume contracts belong to the production harness,
  run against a release binary on a quiet surface.

- **GMSI-113 — A provider's raw error never crosses an
  API boundary.** (Conduit filings checkout error-leak
  gate, 2026-11-03.) Any outbound-call error path must
  answer in the product's own words, with provider
  detail confined to server logs. Guardian Mesh must be
  able to prove, for an evaluation that depends on an
  external call, that the caller-visible response
  contains no provider response body or provider error
  string, while the sealed proof still records that an
  external failure occurred and which class it was.

- **GMSI-114 — Price-to-plan integrity is a provable
  money-surface invariant.** (codetopo tiered-pricing
  gate GM-1, 2026-11-03.) For any recorded subscription
  or payment event, the plan stamped on the issued key
  or certificate equals the plan of the price actually
  billed. Guardian Mesh must be able to issue and
  verify a proof binding billed price, resolved plan,
  and issued credential together, so a mismatch is
  detectable after the fact, not only at issuance.

- **GMSI-115 — One-off gate probes must graduate into
  the repo suite.** (codetopo tiered-pricing gate GM-2,
  2026-11-03.) A coverage gap closed by a one-off gate
  probe escapes again unless the probe becomes a
  standing test in the product's own suite. Guardian
  Mesh certificates for a release should be able to
  name which gate-probe classes are covered by standing
  tests in the gated tree, so probe graduation is
  checkable rather than remembered.

- **GMSI-116 — Tier-switch enforcement freshness.**
  (codetopo tiered-pricing gate GM-3, 2026-11-03.) Once
  a higher tier's limits exist, no live key may enforce
  a lower tier than its entitlement record shows, or
  the exception must be named in the proof. Guardian
  Mesh must be able to prove the enforcement tier a
  credential is actually under at evaluation time, not
  only the tier it was issued with.

- **Backbone note.** The gate's Kali (offensive) and Arch (crypto /
  isolation / evidence benches) backbones are gate infrastructure, not
  repo code; their NOT RUN status is recorded by the gate thread. The
  repo-side contribution is WO-8's fuzz targets, which the Arch isolation
  bench will consume.
- **GMSI-117 — Pre-authentication degraded/BLOCK verdicts are a
  policy surface of their own.** A fail-closed mode that seals
  evaluation before authentication (WO-16 DC-4, like WO-15 DC-15)
  answers unauthenticated requesters with verdict semantics; that
  is acceptable only as a declared, bounded behaviour: the sealed
  verdict names no policy internals beyond the declared rule id,
  and the gate for any such mode states the pre-auth behaviour
  explicitly instead of discovering it in review.
- **GMSI-118 — Startup/deploy integrity gates must be proven
  against the production data they will judge.** A check correct
  on young or synthetic data and failing on real history is an
  escape class: before an integrity, migration, or verification
  gate ships, it is exercised against a copy of the actual
  production dataset (audit log, store, manifest set), and the
  evidence names that dataset's size and shape. (WO-16 v0.15.0
  verified the full persisted audit chain at startup and bricked
  production on its own 2026-10-26/27 concurrent-writer interleave
  segment; v0.15.1 scopes the startup check to the live tail and
  was proven against the real 2,120-entry log before redeploy.)

- **GMSI-119 — External-state snapshot provenance is provable
  from the receipt stream.** When a verdict depends on fetched
  external state (a provider's model catalog, a price list, a
  revocation feed), the receipt must bind which snapshot decided
  it: the endpoint it came from, when it was fetched, and for
  which key owner — so a later probe can compare the receipt's
  subject against the deciding snapshot and catch a stale or
  poisoned snapshot changing what the system refuses or allows.
  (Conduit Router v1.3.0 gate, 2026-11-04: per-owner model-list
  snapshots became the truth for availability, and a caller-named
  model absent from the caller's snapshot is refused — catalog
  freshness is now a live dependency of routing correctness.)

- **GMSI-120 — An escalated verdict must have a provable
  resolution path, or be declared terminal.** A conformance suite
  must be able to prove that an approval, by the role the spec
  names, resolves an ESCALATE to a final verdict within a stated
  bound — or the specification must declare ESCALATE
  terminal-by-design for that action class, in which case the
  suite pins the declaration. (WO-17 gate F3, 2026-11-04: the
  daemon has no per-request escalation approval path; dual-control
  policy approval does not resolve an individual escalated
  evaluation, and installing the escalation list via an approved
  policy change still yields ESCALATE.)

- **GMSI-121 — Repo↔live drift proof, continuous per deploy
  path.** Guardian Mesh must be able to prove, on a cadence and
  not only at release time, that the deployed artifact for each
  deploy path equals the repo head that path deploys from —
  bytes or a behaviour marker only current code produces, per
  GMSI-9's discipline — and alert the day the two diverge, in
  either direction (live ahead of repo is drift, not freshness).
  (onsmartgrid consolidation gate, 2026-11-05: production ran
  12 days ahead of its repo, Oct 24–Nov 5, with the divergence
  invisible to every watcher; the batch that closed it was a
  repo-integrity gate, not a product release. The same gate's
  page-proof gap is a repeat filing of GMSI-48 and its
  money-surface signed-cell note carries no new input.)


- **GMSI-122 — Ceiling-enforcement venue.** A resource-ceiling
  claim (DP-6 class) can only be behaviour-proven where cgroup
  controllers are actually delegated to the proving venue; a
  nested sandbox that cannot enforce a ceiling must instead
  (a) measure the real footprint under load, (b) state the
  headroom against the shipped ceiling, and (c) name enforcement
  NOT RUN with the venue defect as the reason — never let a
  green suite stand in for an enforcement proof. (WO-18 edge
  gate F3, 2026-11-07: the verifying sandbox's nested userns
  delegates no memory/pids controllers — crun refuses every
  limit flag — while the daemon's measured peak was 10.6 MB
  against the shipped 256M ceiling.) **CLOSED 2026-11-12** by
  the first bench-backed gate run (guardian-mesh-bench-2026-11-12,
  Leg 4): enforcement proven on the production box at the shipped
  256M cap (cgroup memory.max read back exactly; twin hog unit
  OOM-killed at the same cap; daemon peak ~9.1 MB under 97,090
  requests) — the venue rule above stands for future claims.

- **GMSI-123 — Counter-only auth-outcome metrics.** Where a
  surface deliberately logs nothing about authentication
  outcomes (a no-logging discipline that must not be weakened),
  Guardian Mesh must be able to prove the aggregate outcome
  counts — expired vs used vs invalid, counter-only, carrying
  no identifier, token fragment, or address — so a
  delivery-latency problem can be distinguished from token
  misuse from evidence, not inference. The counts themselves
  must not become a state oracle: they are aggregate and
  operator-facing only, never per-token or per-mailbox.
  (Linktary v0.4.1 magic-link gate, 2026-11-08: the auth module
  logs nothing by design, so an expired-link failure today
  leaves no privacy-preserving aggregate trace; the gate
  accepted this input as filed — not built there, not a
  condition of that release.)

- **GMSI-124 — Operator-surface smoke proof.** Every shipped
  client surface (CLI, MCP server, panel actions) must carry a
  repeatable smoke proof a gate run can execute against a live
  daemon: connect, health, handshake, one ALLOW evaluate, proof
  verify, one audit read, plus the negative legs the surface
  owns (no-session, tampered proof, unreachable endpoint), each
  with its expected exit/result. A surface that ships without
  its smoke proof is incomplete by definition. (WO-18 CLI gate,
  2026-11-08: the CC-4 CLI's proof was necessarily ad-hoc —
  gm-proof.sh in the run dir — because no in-repo proof exists
  for any surface; CC-5's MCP surface should land with its
  proof in-repo. Absorbing this input means the suite exists
  in-repo and a gate run executes it against the release build;
  until then it stands as filed input. Rules touched: CC-4/CC-5
  acceptance; RG-7 — the smoke proof is the surface's
  conformance slice.)

GMSI-125…133 were filed by the release gate's 2026-11-09 Conduit
rounds (packs: release-gate-runs/conduit-buyerfix-2026-11-09,
conduit-buyerfix2-2026-11-09, conduit-buyerfix3-2026-11-09,
conduit-credits-2026-11-09). They queue behind the Part A work
orders exactly as GMSI-6…124 do, and none becomes a gate MUST
until behaviour-proven here.

- **GMSI-125 — Wedged dashboard reads must be observable.**
  (Conduit buyerfix gate, 2026-11-09.) A dashboard read that can
  wedge must be *observable*: the page should surface (and
  ideally report) refresh failures rather than only wording
  them — in the filed escape the only witness to the class was
  the owner's own walk. GM must be able to prove a wedged read
  becomes a visible, reported failure on the surface itself.
- **GMSI-126 — Every primary card read settles with words.**
  (Conduit buyerfix gate, 2026-11-09; the round's F-3.) The
  single-shot dashboard calls left after the purchase-path fix
  are the same wedge class on non-money cards: GM should be
  able to prove "every primary card read settles with words"
  across the whole page, not only the purchase path.
- **GMSI-127 — No key material in post-sign-in dashboard reads.**
  (Conduit buyerfix round-2 gate, 2026-11-09.) A served page's
  credential choice is a release surface: GM should be able to
  prove, for a stall-model network, that post-sign-in dashboard
  reads carry no key material (the round-2 regression shape).
- **GMSI-128 — Observability ON for live-walk-accepted surfaces.**
  (Conduit buyerfix round-2 gate, 2026-11-09; the round's F-3.)
  Production Workers Logs observability must be ON for any
  surface whose acceptance evidence is a live walk — filed as a
  gate checklist candidate: a buyer-leg escape was diagnosable
  only because the code carried its own evidence; the log
  window itself was dark.
- **GMSI-129 — Liveness of awaited shared state.** (Conduit
  buyerfix round-3 gate, 2026-11-09.) Any initialization
  promise awaited on a request path must carry (a) a deadline,
  (b) a degraded path that serves from the durable source, and
  (c) a regression that wedges the source and proves requests
  still complete. Probe candidate: wedge the registry store in
  a staging isolate and assert authenticated reads complete
  inside the deadline + one store read.
- **GMSI-130 — Metered balance == signed ledger sum.** (Conduit
  credits gate, 2026-11-09.) GM must be able to prove, for any
  metered key: balance == signed ledger sum, at any instant,
  from outside the gateway process.
- **GMSI-131 — Refusal means zero provider egress.** (Conduit
  credits gate, 2026-11-09.) GM must be able to prove a
  `blocked_credits` refusal produced zero provider egress
  (correlate the audit chain with provider-call telemetry).
- **GMSI-132 — Webhook/grant correspondence.** (Conduit credits
  gate, 2026-11-09.) GM must detect a Stripe webhook delivered
  but ungranted (event seen at the edge, no ledger grant within
  N minutes) and a grant with no corresponding webhook
  (impossible by construction — prove it stays so).
- **GMSI-133 — Top-up attempts cap watch.** (Conduit credits
  gate, 2026-11-09.) GM must watch the top-up path: attempts
  per key per day never exceed the configured cap, including
  failure storms.

- **GMSI-134 — Panel-action smoke proof.** (WO-18 MCP gate,
  2026-11-09.) The last unabsorbed surface of GMSI-124: the
  WebUI panel's live actions (handshake, evaluate, verify,
  audit view) still have no in-repo repeatable smoke a gate
  run can execute; the CLI and MCP surfaces now carry theirs
  (scripts/smoke.sh, 9/9 in the v0.20.0 gate). Absorbing this
  input means the panel legs join the same in-repo suite,
  driven against the served panel in a real browser.

- **GMSI-135 — Repo-root Python client stubs are stale.**
  (WO-19 completion gate, 2026-11-10.) The repo-root
  `guardian_mesh_pb2.py` predates the WO-19 (v0.8.5) Health
  fields — it carries no `protocol_firewall_rule_counters`
  (0 references vs 5 in the WebUI's generated TS), so any
  Python wire client built on it silently lacks the measured
  counters this release exists to bind. Absorbing this input
  means the root stubs are regenerated from
  `guardian-meshd/proto/guardian_mesh.proto` (or generated in
  CI, or the stale file is removed and the generation route
  documented). The daemon, gm, gm-mcp and WebUI clients all
  generate from the current proto and are unaffected.

GMSI-136…142 were filed by the release gate's 2026-11-10 rounds
(packs: release-gate-runs/codetopo-v091-2026-11-10 and
release-gate-runs/gate-agent-v010-2026-11-09, the latter's
FIX-RECORD-2026-11-10 filing none). They queue behind the Part A
work orders exactly as GMSI-6…135 do, and none becomes a gate
MUST until behaviour-proven here.

- **GMSI-136 — Commit-delta composition proof.** (Codetopo
  v0.9.1 gate, 2026-11-10; the pack's GMSI-1.) A gate brief's
  "data-only commit" characterisation of a main-branch delta was
  wrong by four commits including a kernel change. GM should be
  able to prove, for any gated release, the exact commit-delta
  composition between the release commit and current main (code
  vs data classified per commit), so a stale brief can never
  silently widen a gate's scope. Evaluation input: release SHA +
  main SHA; rule: ALLOW only when every delta commit is
  classified and the pack names each; tampered proof → NOT
  VALID.
- **GMSI-137 — Secret-finding context verdict.** (Codetopo
  v0.9.1 gate, 2026-11-10; the pack's GMSI-2, reinforced by its
  GMSI-5.) The scanner's single secrets hit was a test-string
  false lead whose resolution required reading the file's own
  design comment — and the gate runner then mechanically counted
  the already-adjudicated lead as a BLOCKER because it consumes
  only the scanner's count. Spec: secret findings carry a
  *context verdict* field (test-scope / literal-credential /
  derived-at-runtime, with a pointer to the adjudicating pack)
  that a verifier — and the runner — can re-check mechanically,
  so a resolved lead stays resolved across both machine passes
  instead of re-blocking every later gate.
- **GMSI-138 — Repo-hygiene proof.** (Codetopo v0.9.1 gate,
  2026-11-10; the pack's GMSI-3.) Medium hygiene drift
  accumulates outside artifacts (workflow pinning alerts, a
  dismissal comment overwritten by a probe). Spec: a
  repo-hygiene proof (open medium alerts enumerated, dismissal
  comments non-placeholder) as a standing input to future gates
  of the repo under examination.
- **GMSI-139 — Deployed==tree proof scope for embedded pages.**
  (Codetopo v0.9.1 gate, 2026-11-10; the pack's GMSI-4.) The
  DEPLOY-TREE-DIFF check's file-extension set cannot see pages
  embedded as string literals in compiled sources (a Rust `.rs`
  string here; the class is any non-script-extension source), so
  it reported drift where deployed == tree in fact. Spec: the
  deployed==tree proof indexes distinctive lines from ALL text
  source files, or the check records "served script originates
  outside the scanned set" as NOT RUN rather than FAIL when the
  served lines match a non-scanned source file verbatim.
- **GMSI-140 — Identity binding for repository-less releases.**
  (Gate Agent v0.1.0 gate, 2026-11-09; the pack's GMSI-GA-1.) A
  product can reach a fully armed gate yet be repository-less —
  its identity pinnable only by a gate-side content manifest.
  GM should be able to prove, for any gated release, the
  identity binding between the verdict and the artefact
  (manifest hash ↔ tree ↔ deployed bytes), and a gate brief
  should be able to require "repo + tag OR filed content pin" as
  a named precondition class, so the absence of version control
  is a graded finding by construction rather than a gate lane's
  discovery.
- **GMSI-141 — Money-path proof: two separate legs.** (Gate
  Agent v0.1.0 gate, 2026-11-09; the pack's GMSI-GA-2.) The
  billing webhook's credit grant did not reconcile the paid
  amount against the price of the service granted. Spec: for
  any webhook that converts a payment event into service value,
  the proof must show amount/price reconciliation and replay
  idempotence as **two separate legs**; a gate that proves only
  one leg must not be able to report the money path as covered.
  (The filed run proved idempotence behaviourally and found
  reconciliation absent by read.)
- **GMSI-142 — Contract-truth proof for negative
  declarations.** (Gate Agent v0.1.0 gate, 2026-11-09; the
  pack's GMSI-GA-3.) A control's absence can be honestly
  **disclosed** (the contract declares nothing) yet still
  require a human read of the code to distinguish "undeclared"
  from "unenforced". Spec: when a contract omits a control, the
  machinery should be able to prove the omission is also true
  in code (no enforcement exists to contradict the declaration,
  and no enforcement exists that the declaration hides), so
  disclosed absences grade mechanically as findings of the
  right class instead of consuming agent adjudication each
  cycle.

- **GMSI-143 — Spec↔release status reconciliation.** (WO-30
  gate, 2026-11-10.) The revised specification's
  per-requirement status labels are maintained by hand and lag
  shipped releases — seven confirmed instances at v0.22.0
  (DP-3, CC-4, CC-5, DC-4/DC-5, DC-9, DC-14, DC-18/DC-19 all
  labelled [TARGET] in the spec while their slices are shipped
  and gate-proven). GM should be able to prove, per release,
  that every requirement ID's spec status matches the release
  record (shipped-in-version X / partial-with-named-slice /
  target), so a stale label surfaces as a gate finding, not a
  reader's discovery. The WO-30 threat model follows the
  release record where the two disagree and notes the lag
  where a row depends on it; reconciling the labels
  themselves is a documentation follow-up this input tracks.
- **GMSI-144 — Static discovery proof for open MCP surfaces.**
  (Conduit Router v1.5.0 gate, 2026-11-11.) A server that opens
  MCP discovery to anonymous callers (initialize / ping /
  tools/list) must serve a fully static tools/list carrying no
  per-key state — no usage, no vault material, no caller-specific
  annotation can leak through discovery. GM should be able to
  prove, for any server that opens discovery, that the anonymous
  tools/list output is byte-identical across callers and across
  keys: two anonymous calls and one keyed call produce the same
  bytes; any difference is a BLOCK-grade finding (state is
  leaking through a surface that must be static). The Conduit
  Router's own tools/list is static by construction (a constant);
  this input asks GM to make that property provable, not assumed.
- **GMSI-145 — Negative-start proof (refusal as a behaviour).**
  (WO-22 gate, 2026-11-11.) WO-22's acceptance is a refusal: the
  daemon must NOT start under an insecure posture. GM should be
  able to prove refusal-to-start as a first-class behaviour —
  the process exits non-zero, the FATAL line names the insecure
  setting, and nothing listens on the configured port — for any
  guarded service whose secure-by-default claim rests on a
  startup gate. The proof is of an absence (no listener, no
  service), not only of correct responses from a running server:
  a gate that only tests running servers can never evidence the
  one behaviour a startup gate exists to produce.

- **GMSI-146 — Bench-image tool completeness.** (Bench-backed
  gate, 2026-11-12.) The Kali golden image lacks testssl.sh on
  PATH (only a /usr/share/doc remnant), so the deep TLS leg fell
  back to nmap ssl-enum-ciphers + openssl. A bench image's tool
  inventory is part of the gate's evidence surface: GM should be
  able to prove a bench venue carries the tools its legs claim
  before a leg is scheduled against it, and a missing tool must
  surface as a named NOT RUN, never a silent substitution.
  Folded note: the grand-machine IAM key can launch and
  terminate bench instances but cannot start/stop the standing
  ones — bench lifecycle is launch+terminate only.
- **GMSI-147 — Edge TLS floor proof.** (Bench-backed gate,
  2026-11-12.) The Cloudflare zone edge for the production
  surface still offers TLS 1.0/1.1 including
  TLS_RSA_WITH_3DES_EDE_CBC_SHA (grade C) while the daemon
  itself negotiates TLS 1.3. GM should be able to prove the
  *served* TLS floor of a deployment's public edge — minimum
  version and weakest cipher actually offered — not only the
  daemon's own stack, so an edge downgrade path surfaces as a
  finding. Recommendation of record: raise the zone minimum
  TLS version to 1.2 (dashboard setting; the daemon is
  unaffected — it terminates nothing publicly).
- **GMSI-148 — Operator tooling installed, not staged.**
  (Bench-backed gate, 2026-11-12.) The gm CLI is not installed
  on the production box; gate and nightly runs upload the
  current release's gm to /tmp per run and remove it after,
  and stale operator binaries from prior runs accumulate in
  /tmp. A deployment should install its operator CLI at deploy
  time from the same attested build as the daemon, and GM
  should be able to prove the installed CLI's build matches
  the daemon it operates (version + commit + binary hash)
  instead of trusting a staged copy.
- **GMSI-149 — Dependency-audit scope pinning.** (Bench-backed
  gate, 2026-11-12.) The repo commits no Cargo.lock, so a
  cargo audit resolves fresh from the manifests — the audited
  tree can differ from the attested build's tree. GM should be
  able to prove a dependency audit ran against the exact lock
  of the build it gates: commit Cargo.lock, or pin gate audits
  to the attested build's lock and file that lock in the
  evidence pack. (cargo-audit 0.23.0 is now installed on the
  verifying VM; the reliable route through the sandbox proxy
  is --no-fetch against the cached advisory DB.)
- **GMSI-150 — Content-rule payload coverage.** (WO-DCR gate,
  2026-11-12.) The v0.25.0 policy content rules inspect the
  evaluate action's context JSON — the surface the shipped gm
  client populates (context = request payload, metadata =
  {}). A caller placing a registration payload in
  EvaluateRequest.metadata, or a future MCP arguments
  envelope, sits outside the rule's view. Extend content-rule
  inspection to the request's other payload-carrying surfaces
  (or prove at the protocol layer that context is the only
  payload surface a mediated call can take), with control
  tests for each surface covered.
- **GMSI-151 — Sibling DCR validations + a spec row for the
  rule family.** (WO-DCR gate, 2026-11-12.) v0.25.0 ships the
  fragment rule only (DCR-REDIRECT-FRAGMENT). Unbuilt from the
  same case family: non-loopback http redirect_uris (scheme
  downgrade), redirect URIs with embedded credentials
  (userinfo), and unparseable URI values — each wants a named
  rule, a blocked verdict with the rule sealed in the proof's
  reasons, and control tests, specified the same way
  (RFC 6749 §3.1.2, RFC 7591 §2, OAuth Security BCP). Also to
  specify: a row in the revised Guardian Mesh specification
  for the content-rule family itself — the fragment rule
  shipped under the gate's case-file spec input
  (2026-10-15-conduit-dcr) without one.

- **GMSI-152 — Self-contained lane tasks.** (WO-20 gate,
  2026-11-12.) Two OpenCode sessions died on WO-20
  researching an ML-DSA signature length in the cargo
  registry: reads outside the project directory are
  permission-auto-rejected, and the rejection ends the
  session with zero files written. GM should be able to
  prove a build task is self-contained — every API fact
  the lane needs is inside the repo or the task file —
  before dispatch, so a lane never has to leave the
  project surface to finish. (Fix of record on WO-20: a
  self-delimiting token wire format plus the needed
  facts written into the task file itself.)

- **GMSI-153 — Reconciliation covers the register.**
  (WO-32 gate, 2026-11-13.) GMSI-143 asks for a
  per-release spec<->release reconciliation proof.
  Since v0.27.0 the risk register's residual scores
  are computed from countermeasure statuses, so a
  status that ships without a register re-score is
  the same defect class in a second document.
  Guardian Mesh should be able to prove, per
  release, that every shipped status change has a
  matching threat-model review line and a register
  re-score (or an explicit no-change record) — the
  reconciliation proof covers all three documents
  or it covers none of them honestly.

- **GMSI-154 — Leakage-canary probe.** (Gate Agent
  v0.1.0 gate adjudication, 2026-11-14.) An
  engagement-surface leakage canary as a standing
  GM probe: submit a unique canary through a
  product's engagement/intake surface, then search
  every output surface the product exposes and
  prove the canary appears only where the contract
  allows it (e.g. the submitter's own receipt) and
  nowhere else. Filed as a probe candidate: it
  becomes a gate MUST only after it is
  behaviour-proven here, per the standing rule.

- **GMSI-155 — Rate-bound enforcement probe.**
  (Gate Agent v0.1.0 gate adjudication,
  2026-11-14.) A declared rate limit on any served
  face must be proven enforced from an independent
  vantage — requests up to the declared bound are
  allowed, the next request is refused (429 or the
  face's declared refusal) — never taken from the
  code or the contract alone. Filed as a probe
  candidate: it becomes a gate MUST only after it
  is behaviour-proven here, per the standing rule.

- **GMSI-156 — Declared bound == enforced bound,
  end-to-end.** (WO-37 gate, 2026-11-14.) The
  daemon's certificate evidence cap is 10 MB
  (certificate.rs), but the gRPC (tonic) transport
  refuses messages above 4 MB, so evidence between
  4 MB and 10 MB is refused at transport — with a
  clear error, fail-closed — before the daemon cap
  can apply, for every client. Guardian Mesh
  should be able to prove, for any RPC carrying
  evidence or proofs, that the bound declared at
  the application layer equals the bound enforced
  at every layer beneath it (transport, proxy,
  envelope), or name the effective bound honestly
  as the transport's.

GMSI-157…181 were filed by the release gate's 2026-11-15 atoms
runs (packs: release-gate-runs/atoms-per-atom-gate-2026-11-15,
atoms-gateway-v1-2026-11-15, atoms-gateway-v110-prorated-
2026-11-15, atoms-gateway-takedown-presentation-2026-11-15,
atoms-gateway-batch14-2026-11-15; batch15 filed none new).
In every one of those runs the Guardian Mesh disposition was
NOT RUN — no GM machinery is behaviour-proven for an external
product surface — and the records below state what GM must be
able to prove before any atoms gate may mark the GM leg
PROVEN. They queue behind the Part A work orders exactly as
GMSI-6…156 do, and none becomes a gate MUST until
behaviour-proven here.

- **GMSI-157…169, GMSI-175, GMSI-176 — Per-atom verdict
  certification (one record per cohort, the obligation per
  atom).** (Per-atom R-18 gate run, 2026-11-15; canonical
  record: atoms-per-atom-gate-2026-11-15/gmsi.md.) Until that
  run, atoms carried no per-atom gate verdict at all — a
  verdict could be edited after the fact and nothing
  downstream could tell. GM must prove, per atom: evaluation
  input = atom id (`org.aimlds/atom-<atom>`), gateway version
  + deployment id, sha256 of the atom's recorded case corpus
  (cases.json), the gate verdict, the per-check outcome
  summary, sha256 of the atom's GATE-VERDICT record and of
  the batch evidence pack. ALLOW only when the verdict in
  the proof equals the verdict in the filed gate record AND
  both hashes recompute; BLOCK on any mismatch, on a missing
  corpus hash, or when the atom's kill switch
  (`atom_enabled=0`) is set. Sealed-proof fields: atom id,
  cohort, gateway deployment id, corpus hash, verdict,
  checks summary hash, pack hash, issued-at, supersedes.
  Tamper: any altered field verifies NOT VALID; a superseded
  verdict's proof verifies SUPERSEDED, never VALID.
  Lifecycle: issue at gate verdict; supersede on re-gate;
  revoke on kill-switch activation or a BLOCKED re-gate;
  expire with the RC soak if graduation is refused. Cohorts:
  157 = release-readiness-verdict (atom #1); 158 = Batch 1
  (agent-safety-guardrail-audit, append-only-ledger-design-
  audit, dependency-governance-audit, encryption-claim-
  audit, firewall-rules-audit, license-compliance-check);
  159 = Batch 2 (agent-evaluation-scorecard, assumption-
  audit, claim-verification-fact-check-stamp, codebase-
  structural-query, condition-monitoring-triage, defined-
  flow-auditor); 160 = Batch 3 (correctness-verification-
  certificate, crypto-inventory-pq-migration-map, decision-
  trap-sweep, distribution-equipment-rating-condition-check,
  electrical-machinery-engineering-check, electrical-test-
  record-preparation); 161 = Batch 4 (finance-content-
  compliance-check, forecast-with-ranges-and-scorecard,
  lean4-formal-proof, link-rot-scan-and-notarized-archive,
  network-exposure-audit, portfolio-risk-analytics-report,
  prediction-model-leakage-calibration-audit); 162 = Batch 5
  (predictive-maintenance-failure-risk-assessment, pump-
  conveyor-motor-suitability-check, rag-retrieval-
  evaluation-tuning, reconciled-portfolio-performance-
  report, semantic-code-taint-analysis-report); 163 =
  Batch 6 (strategy-backtest-validation, tested-
  authorization-policy-pack, vfd-application-engineering-
  check, vulnerability-triage-verified-closure, zero-
  knowledge-claim-audit, zero-trust-evaluation-verdict);
  164 = Batch 7 (acp-protocol-integration-review, agent-
  context-packaging, agent-interoperability-design,
  agentic-coding-practice, algorithm-design-implementation,
  applied-ml-validation, architecture-decision-record);
  165 = Batch 8 (argument-analysis-review, audience-
  contract-design, auth-design-review, backend-engineering-
  advice, base-rate-card, behavioral-finance-bias-check,
  behavioral-finance-debiasing); 166 = Batch 9 (bias-
  controlled-quant-study-pack, brand-mention-monitoring-
  triage-digest, browser-extension-engineering, budget-
  design-review, buyer-test-card, c-engineering-review,
  cash-flow-forecast); 167 = Batch 10 (cicd-pipeline-design,
  claim-evaluation-review, code-review-service, codebase-
  visualization, community-support-operations, confidential-
  computing-design, cost-estimate-preparation); 168 =
  Batch 11 (cpp-engineering-review, creative-ideation-
  session, crm-pipeline-operations, data-analysis-
  deliverable, data-ml-pipeline-engineering, data-
  visualization-design, database-design-review); 169 =
  Batch 12 (decision-process-design, decision-ready-
  research-brief, delivery-plan-preparation, designed-test-
  case-pack, difficult-conversation-coaching, document-
  operations-service, domain-portfolio-audit); 175 =
  Batch 13 (edge-platform-engineering, efficient-web-build-
  standard, engineering-project-budget-pack, engineering-
  work-package-structuring, fare-construction-savings-
  strategy, finance-education-article, electrical-machines-
  expert-advice — the last-named was disabled by owner
  ruling under process line U-13 before its gate pass; no
  verdict was issued for it, and under this record's own
  rule its kill-switch state BLOCKs certification today;
  the obligation attaches in full if the atom returns);
  176 = Batch 14 (finance-tool-design-advisory, forecast-
  confidence-scoreboard, framework-adoption-adr, frontend-
  implementation, full-stack-app-build-pack, grpc-service-
  design, home-shortlist-carrying-cost-comparison).

- **GMSI-170 — A gate verdict must bind to a CI run that
  actually ran.** (Per-atom gate run, 2026-11-15.) GM must
  prove: evaluation input = (commit hash, CI run id, suite
  result hash); ALLOW only when a CI run for that exact
  commit exists and is green; BLOCK when the only evidence
  is a local run. Tamper: an altered run id or result hash
  verifies NOT VALID. Lifecycle: issue per gated commit;
  supersede per new commit.

- **GMSI-171 — Connection-protection posture must become
  provable.** (Per-atom gate run, 2026-11-15.) The family
  was NOT RUN in every atoms gate to date (no TLS bench in
  the lane). GM must prove: evaluation input = (surface URL,
  TLS probe result: protocol floor, cipher set, cert chain
  + expiry, HSTS); ALLOW only at TLS ≥ 1.2 with a valid
  chain and ≥ 30 days cert life; BLOCK otherwise. Tamper /
  lifecycle as per the GMSI-170 pattern.

- **GMSI-172 — Request-body size policy, if ever claimed,
  must be proven.** (Per-atom gate run, 2026-11-15.) A
  1.5 MB JSON body was accepted and processed; no cap is
  claimed today, so this is a policy that does not exist
  yet, not a finding. GM must prove (when a cap exists):
  evaluation input = (endpoint, body size, observed
  status); ALLOW only when bodies above the cap are
  rejected before handler execution; BLOCK on acceptance.

- **GMSI-173 — Security-header posture on HTML surfaces.**
  (Per-atom gate run, 2026-11-15, from finding F-G3.) GM
  must prove (the fix shipped at atoms Batch 14 and awaits
  GM proof, not another build): evaluation input = (surface
  URL, header snapshot); ALLOW only when HSTS, CSP,
  X-Frame-Options (or CSP frame-ancestors),
  X-Content-Type-Options and Referrer-Policy are all
  present on HTML responses; BLOCK on any absence. Tamper:
  altered snapshot verifies NOT VALID. Lifecycle: issue per
  deployment; supersede per deploy.

- **GMSI-174 — Judgment corpora must be sealed with the
  verdict.** (Per-atom gate run, 2026-11-15.) GM must prove:
  evaluation input = (atom id, corpus hash, corpus case
  count); ALLOW only when the corpus that produced a
  verdict recomputes to the sealed hash; BLOCK on drift.
  Lifecycle: supersede when a case is appended (escape-
  driven growth), never when one is removed — a shrinking
  corpus is itself a BLOCK. (The corpus hash is a required
  input to GMSI-157…169/175/176.)

- **GMSI-177 — Documentation surface can never diverge
  from availability state.** (Atoms-gateway Batch 14 deploy
  pack, 2026-11-15. NUMBERING: that pack filed this input
  as "GMSI-175", colliding with the per-atom pack's
  GMSI-175 (Batch 13 cohort, above — filed first, in the
  canonical gmsi.md, and keeping its number); this record
  is renumbered GMSI-177 on intake here, and both source
  packs record the collision.) GM must be able to prove,
  for every atom, that (catalogue row present) ⇔ (feed
  status live) ⇔ (feed documentation link present ⇒ doc
  emitted and atom live) ⇔ (/docs/<atom> serves) holds as
  one invariant over live kill-switch state.

- **GMSI-178 — Kill-switch presentation invariance.**
  (Atoms-gateway takedown-presentation pack, 2026-11-15;
  filed unnumbered there.) GM must be able to prove, for
  any atom whose D1 `atom_enabled:<atom>` is `0`, that the
  atom is (a) absent from the catalogue HTML, (b) marked
  `"status":"disabled"` in /api.json, (c) absent from
  /health `atoms` and present in `disabled_atoms`,
  (d) returning an empty tools array from MCP tools/list,
  and (e) refusing MCP tools/call with a literal HTTP 503 —
  presentation state can never diverge from kill-switch
  state. (Sibling of GMSI-177.)

- **GMSI-179 — Deterministic fence replay probe set.**
  (Atoms-gateway v1 gate, 2026-11-15; filed unnumbered
  there.) The gateway's deterministic fences (401/403/402/
  429 ordering, idempotent money movement, uniform auth
  responses) are a reusable probe set: GM should be able to
  replay the attacker-view table + the rate-limit burst
  against any future atoms-gateway deployment and grade
  drift.

- **GMSI-180 — Money-path refund invariant probe.**
  (Atoms-gateway v1.1.0 prorated-refund gate, 2026-11-15;
  filed unnumbered there.) For every grant, Σ reversals ≤
  grant − Σ attributed draws, and every refund reversal's
  amount equals a Stripe refund object's amount — a
  standing GM probe over the money path.

- **GMSI-181 — Webhook replay / ordering probe for refund
  events.** (Atoms-gateway v1.1.0 gate, 2026-11-15; filed
  unnumbered there.) Webhook handlers must be probed with
  replayed and out-of-order refund events (partial, then
  full) — idempotency per refund id, not per charge.

- **GMSI-182 — Content-binding proofs.** (WO-37 T2 gate,
  2026-11-15.) An AuditProof binds action_id (the action
  type), verdict, timestamp, policy_version and
  issuing_node — not the evaluated action's target or
  content hash. A publish receipt's proof<->hash pairing is
  therefore receipt-asserted (presenter-declaration class)
  and checked by recomputation. GM should be able to seal
  the action's target + a hash of its descriptor inside
  the proof itself, so content-bearing receipts (publish,
  and any future content-addressed action) are
  daemon-sealed end to end. Probe candidate only: it
  becomes a gate MUST once behaviour-proven here.

## Development home and engine routing

Owner direction (2026-10-14, replacing the original routing): **development
happens on the owner's laptop, driven by OpenCode there — never on the
Aetheris box.** The box is a deployment target only (the daemon and live
panel services); no building and no OpenCode runs on it. **GitHub is the
repo's home of record** — every lane works on branches and PRs here, and
the laptop checkouts are working copies, never the source of truth.

- **OpenCode on the laptop** — the primary builder, one work order per
  branch/PR. It works in a fresh clone per work order
  (`D:\guardian-mesh-work\<work-order>`, cloned from GitHub main). The
  pre-existing `D:\guardian-mesh` checkout is stale and carries the
  owner's own local changes — never build in it, never clean it.
  OpenCode's output is never trusted on its own tests (owner's standing
  rule: "sometimes it screws up").
- **Model lanes OpenCode may drive, all owner-authorized**: DeepSeek AI,
  OpenAI, Claude, and OpenCode Zen. DeepSeek stays dev-material-only
  (specs and code, never production data or real credentials).
- **Wright** — direction, the whole-app read before changes, independent
  re-testing from the pushed branch (fresh checkout; full suites),
  the release-gate run for each release, merge (green only), deploy to
  the box, and this file's nightly refresh.
- **Testing is always the Release Gate** — machine pass + deep review +
  behaviour proof, verdict recorded in the release record — plus the
  gate's security tuning for the change's families. No gate verdict, no
  merge, no deploy.

## The nightly loop

1. Re-read this file, open issues/PRs, and the release gate's latest
   GMSI filings; refresh this file by PR when new inputs arrived.
2. Take the highest-priority unfinished work order; the laptop's
   OpenCode builds it in a fresh per-work-order clone, on a branch, as
   a draft PR.
3. Wright verifies independently: fresh checkout of the pushed branch,
   full test suites (`cargo test`, webui build + lint), and behaviour
   proof on the live surface where the change touches one.
4. Release gate: run the gate on the change; record the verdict in the
   PR and the CHANGELOG; file this run's GMSI (or "none").
5. Merge only when CI is green and the gate is not BLOCKED. Deploy
   (box services + Pages) per the established paths and re-verify live.
6. One consolidated report to the owner: what advanced, what verified,
   what is NOT RUN and why. No per-step drips.

## Status ledger

- 2026-10-14 — pack created from repo inventory (zero open issues/PRs;
  pending work lives in `specs/` + verified implementation gaps) and the
  release gate's founding GMSI set. WO-1 dispatched first.
- 2026-10-14 — **WO-1 shipped as v0.3.0** (PR #26, merged a6b7d195):
  Handshake binds the caller's ML-DSA-65 public key; Evaluate verifies
  the envelope signature against it, fail-closed. Wright-verified
  independently: 47 cargo tests green on a fresh checkout; wire-level
  proof 9/9 on the branch daemon and again 9/9 against the deployed
  daemon on the Aetheris box (valid → ALLOW + VALID proof; garbage /
  wrong-key / tampered → permission_denied; keyless handshake →
  invalid_argument). Release gate: PASS WITH FINDINGS (scanner "tests"
  failure was a false lead — inline Rust tests; GMSI filed to teach
  the scanner `#[test]` detection; optional: `.gitignore` name `.env`).
  Deployed to guardian.aimlds.org the same night. Next: WO-2.
- 2026-10-14 — **Development home moved to the laptop** (owner's order):
  OpenCode on the laptop builds (fresh clone per work order;
  `D:\guardian-mesh` is stale + owner-dirty, hands off), authorized
  model lanes are DeepSeek / OpenAI / Claude / OpenCode Zen, GitHub
  stays the repo home, the Aetheris box is deployment-only, and
  testing is always the Release Gate + security tuning. Recon the
  same night: OpenCode 1.18.32 runnable on the laptop, git 2.52,
  node 26.
- 2026-10-14 (later) — **Laptop lane at full strength**: the owner
  made the laptop `muse` account an administrator and placed Wright's
  key in `C:\ProgramData\ssh\administrators_authorized_keys` (the
  Windows rule for admin accounts). Wright installed the toolchain
  under `muse` itself: rustup stable (cargo/rustc 1.99.0), protoc
  29.3, OpenCode on muse's PATH. Proof: a fresh clone at
  `D:\guardian-mesh-work\probe` ran `cargo test` on the laptop —
  47/47 passed. The earlier "cargo shim does not execute" note is
  superseded; laptop-side builds and tests are proven.
- 2026-10-15 — **WO-2 shipped as v0.4.0** (PR #31, merged 2a98e7be):
  the Protocol Firewall rule table is enforced on Evaluate — PF-1/5
  size, PF-12 unknown fields, PF-13 nesting ≤4, PF-14 nonce window
  (10,000/session), PF-15/16 timestamp windows (stale >5 s, future
  >1 s, nanosecond field), PF-17 signature format [2420, 3500],
  PF-18 rate limit 100 msg/s/session (E_RATE_LIMITED). PF-2..PF-11
  documented not-applicable at the gRPC surface in the PR. Built by
  the laptop lane (OpenCode, Claude lane) in D:\guardian-mesh-work\wo2;
  Wright-verified independently: cargo 58/58 on a fresh checkout;
  wire-level E2E 16/16 against the release build and again 16/16
  against the deployed daemon on the box (incl. a 115-request burst:
  exactly 100 allowed, 15 × PF-18). Release gate: PASS WITH FINDINGS
  (F1 firewall session state never evicted — evict_session has no
  callers; F2 Health PF counters are constants, not measured; F3–F5
  informational — see PR #31). Deployed to guardian.aimlds.org the
  same night (binary sha256 4254b5eb…, rollback kept as
  guardian-meshd.bak-v030 on the box). GMSI-6 (scanner Rust
  inline-test detection, second false BLOCKED) and GMSI-7 (bind
  measured per-rule firewall outcomes into WO-6 evidence packs)
  filed from this run. Next: WO-3.
- 2026-10-15 — **Laptop lane operating recipe** (learned on the WO-2
  run; reuse it): (1) launch OpenCode detached via Win32_Process.Create
  — children of the SSH session die with it; (2) never pass a long
  prompt as a CLI argument (the .cmd shim truncates it) — put the task
  file INSIDE the clone (headless runs auto-reject reads outside the
  project dir) and pass one short instruction naming it; (3) stdin must
  be redirected from an empty file (an open SSH stdin makes
  `opencode run` die with EUNKNOWN/read); (4) working model lane:
  `anthropic/claude-sonnet-4-5` with the key read from the owner's
  auth.json by the runner script itself and injected as an env var
  (never copied, never logged); Zen (`opencode/…`) Claude models
  currently answer "Model access is disabled" and the laptop's own
  opencode.db is ~7 GB — run the lane with muse's own data home, not
  the owner's; (5) git push from the laptop under `muse` is blocked
  (Git Credential Manager needs an interactive prompt) — the lane
  commits locally and Wright carries the exact commit to GitHub by
  git bundle + API push, asserting the tree hash matches; (6) the
  deploy binary is cross-built on Wright's machine with
  cargo-zigbuild (aarch64-unknown-linux-gnu; blake3 needs the zig cc)
  — the box never builds.
- 2026-10-15 — **Revised Specification v3.0 adopted** (owner's order):
  `specs/GUARDIAN_MESH_REVISED_SPEC.md` is the governing target spec,
  folding in the data-center readiness set (owner-approved: "what you
  said for muse datacenter is correct"), the hyperscaler-aligned
  checkpoint catalogue (AWS Well-Architected SEC / Google Security
  Foundations + BeyondCorp/BeyondProd / Microsoft Cloud Security
  Benchmark / OCI Security Zones + Cloud Guard / Meta infra zero
  trust, on a NIST CSF + 800-53 + 800-207 + CIS spine), the release
  gate as criteria of record, and the owner's new doctrines: deploy
  on every endpoint class (clouds, servers, laptops, phones, edge,
  browsers), every boundary crossing needs authorization + handshake
  with at least two independent confirmations, and authorization by
  any lawful method — PGP/GPG included. New work orders WO-10…WO-19
  added as Part C of this pack. Honesty labels in the spec mark
  SHIPPED / PARTIAL / TARGET; nothing [TARGET] may be described as
  existing capability.
- 2026-10-15 — **Spec amended to v3.1** (owner-directed, same day):
  §0.5 product boundary charter (what it is / does / stands /
  cannot do — liability and honesty edges in normative text);
  Doctrine 0, the closed-path rule ("package it such that things
  can only flow in certain way… nothing that is not a desired path
  can at all invoke anything"); §11 complete mediation — the owner
  ruled an unguarded path is a vulnerability, so credential escrow,
  execution tokens, receipt reconciliation, drift watch, and a
  coverage statement inside every certificate; §12 securing the
  guardian (threat model of record, anti-downgrade, secure-by-
  default incl. refusing the default handshake secret, external
  witnessing of the audit chain, compromise playbook, insider
  separation, independent review, authenticated time, end of life);
  §13 product completeness (payload DLP, tool/model supply chain,
  delegation attenuation, policy authoring, agent registry, admin
  RBAC, compliance exports, certificate transparency, incident kit,
  alerting, air-gapped mode, integration wrappers, self-test kit,
  appeal path, operational completeness). Work orders WO-20…WO-30
  added as Part D of this pack.
- 2026-10-16 — **Standards compliance review + development plan**
  (owner's order): `specs/STANDARDS_COMPLIANCE_REVIEW.md` (PR #36)
  found ISO/IEC 22989 PARTIAL (terminology form gap), 23894
  PARTIAL, CSF/800-53 PARTIAL, FIPS 140-3 GAP (not claimed), SLSA
  TARGET, no organizational certifications held or claimed.
  `specs/COMPLIANCE_DEVELOPMENT_PLAN.md` converts every gap into
  builds with acceptance evidence: WO-31 (terminology annex),
  WO-32 (AI risk register per 23894, after WO-30), WO-33 (NIST AI
  RMF profile), WO-29 bar raised (per-deployment CP evidence
  export), WO-36 (EU AI Act deployer pack), WO-35 (PKCS#11
  validated-module path, after WO-3), WO-13 (SLSA). Organizational
  track (42001/27001/SOC 2) is staged demand-led in the plan —
  groundwork only, certification spend on customer requirement,
  never theatre ahead of revenue.
- 2026-10-16 — **Relicensed: Apache 2.0 + Payment Rider** (owner's
  decision: "Apache two license plus payment rider"). The former
  split (AGPL core / Apache interface) is retired: root LICENSE and
  guardian-meshd/LICENSE now carry the canonical Apache 2.0 text,
  LICENSE-RIDER.md carries the rider (free use/self-hosting at any
  scale; paid license only for offering verdicts/certification as
  a service or issuing certificates under the name), README and
  guardrail 3 updated, all daemon SPDX headers swept AGPL→Apache-2.0
  (verified: zero AGPL strings remain in sources). Honest naming
  rule in the rider itself: always "Apache License 2.0 + Payment
  Rider", never bare Apache 2.0.
- 2026-10-15 (nightly) — **Pack refreshed: GMSI-6…47 filed.** The
  WO-1/WO-2 gate runs (GMSI-6/7) and the release gate's 2026-10-15
  fleet re-gate — 13 product packs — filed the spec inputs now
  carried in Part B; onsmartgrid and the Conduit Router re-run
  filed none. Repeats are consolidated (the transport floor,
  GMSI-8, was filed seven times in one day — the fleet's loudest
  repeat class). The work-order order does not change: the new
  inputs queue behind Part A and land through WO-6's certificate
  schema and the gate's standing probe sets, each becoming a MUST
  only once behaviour-proven here. Next: WO-3.
- 2026-10-17 — **WO-3 shipped as v0.5.0** (PR #40, merged 5ecf9074):
  the daemon's ML-DSA-65 signing key persists — the 32-byte seed is
  generated on first start into `<workspace>/keys/daemon_signing_key.bin`
  (mode 0600, permissions set before the seed is written, fsync'd) and
  loaded on later starts; a corrupt or unreadable key file fails
  closed with a FATAL naming the file — never a silent regeneration.
  Health reports `signing_key_fingerprint` (proto field 5): lowercase
  hex SHA-256 of the public key — fingerprint only, never key
  material (GMSI-2's GM-side half). Generation/storage/backup/rotation
  documented in `guardian-meshd/README.md`. Built by the laptop lane
  (OpenCode, Claude lane) across two runs — the first died mid-work
  when the laptop restarted for updates; a continuation run finished
  it; Wright carried the commit by git bundle with tree-hash equality
  asserted (lane tree 72de5f98 == pushed tree). Wright-verified
  independently: cargo 65/65 on a fresh checkout (58 at v0.4.0);
  wire-level two-boot proof — proof issued under boot 1 verifies
  VALID under boot 2 (distinct processes), corrupt key → exit 1,
  restored key → validity returns, fresh workspace → different
  fingerprint and the old proof correctly invalid there. Release
  gate: PASS WITH FINDINGS (F1 low cosmetic — the FATAL line doubles
  its prefix; F2 low — the keys/ directory's permissions are not
  pinned; scanner "tests" BLOCKED is the GMSI-6 false lead, third
  occurrence, resolved by the direct suite evidence; Kali/Arch
  backbone families NOT RUN — benches not yet built). Verification
  also caught the relicense sweep's misses — daemon Cargo.toml still
  declared AGPL, build.rs carried an AGPL SPDX header, CONTRIBUTING
  still described split licensing — fixed on the branch (8fe51bab)
  to Apache License 2.0 + Payment Rider. Deployed to
  guardian.aimlds.org the same night (binary sha256 d93df02d…,
  rollback kept as guardian-meshd.bak-v040): production key
  generated on first start; production signing fingerprint
  dd2cf1a350e0b31c30fcf0db2d1dd73ade7487af08385ddce6b99e7d1f40a8c9,
  stable across a service restart with a pre-restart proof still
  VALID; box E2E 16/16; unauthenticated web check still 302.
  Next: WO-4.
- 2026-10-19 — WO-4 shipped as v0.6.0 (PRs #42–#44): AuditTrail read
  path (ReadAuditLog RPC) + live panel audit view; wire-verified
  against production (316 entries chain-VERIFIED). Gate PASS WITH
  FINDINGS. (Run detail: the 2026-10-18 nightly run log.)
- 2026-10-20 — **WO-6 shipped as v0.8.0** (PR #48, merged 0d963b7c):
  release-evidence certification — IssueCertificate /
  RevokeCertificate / CertificateStatus RPCs; certificate =
  sealed envelope over a canonical body (specs/
  CERTIFICATE_SCHEMA.md); fingerprint = SHA-256 of the exact
  payload bytes, carried alongside the envelope, never inside
  it; lifecycle (issue / supersede / BLOCKED-revokes) recorded
  in the hash-chained Vault audit log; registry persists
  across restarts on the WO-3 persistent key. Built by the
  laptop lane in three runs (initial + two gate fix rounds).
  Wright-verified independently: cargo 96/96; webui build+lint
  pass; wire proof 20/20 (issue, recompute, verify, mismatch
  refusal, supersession, BLOCKED revocation, restart
  persistence) + mixed-traffic chain proof. Gate: PASS WITH
  FINDINGS — F1 (High) first commit did not compile, committed
  without a test run; F2 (High) fingerprint not recomputable
  from the sealed payload; F3 lifecycle events initially in a
  separate file, not the chain; F4 (High) two VaultEnclave
  instances broke the chain under mixed traffic — all fixed
  in the loop and re-proven. Carried: Python checked-in client
  not regenerated (protoc 29.3 vs 6.31.1 gencode). Deployed
  to guardian.aimlds.org (binary sha256 86161727…, rollback
  guardian-meshd.bak-v070): production fingerprint unchanged
  (dd2cf1a3…, third upgrade), box E2E 16/16, Access 302, and
  the release certified ITSELF on production — certificate
  cert-20261020-000001 for guardian-mesh 0.8.0, evidence =
  this gate's verdict, fingerprint recomputes, VerifyProof
  valid, status ACTIVE. **F7 (High, carried, post-deploy):**
  the production audit chain FAILS verification at position
  557 — concurrent-burst chain race (GMSI-69), reproduced
  locally on v0.8.0 (one 115-burst → break at position 2, 32
  duplicate hashes). Pre-existing since bursts began sealing
  verdicts (v0.7.0); not a WO-6 regression, but v0.8.0's RC
  graduation weighs its fix. v0.8.0 is a RELEASE CANDIDATE
  (one-week watched soak). Next: WO-6.1 (chain-concurrency
  fix, P1), then WO-7.
- 2026-10-19 — **WO-5 shipped as v0.7.0** (PR #45, merged e994d842):
  THROTTLE and ESCALATE are real verdicts. PF-18 breaches and a
  policy-configurable per-session rate (GUARDIAN_MESH_POLICY_THROTTLE_RATE,
  default 100 msg/s) return verdict THROTTLE with a signed proof —
  a deliberate behaviour change from WO-2's permission_denied (the
  box E2E's PF-18 check now asserts THROTTLE verdicts; the old
  script is kept on the box as box-e2e.mjs.bak-v060).
  GUARDIAN_MESH_POLICY_ESCALATE_ACTIONS lists action types that
  require a human (default empty); precedence BLOCK > ESCALATE >
  ALLOW. Built by the laptop lane (one run, clean); Wright carried
  by bundle (tree 03c4b91f asserted equal). Wright-verified
  independently: cargo 85/85; webui build+lint pass; wire proof on
  the branch build — 115-burst = exactly 100 ALLOW + 15 THROTTLE
  (proof verifies) under both the policy rate and, with the policy
  rate raised, PF-18 itself (reason "PF-18 rate limit breach:
  E_RATE_LIMITED"); policy rate 5 = 5 ALLOW then THROTTLE;
  ESCALATE for a configured action with a verifying proof, BLOCK
  precedence intact, unconfigured traffic unchanged. Gate: PASS
  WITH FINDINGS — F1 scanner tests MUST false-lead (GMSI-6, 4th
  occurrence; resolved by direct suite evidence); F2 (low) reason
  attribution at equal defaults shadows PF-18 and the policy reason
  omits the numeric limit; F3 (low) the lane's THROTTLE test is
  structural, not a real burst — filed as GMSI-53 (a new verdict
  path's tests must drive its real trigger in-process); cargo audit
  NOT RUN (tool absent); Kali/Arch NOT RUN (benches not built).
  Judgment differential (§7) run: calibration + twins + citation
  graded PASS with F2 noted. Deployed to guardian.aimlds.org
  (binary sha256 8e4b9665…, rollback guardian-meshd.bak-v060):
  production fingerprint unchanged (dd2cf1a3…, the WO-3 identity
  surviving its second upgrade), production burst served the first
  15 THROTTLE verdicts with verifying proofs, box E2E 16/16,
  Access 302 intact. v0.7.0 is a RELEASE CANDIDATE (one-week
  watched soak). Next: WO-6.
- 2026-10-18 (nightly) — **Pack refreshed: GMSI-48…52 filed.**
  The only new Guardian Mesh Spec Inputs since the 2026-10-15
  refresh are the five items from the release gate's 2026-10-17
  independent re-gate of Verdict (served-script parse proof,
  SSRF spelling/resolution posture, judgment differential
  battery, concurrent fresh-identity rate proof, pattern-coverage
  canaries). No work-order order changes: WO-4 remains next.
- 2026-10-19 — **WO-4 shipped as v0.6.0** (PR #43, merged 6dc51add):
  the audit trail has a read path — a new additive `ReadAuditLog`
  RPC returns the Vault's persisted entries in append order with
  chain verification computed at read time (verified / entries
  checked / first-break position), and the live panel's audit view
  is wired to it. One design fact the build surfaced honestly:
  the pre-0.6.0 audit digest was per-entry, NOT chained — WO-4
  makes seal() write a true chain (prev-hash linked, all fields
  covered) and verification is dual-mode, so pre-0.6.0 entries
  verify against their original legacy formula and seed the
  chain (their reason/enclave-chain fields were never
  digest-covered; the daemon README now says so). Built by the
  laptop lane (OpenCode, Claude) across three runs — the first
  killed mid-build by a laptop reboot (Windows-update pattern,
  as WO-3's first run), a continuation finishing it, a third
  closing the gate fix loop. Wright-verified independently:
  cargo 78/78 on a fresh checkout of the pushed tree (pushed
  tree == lane tree, asserted), webui build + lint green, and
  Wright's own probes — hand-edited file line → break at the
  exact position; legacy entry verifies; mixed legacy→new log
  verifies; malformed stored hash returns a break report, never
  a panic. Release gate: PASS WITH FINDINGS (pack
  release-gate-runs/guardian-mesh-wo4-2026-10-18) — the fix loop
  closed F1 (High: verify_chain panicked on a malformed stored
  hash, byte-slicing log-controlled data) and F2 (High: every
  pre-0.6.0 entry falsely reported "break at position 0") on the
  branch before merge; F3 (Low, panel hid a break at position 0)
  fixed with them; F4 (Low, carried) is lane reporting slips
  (result-file test counts off by one twice; a result file
  briefly committed, removed by Wright's amend before push).
  Scanner "tests" BLOCKED is the GMSI-6 false lead, FOURTH
  occurrence, resolved by the direct suite evidence — GMSI-6 is
  re-filed by this run as the scanner's loudest repeat false
  lead; no other new GMSI. NOT RUN: Kali/Arch benches (not
  built), dependency-vuln scan, real-browser panel click-through.
  Deployed the same night: aarch64 daemon binary sha256
  8e5e994e… live on the box (rollback guardian-meshd.bak-v050
  kept), live panel dist rebuilt with the endpoint and deployed
  (webui-dist.bak-v050 kept), Pages demo deployment at the merge
  commit (asset hash == Wright's local demo build). Production
  proof on the wire: signing fingerprint unchanged
  (dd2cf1a3…); production ReadAuditLog returned the real log —
  213 pre-0.6.0 entries, chain VERIFIED — then the box E2E
  battery (16/16) sealed 103 new chained entries on top and the
  mixed 316-entry log still verifies. guardian.aimlds.org
  unauthenticated still 302. v0.6.0 is a release candidate under
  the standing one-week soak (to 2026-10-26). Next: WO-5.
- 2026-10-20 (nightly) — **WO-6.1 shipped as v0.8.1** (PR #53,
  merged e87a18b5): the chain-concurrency fix closing issue #50
  and GMSI-69 — both audit-chain writers (seal +
  record_certificate_event) now hold the last_chain_hash mutex
  across the whole append (predecessor read + digest + persist
  + predecessor update as one critical section); sequential
  behaviour, digest formula, and on-disk format unchanged.
  Built by OpenCode on the laptop lane (fresh clone at the
  GMSI-70..73-refreshed main, PR #52); Wright carried the tree
  with two edits (trail push inside the critical section; the
  lane's stale test counts corrected). Gate: PASS WITH
  FINDINGS — F1/F2 (Low) fixed in the loop; scanner BLOCKED
  only on the GMSI-6 "tests" false lead (sixth occurrence).
  Wright's independent verification: cargo 97/97 (80 lib + 17
  bin), webui build+lint green; barrier-synchronized burst
  FAILED pre-fix / PASSED post-fix; wire proof pair (identical
  150-append concurrent burst): v0.8.0 control = 7 duplicate
  hashes + break at position 1; v0.8.1 = 0 duplicates, chain
  VERIFIED. Filed GMSI-74 (above). Deployed to
  guardian.aimlds.org (aarch64 binary sha256 a2535e66…,
  rollback guardian-meshd.bak-v080): production fingerprint
  unchanged (dd2cf1a3…, fourth upgrade), box E2E 16/16,
  post-deploy segment of 268 entries (E2E PF-18 burst + a
  150-append burst) verifies with 0 breaks / 0 duplicates —
  while the whole-log verification still reports the
  historical burst-race break at position 557, which stands
  as recorded (pre-fix history; F3). The release certified
  itself on production: certificate cert-20261021-000032
  (guardian-mesh 0.8.1, PASS WITH FINDINGS, evidence = the
  gate verdict), fingerprint recomputes, VerifyProof valid,
  supersedes cert-20261020-000001, status ACTIVE.
  guardian.aimlds.org unauthenticated still 302. v0.8.1 is a
  RELEASE CANDIDATE (one-week watched soak, RC register row
  28; graduates 2026-10-27). v0.8.0's own graduation (row 26)
  weighed this fix landing — it has. Next: WO-7.
- 2026-10-21 (nightly) — **WO-7 shipped as v0.8.2** (PR #55,
  merged 2b774294): `revised_project_scope.md` rewritten to
  shipped reality — Sentinel/Gatekeeper/Witness/Arbiter/Vault
  pipeline (not the pre-implementation Auth/Compute/Storage/
  Network/Policy set), Apache License 2.0 + Payment Rider (not
  MIT), audit logging + ReadAuditLog and the 97-test suite as
  shipped (not "not implemented"/"not started"), the real
  specs/ table, TEE/BFT/mTLS/anchoring/Lean 4/OPA as design
  only, npm tooling, GitHub as home of record — and the
  byte-identical duplicate `specs/GUARDIAN_MESH_GAP_ANALYSIS
  (1).md` removed (both blobs f396e2ef, verified before
  deletion). No new GMSI arrived since GMSI-74 (the three
  2026-10-21 gate packs filed none), so no pack refresh was
  needed before the build. Built by OpenCode on the laptop
  (fresh clone D:\guardian-mesh-work\wo7, commit 31afd4f4);
  Wright carried by Git-data API with tree equality asserted
  (lane tree 94e66bbd, final tree 15b1a824). Wright-verified
  independently: cargo 97/97 (80 lib + 17 bin) from the
  workspace root; webui build+lint green; full read of the
  rewrite against README/CHANGELOG/daemon README/specs.
  Gate: PASS WITH FINDINGS — scanner BLOCKED only on the
  GMSI-6 "tests" false lead (seventh occurrence); F1 (Low)
  the lane ran cargo test inside guardian-meshd/ (96 = 79+17)
  and "corrected" the verified counts down — fixed by Wright
  carry edits and filed as GMSI-75 (above). Deployed to
  guardian.aimlds.org (aarch64 binary sha256 dcd0f79c…,
  rollback guardian-meshd.bak-v081): production fingerprint
  unchanged (dd2cf1a3…, fifth upgrade), box E2E 16/16, Pages
  asset == Wright's build, Access 302 intact, and the release
  certified itself on production — certificate
  cert-20261022-000033 (guardian-mesh 0.8.2, PASS WITH
  FINDINGS, evidence = the gate verdict), fingerprint
  recomputes, VerifyProof valid, supersedes
  cert-20261021-000032, status ACTIVE. Whole-log verification
  still reports the historical break at position 557 (pre-fix
  history, stands as recorded). v0.8.2 is a RELEASE
  CANDIDATE (one-week watched soak, RC register row 29;
  graduates 2026-10-28). Next: WO-8 (P2, fuzz the
  boundaries). Standing: dependabot PR #51 (vite bump) still
  open, outside the work orders.
- 2026-10-22 (nightly) — **Pack refreshed: GMSI-76..81 filed.**
  The DogEar gate runs of 2026-10-22 filed six new spec inputs:
  v1.2.0 — pack drift watch (GMSI-76), price-totality probe
  (GMSI-77), seam-activation watch (GMSI-78), pairing integrity
  (GMSI-79); v1.4.0 beta.4 — certified-shell identity (GMSI-80),
  capability-tier proof (GMSI-81). The v1.3.0 picker verdict
  filed none explicitly. These queue behind Part A like prior
  inputs and land through WO-6's certificate schema and the
  gate's standing probe sets, each becoming a MUST only once
  behaviour-proven here. Next: WO-8.
- 2026-10-22 (nightly) — **WO-8 shipped as v0.8.3** (PR #58,
  merged c8e4bb3b): three cargo-fuzz/libFuzzer targets in a
  detached `fuzz/` package — fuzz_envelope_decode (prost
  EvaluateRequest decode + PF size), fuzz_payload_parse
  (PF-1/12/13), fuzz_proof_verify (verify_proto_envelope +
  verifying_key_from_bytes) — with real seed corpora, a
  fuzz/README, and a nightly fuzz workflow (02:00 UTC +
  dispatch, 60 s per target, crash-artifact gate). Pack was
  refreshed first (PR #57, merged dfcdb1b1: GMSI-76..81 from
  the DogEar 2026-10-22 gates). Built by OpenCode on the
  laptop (fresh clone D:\guardian-mesh-work\wo8, lane commit
  f9acde7; carried by Git-data API with tree equality asserted
  at each commit — lane tree ceae6325, final tree 47220a86).
  Wright-verified independently: cargo 97/97 (80 lib + 17 bin)
  from the workspace root on Linux (the lane's Windows root
  run: 96 = 79+17; one lib test is #[cfg(unix)] — GMSI-75
  naming applied); webui build+lint green; and the fuzz
  behaviour proof the lane could not run (its cargo-fuzz
  install OOM'd on Windows): Wright built all three targets
  on Linux (nightly, cargo-fuzz 0.13.2) and ran each 30 s —
  envelope 1,570,318 execs, payload 922,892, proof 354,323 —
  zero crashes, zero crash artifacts. Gate: PASS WITH
  FINDINGS — scanner BLOCKED only on the GMSI-6 "tests" false
  lead (eighth occurrence); F1 (High) the lane's fuzz package
  had never been built and could not build (cargo-fuzz
  metadata, undeclared ml-dsa, Keypair import); F2 (High) the
  proof target's up-to-3500-byte signature slice could never
  verify a real 3309-byte ML-DSA-65 proof — fixed to the
  exact length, seeds regenerated real (valid_signed verifies
  under the target's fixed-seed key; valid_request prost-
  decodes and round-trips); F3 workflow continue-on-error
  would have swallowed crashes — crash-artifact gate added;
  F5 workflow ran cargo-fuzz from inside fuzz/ (cannot run
  there) — moved to the repo root; F4 lane's WO8-RESULT.md
  removed from the tree. All fixed in the carry. Filed
  GMSI-82 (above). Deployed to guardian.aimlds.org (aarch64
  binary sha256 8407e6c5…, rollback guardian-meshd.bak-v082):
  production fingerprint dd2cf1a3… unchanged (sixth upgrade),
  box E2E 16/16, Pages asset == Wright's build (webui
  unchanged), Access 302 intact, audit log at 1,179 entries
  with whole-log verification still reporting the historical
  break at position 557 (pre-fix history, stands as
  recorded), and the release certified itself on production —
  certificate cert-20261023-000034 (guardian-mesh 0.8.3, PASS
  WITH FINDINGS, evidence = the gate verdict sha256
  2b4df95c…), fingerprint recomputes, VerifyProof valid,
  supersedes cert-20261022-000033, status ACTIVE. v0.8.3 is
  a RELEASE CANDIDATE (one-week watched soak, RC register
  row 30; graduates 2026-10-29). Next: WO-9 (P1, public
  release log on the site). Standing: dependabot PR #51
  (vite bump) still open, outside the work orders.
- 2026-10-23 (nightly) — **WO-9 shipped as v0.8.4** (PR #60,
  merged 0d5787aa): public release log on the site — a
  `/releases` page in the WebUI rendering a typed data file
  (`webui/src/data/releases.ts`) with one entry per
  CHANGELOG version section (0.8.4 … 0.1.0: summary,
  highlights, gate verdict or "Not recorded", test record,
  status), plus a drift guard
  (`webui/scripts/check-releases.mjs`) wired into the webui
  build — a release that forgets the log now fails the
  build. No pack refresh was needed (no new GMSI had
  arrived since GMSI-82; the Sanity Check gate of
  2026-10-23 filed none). Built by OpenCode on the laptop
  (fresh clone D:\guardian-mesh-work\wo9, lane commit
  d42fda1; carried by Git-data API with tree equality
  asserted at each commit — lane tree df2dc100, final tree
  42b3810a). Wright-verified independently: cargo 97/97
  (80 lib + 17 bin) from the workspace root on Linux (the
  lane's Windows root run: 96 = 79+17; one #[cfg(unix)]
  test — GMSI-75 naming applied); webui npm ci + build +
  lint + check:releases green; drift-guard negative case
  proven by Wright on a scratch copy (exit 1, position-
  specific message). Gate: PASS WITH FINDINGS — scanner
  BLOCKED only on the GMSI-6 "tests" false lead (ninth
  occurrence); 0 secrets, 0 vulns (159 deps). F1 (Medium)
  the lane marked v0.8.0–v0.8.3 as "Released" — all four
  are RELEASE CANDIDATES in soak per the RC register —
  fixed in the carry (statuses sourced from the register,
  the status artifact); F2 (Low) the lane's draft
  CHANGELOG claimed the Linux 97 count before Wright ran
  it — corrected to name platform + verifier per count.
  Filed GMSI-83 (above). Deployed to guardian.aimlds.org
  (aarch64 binary sha256 7e5afacc…, rollback
  guardian-meshd.bak-v083; webui-dist.bak-v083 kept):
  production fingerprint dd2cf1a3… unchanged (seventh
  upgrade), both services active, Pages serving the gated
  asset index-D5AkpYQg.js, Access 302 intact, audit log
  at 1,181 entries with whole-log verification still
  reporting the historical break at position 557 (pre-fix
  history, stands as recorded), and the release certified
  itself on production — certificate cert-20261024-000035
  (guardian-mesh 0.8.4, PASS WITH FINDINGS, evidence =
  the gate verdict sha256 9441325f…), fingerprint
  recomputes, VerifyProof valid, supersedes
  cert-20261023-000034, status ACTIVE. Real-browser
  click-through of /releases NOT RUN (three browser-task
  windows closed without results tonight; live asset
  identity + bundle content inspection are the served-
  state evidence). v0.8.4 is a RELEASE CANDIDATE
  (one-week watched soak, RC register row 32; graduates
  2026-10-30). Part A is now complete (WO-1…WO-9).
  Next: WO-19 (P1, Part C first in order — firewall
  session eviction + measured Health counters).
  Standing: dependabot PR #51 (vite bump) still open,
  outside the work orders.
- 2026-10-24 (nightly) — **WO-19 shipped as v0.8.5** (PR #63,
  merged 608649f5; pack refresh PR #62, merged 863395a1,
  filed GMSI-84/GMSI-85 from the 2026-10-24 DogEar gates):
  firewall session eviction + measured Health counters,
  closing v0.4.0 gate findings F1/F2 (EV-5 groundwork).
  HandshakeBus eviction now returns the evicted session IDs
  (evict_expired / evict_expired_at); the service sweeps them
  into ProtocolFirewall::evict_session on Handshake and on
  Evaluate, and the Gatekeeper evicts a dead session's
  firewall state before blocking. The firewall records
  measured per-rule outcomes (Gatekeeper records the static
  PF-1/12/13/15/16/17; the instance checks record PF-14,
  POLICY_RATE, PF-18); Health reports the measured totals
  and a per-rule map in the new proto field 6
  (protocol_firewall_rule_counters, "passed=<n>,failed=<n>")
  — the 18/18 constants are deleted, a fresh daemon reports
  0/0 with an empty map. Built by OpenCode on the laptop
  (fresh clone D:\guardian-mesh-work\wo19, lane commit
  e048a40; carried by Git-data API with tree equality
  asserted at each commit — lane tree aa88997e, final tree
  78035aa5). Wright-verified independently: cargo 107/107
  (87 lib + 20 bin) from the workspace root on Linux (lane
  Windows run 106 = 86+20; one #[cfg(unix)] test); webui
  npm ci + build + lint + check:releases green (9 versions);
  wire proof on a local daemon AND on production over
  gRPC-Web through the shipped TS client: fresh Health 0/0
  empty map → one valid Evaluate = 9 passed / 9 total across
  exactly 9 rules → one PF-12 block = PF-12 failed=1 with
  later rules unrecorded. Gate: PASS WITH FINDINGS —
  scanner BLOCKED only on the GMSI-6 "tests" false lead
  (tenth occurrence); 0 secrets, 0 vulns (159 deps). F1
  (Low) the lane's shipped test counts were arithmetically
  wrong (Windows total vs Linux baseline; "9 added" for 10
  tests) — fixed in the carry. No new GMSI from this run;
  the WO-6 schema's reserved pf_outcomes wiring is the
  standing follow-up now that the counters exist.
  Deployed to guardian.aimlds.org (aarch64 binary sha256
  4e74382b…, rollback guardian-meshd.bak-v084;
  webui-dist.bak-v084 kept): production fingerprint
  dd2cf1a3… unchanged (eighth upgrade), both services
  active, Pages serving the gated asset index-CCim350_.js,
  Access 302 intact, audit log at 1,182 entries with
  whole-log verification still reporting the historical
  break at position 557 (pre-fix history, stands as
  recorded), and the release certified itself on
  production — certificate cert-20261025-000036
  (guardian-mesh 0.8.5, PASS WITH FINDINGS, evidence =
  the gate verdict sha256 38426175…), fingerprint
  recomputes, VerifyProof valid, supersedes
  cert-20261024-000035, status ACTIVE. v0.8.5 is a
  RELEASE CANDIDATE (one-week watched soak, RC register
  row 33; graduates 2026-10-31). Part C is underway
  (WO-19 done). Next: WO-10 (P1, Part C second in order —
  Simulate call + structured verdict reasons). Standing:
  dependabot PR #51 (vite bump) still open, outside the
  work orders.
- 2026-10-25 (nightly) — **WO-10 shipped as v0.9.0** (PR #66,
  merged 026dc374; pack refresh PR #65, merged bc318334,
  filed GMSI-86/GMSI-87/GMSI-88 from the 2026-10-25 gate
  runs): Simulate call + structured verdict reasons,
  closing spec DC-9/DC-10. A new Simulate RPC runs the
  identical verdict pipeline (one shared run_evaluation)
  with no-burn semantics — no vault seal or audit entry,
  no nonce/rate consumption and no PF counter recording
  (new ProtocolFirewall peek variants), empty
  handshake_token — and is marked simulation=true in the
  response AND inside the sealed proof; early blocks
  return Ok(BLOCK) with structured reasons instead of
  permission_denied, while real Evaluate behaviour is
  unchanged. Every verdict carries StructuredReason
  entries (rule_id + detail + remediation): Gatekeeper
  records the deciding check (PF-1/12/13/14/15/16/17/18,
  POLICY_RATE, SESSION, HMAC, SIGNATURE, ENVELOPE),
  Arbiter records POLICY / POLICY_ESCALATION; the proof
  carries the rule_ids. Built by OpenCode on the laptop
  in TWO lane runs (fresh clone
  D:\guardian-mesh-work\wo10 at refreshed main bc318334;
  the first lane stopped at ~50% and reported honestly,
  the continuation lane finished; lane commit b89384a;
  carried by Git-data API with tree equality asserted at
  each commit — lane tree 74988708, final tree 179c6fa7).
  Wright-verified independently: cargo 117/117 (90 lib +
  27 bin) from the workspace root on Linux (lane Windows
  116 = 89+27; one #[cfg(unix)] test); webui npm ci +
  build + lint + check:releases green (10 versions);
  wire proof 26/26 on a local daemon AND 26/26 on
  production over gRPC-Web through the shipped TS client
  (simulations left Health 0/0 and the audit log
  untouched; PF-12 simulation returns BLOCK + PF-12
  while the same envelope via Evaluate still
  permission_denies; proofs verify). Gate: PASS WITH
  FINDINGS — scanner BLOCKED only on the GMSI-6 "tests"
  false lead (eleventh occurrence); 0 secrets, 0 vulns
  (159 deps). F1 (High) the lane never updated the
  generated TS client (guardian_mesh_pb.client.ts):
  client.simulate missing — Wright's clean build failed
  TS2339 — and, Simulate sitting at service index 1,
  every existing client method index pointed at the
  wrong RPC; FIXED in the carry (simulate added at
  index 1, VerifyProof..CertificateStatus shifted to
  2..8). F2 (Low, fixed in carry): a simulation still
  ran the state-mutating TTL sweep; simulation proofs on
  the THROTTLE/final paths named the Vault though
  nothing is sealed; the missing-firewalled block had
  no ENVELOPE reason; the PF-15/16 fallback inverted
  the spec. F3 (Low, open): the Dashboard's simulate
  error path only console.errors. F4 (Low, fixed):
  lane CHANGELOG/releases test counts garbled. Filed
  GMSI-89 (above) from this run. Deployed to
  guardian.aimlds.org (site-integrity declaration
  cd38da62 opened + closed): aarch64 binary sha256
  34d1f818… cross-built from merged main (cargo-zigbuild;
  merged tree == gated tree 179c6fa7), installed
  (rollback guardian-meshd.bak-v085; webui-dist.bak-v085
  kept): production fingerprint dd2cf1a3… unchanged
  (ninth upgrade), both services active, box webui-dist
  carrying the base-/ build index-BVLu5-3_.js, Access
  302 intact, audit log at 1,185 entries (+1 = the
  proof Evaluate's seal; the cert issuance seals one
  more) with whole-log verification still reporting
  the historical break at position 557 (pre-fix
  history, stands as recorded), and the release
  certified itself on production — certificate
  cert-20261026-000037 (guardian-mesh 0.9.0, PASS WITH
  FINDINGS, evidence = the gate verdict sha256
  4f4b0451…), fingerprint recomputes, VerifyProof
  valid, supersedes cert-20261025-000036, status
  ACTIVE. v0.9.0 is a RELEASE CANDIDATE (one-week
  watched soak, RC register entry; graduates
  2026-11-01). Part C continues (WO-19, WO-10 done).
  Next: WO-11 (P1, Part C third in order — policy
  governance). Standing: dependabot PR #51 (vite bump)
  still open, outside the work orders.
- 2026-10-26 — **WO-11 shipped as v0.10.0** (PR #69,
  merged e2aeacba): policy governance (spec DC-18,
  DC-19, BM-6/BM-12) — signed versioned policy
  bundles (canonical serialization + SHA-256 content
  hash; genesis v1 = the previous defaults; fail-closed
  validation: version == current+1, prev_hash == current
  hash, no duplicate/invalid actions), a dual-control
  change path (ProposePolicyChange by a registered
  ML-DSA-65 policy admin, ApprovePolicyChange by a
  SECOND distinct registered admin; approval persists
  atomically via temp + rename, swaps under the write
  lock, audit-logs POLICY_CHANGE_APPLIED; no admins
  configured ⇒ change path refuses, publication still
  serves), a GetPolicy publication endpoint (bundle +
  hash + daemon signature over the canonical bytes +
  fingerprint + proposer/approver of record), and
  AuditProof.policy_version (proto field 8) on every
  verdict path including simulation. WebUI: read-only
  Dashboard policy display; no admin WebUI; multi-node
  propagation out of scope (single-node atomic swap;
  the bundle is the distributable unit). Built by the
  laptop lane (OpenCode, fresh clone
  D:\guardian-mesh-work\wo11 at refreshed main
  687534e9 — the pack had been refreshed the same night
  by PR #68 filing GMSI-90; lane commit a97b67d carried
  by API with tree equality asserted, 02a84b2f, then two
  Wright carry commits to gated tree efa76549 ==
  merged tree). Wright-verified independently: cargo
  137/137 at the workspace root (Linux; 136 Windows —
  one #[cfg(unix)] lib test; +20 over the 117 baseline);
  webui npm ci + build (drift guard: 11 versions) +
  lint green on a clean tree; wire proof through the
  shipped TS client 31/31 — genesis publication (hash
  recomputed in TS, daemon signature, fingerprint),
  policy_version 1 stamped on v1 proofs, unregistered /
  bad-signature refusals, dual-control propose/approve
  (same-principal approval refused), the verdict flip
  under v2 with policy_version 2, the POLICY_CHANGE_APPLIED
  audit entry, and restart persistence (v2 in force;
  the persisted file byte-for-byte the canonical
  bundle). Release gate: PASS WITH FINDINGS (scanner
  BLOCKED only on the GMSI-6 "tests" false lead, 12th
  occurrence; 0 secrets, 0 vulns / 159 deps). F1 (High,
  FIXED in Wright carry): the lane's generated TS
  message file declared the new policy interfaces +
  methods but no MessageType classes, and AuditProof's
  MessageType lacked field 8 — @ts-nocheck + Rollup
  globals kept build/lint green while the shipped
  bundle referenced undefined identifiers (runtime
  import failure) and TS clients dropped
  policy_version on decode; the carry adds all seven
  classes + the field, proven by the wire run. F2
  (Low, FIXED in carry): lane test-count arithmetic /
  placeholders corrected to verified counts. F3 (Low,
  OPEN): approval persists before the under-lock
  re-validation and swallows a record_policy_event
  error; no divergent state constructible in review.
  Filed GMSI-91 (above) from this run. Deployed to
  guardian.aimlds.org (site-integrity declaration
  a956ce80): aarch64 binary sha256 ec4ecc72…
  cross-built from merged main (cargo-zigbuild;
  merged tree == gated tree efa76549), installed
  (rollback guardian-meshd.bak-v090; webui-dist.bak-v090
  kept): production fingerprint dd2cf1a3… unchanged
  (tenth upgrade), both services active, box webui-dist
  carrying the base-/ build index-BSxUB-i_.js, Access
  intact, production wire proof 12/12 — genesis v1
  published with the identical content hash as the
  local daemon's (9b921513…), a change proposal
  refused with "unknown policy admin" (no admin
  registry configured on production — fail-closed by
  configuration, an operator decision), Evaluate
  ALLOW with proof policy_version 1; audit log at
  1,188 entries (+1 = the proof Evaluate's seal; the
  cert issuance seals one more) with whole-log
  verification still reporting the historical break
  at position 557 (pre-fix history, stands as
  recorded), and the release certified itself on
  production — certificate cert-20261027-000038
  (guardian-mesh 0.10.0, PASS WITH FINDINGS, evidence
  = the gate verdict sha256 c84dff34…), fingerprint
  recomputes, VerifyProof valid, supersedes
  cert-20261026-000037, status ACTIVE. v0.10.0 is a
  RELEASE CANDIDATE (one-week watched soak, RC
  register entry; graduates 2026-11-02). Part C
  continues (WO-19, WO-10, WO-11 done). Next: WO-12
  (P1, Part C fourth in order — revocation service).
  Standing: dependabot PR #51 (vite bump) still open,
  outside the work orders.
- 2026-10-27 — **WO-12 shipped as v0.11.0** (PR #71,
  merged 7e973a6d): revocation service (spec DC-14,
  EV-4, BM-12) — dual-control propose/approve
  revocation over the shared WO-11 admin registry
  for sessions (bus drop + firewall evict), client
  ML-DSA-65 keys (all bound sessions dropped;
  Handshake refused by key fingerprint), and
  certificates (registry revoke); approval applies
  synchronously under lock and measures propagation
  against the configured bound
  (GUARDIAN_MESH_REVOCATION_BOUND_SECS, default
  60 s); persistent fail-closed JSONL registry;
  REVOCATION_APPLIED audit events with failures
  surfaced, never swallowed; legacy
  RevokeCertificate refuses when an admin registry
  is configured; WebUI read-only revocation
  summary; multi-node propagation is WO-16 scope
  and is not claimed. Built by the laptop lane
  (OpenCode, fresh clone D:\guardian-mesh-work\wo12
  at main 626a729a; no pack refresh needed — no new
  GMSI had arrived; lane commit cfbfea6 carried by
  API with tree equality asserted, 453ac43a, then
  one Wright carry commit to gated tree 50ec2c4b ==
  merged tree). Wright-verified independently:
  cargo 160/160 at the workspace root (Linux;
  159 Windows — one pre-existing #[cfg(unix)] lib
  test; +23 over the 137 baseline); webui npm ci +
  build (drift guard: 12 versions) + lint green on
  a clean tree; wire proof through the shipped TS
  client 36/36 (all three kinds end-to-end,
  dual-control + signature refusals, change_id ==
  TS-computed SHA-256 of the canonical string,
  legacy-RPC tightening, REVOCATION_APPLIED audit
  entries, restart persistence). Release gate: PASS
  WITH FINDINGS (scanner BLOCKED only on the
  GMSI-6 "tests" false lead, 13th occurrence; 0
  secrets, 0 vulns). F1 (Low, FIXED in carry):
  CHANGELOG test arithmetic. F2 (Low, FIXED in
  carry): release-log "bound enforcement" wording —
  the bound is measured and reported, not
  watchdog-enforced. F3 (Low, OPEN): no propagation
  watchdog — single-node application is synchronous
  by construction; multi-node is WO-16. Filed
  GMSI-92 (above) from this run. Deployed to
  guardian.aimlds.org via gm-deploy: aarch64 binary
  sha256 0b612653… cross-built from merged main
  (cargo-zigbuild; merged tree == gated tree
  50ec2c4b), installed (rollback
  guardian-meshd.bak-v0100; webui-dist.bak-v0100
  kept); production fingerprint dd2cf1a3… unchanged
  (eleventh upgrade), both services active, box
  webui-dist carrying the base-/ build
  index-DVJt8f8u.js, Access intact (302),
  production wire proof 14/14 — Health SERVING with
  PF fields consistent with the measured rule
  counters, revocation summary bound 60 / total 0,
  a change proposal refused with "unknown policy
  admin" (no admin registry configured on
  production — fail-closed by configuration, an
  operator decision), Evaluate ALLOW with proof
  policy_version 1, VerifyProof valid; audit log
  at 1,430 entries with whole-log verification
  still reporting the historical break at position
  557 (pre-fix history, stands as recorded), and
  the release certified itself on production —
  certificate cert-20261028-000039 (guardian-mesh
  0.11.0, PASS WITH FINDINGS, evidence = the gate
  verdict sha256 a2f06539…), fingerprint recomputes,
  VerifyProof valid, supersedes cert-20261027-000038,
  status ACTIVE. Deploy note: gm-deploy's box E2E
  scored 15/16 — its Health check still expects the
  retired pre-WO-19 constant 18/18 and its bundled
  client does not decode Health field 6; the
  daemon's measured-counter behaviour was proven
  directly in the production wire proof, and
  box-e2e.mjs was left byte-identical to its
  pre-run state with the stale check filed as a
  harness finding. v0.11.0 is a RELEASE CANDIDATE
  (one-week watched soak, RC register entry;
  graduates 2026-11-03). Part C continues (WO-19,
  WO-10, WO-11, WO-12 done). Next: WO-14 (P2, Part
  C fifth in order — boundary authenticators).
  Standing: dependabot PR #51 (vite bump) still
  open, outside the work orders.
- 2026-10-28 — **WO-14 shipped as v0.12.0** (PR #73, merged
  0306cfd1; merged tree 80190737 == gated tree): boundary
  authenticators — authenticator framework classifying
  ML_DSA_65 / HMAC_SESSION / SPIFFE_X509
  (workload-attestation) / OPENPGP by factor and assurance
  (AZ-11); SPIFFE SVID attestation at the handshake (DER
  leaf validation, SAN-equality, trust-domain allowlist,
  validity window, possession proof bound to the session
  ML-DSA key; GUARDIAN_MESH_REQUIRE_SPIFFE fail-closed
  naming SPIFFE_X509 per BM-11); OpenPGP (Ed25519) second
  factor for enrolled admins on policy and revocation
  propose/approve; AuthenticatorStatus RPC (service index
  15) + Dashboard Boundary Authenticators section. NOT in
  v1 (declared in the CHANGELOG): SPIFFE trust-bundle
  chain verification (AZ-3 TARGET → PARTIAL) and mTLS
  transport termination. Release gate: PASS WITH FINDINGS
  (scanner BLOCKED only on the dispositioned block-buffer
  advisory, F1 — needs a panicking caller-supplied
  compress callback, the daemon registers none; fix
  exists only under digest 0.11). Lane evidence failure
  (F2): the lane's commit did not compile its bin tests
  (81 errors), all 16 of its authenticators tests failed,
  and the WebUI caller was broken; Wright carry fixed
  everything, including three production defects (F3):
  civil-date math ≈93 days off in SVID validity windows,
  the OpenPGP EdDSA construction (OpenPGP verifies over
  the digest bytes), and the signature R MPI form; plus
  8 integration tests (F4: gmClient caller). Wright-verified:
  cargo 185/185 (128 lib + 57 bin), WebUI build (drift
  guard 13 versions) + lint, wire proof 24/24 local and
  15/15 on production. Build deviation: pwsh on the
  laptop was wedged all night — the build still ran on
  the laptop via a cmd + Python CREATE_BREAKAWAY_FROM_JOB
  launcher (OpenCode exit 0). Filed GMSI-93, GMSI-94,
  GMSI-95 (above) from this run. Deployed to
  guardian.aimlds.org via gm-deploy (its build leg is
  broken — shell string run shell=False — so the deploy
  ran its documented --binary path with the exact printed
  cross-build command): aarch64 binary sha256 30b823b7…,
  rollback guardian-meshd.bak-v0110 + webui-dist.bak-v0110
  kept; production fingerprint dd2cf1a3… unchanged
  (twelfth upgrade); box webui-dist carrying
  index-nCDEk1v1.js == Wright's build and == the Pages
  asset; Access intact (302 to the Cloudflare Access login, verified from the box after two browser windows closed without a result; the public Pages /releases serves the 0.12.0 bundle index-nCDEk1v1.js — a live-browser read returned the profile's PWA service-worker cache of 0.11.0, a known artifact class, superseded by the direct served-asset read); self-certification
  cert-20261029-000040 (0.12.0, PASS WITH FINDINGS,
  evidence = gate verdict sha256 6eacbbf5…), superseding
  cert-20261028-000039; audit history break at position
  557 stands as recorded. gm-deploy's box E2E scored
  15/16 on the standing stale Health check (harness
  finding, third occurrence). v0.12.0 is a RELEASE
  CANDIDATE (one-week watched soak, RC register entry;
  graduates 2026-11-04). Part C continues (WO-19, WO-10,
  WO-11, WO-12, WO-14 done). Next: WO-13 (P2, Part C
  sixth in order — guardian attestation package).

- 2026-10-29 — **WO-13 shipped as v0.13.0** (PR #75, merged
  95f3fcac; merged tree 98ba7e9f == gated tree): guardian
  attestation package — build identity embedded by build.rs
  (git commit + SOURCE_DATE_EPOCH); HealthResponse appends
  build_version / build_commit / binary_sha256 (fields 7/8/9;
  the SHA-256 of the running executable, computed at runtime);
  attestation.rs provenance (in-toto/SLSA-v1 shape, canonical
  JSON, ML-DSA-65 sealed envelope, fail-closed verify in five
  named checks); gm-attest CLI (build/sign/verify);
  scripts/reproducible-build.sh; docs/ATTESTATION.md;
  Dashboard Guardian Attestation section. NOT in v1 (declared
  in the CHANGELOG): SLSA L3, transparency log, TPM measured
  boot — CP-19/CP-21/DC-17 TARGET → PARTIAL. Release gate:
  PASS WITH FINDINGS (scanner BLOCKED only on the
  dispositioned block-buffer advisory GHSA-qwgh-2vcv-g2f7,
  WO-14 F1). Wright-verified: cargo 193/193 (136 lib + 57 bin,
  Linux; lane Windows 134+1 PGP-fixture fail that passes on
  Linux/CI, bin suite Defender-blocked — GMSI-97), WebUI build
  (drift guard 14 versions) + lint, reproducible build —
  two clean builds IDENTICAL (SHA-256 a39725c6…) after the
  Wright carry fixed the lane's unrun script (F1, GMSI-96),
  gm-attest VALID / tamper-INVALID, Health wire proof exact.
  Deployed to guardian.aimlds.org via gm-deploy --binary:
  aarch64 binary sha256 f604dd67…, rollback
  guardian-meshd.bak-v0120 + webui-dist.bak-v0120 kept;
  production fingerprint dd2cf1a3… unchanged (thirteenth
  upgrade); box dist asset index-D5vvP-yQ.js == Wright's
  build == Pages asset; Access intact (302); production
  daemon reports binary_sha256 == the installed binary's
  real SHA-256 (f604dd67…) and build_commit 95f3fcac;
  the release attestation package was signed on the box
  with the production daemon key (signer fingerprint ==
  the pinned dd2cf1a3…), verified VALID against the
  installed binary, and published on the box at
  /opt/guardian-mesh/guardian-meshd-0.13.0.attestation.json;
  self-certification cert-20261030-000041 (0.13.0, PASS
  WITH FINDINGS, evidence = gate verdict sha256 8668cc8b…),
  superseding cert-20261029-000040. gm-deploy's box E2E
  scored 15/16 on the standing stale Health check (harness
  finding, fourth occurrence). v0.13.0 is a RELEASE
  CANDIDATE (one-week watched soak, RC register entry;
  graduates 2026-11-05). Part C continues (WO-19, WO-10,
  WO-11, WO-12, WO-14, WO-13 done). Next: WO-15 (P2, Part C
  seventh in order — multi-tenancy). Standing: dependabot
  PR #51 (vite bump) still open, outside the work orders.

- 2026-10-31 — **WO-15 built and merged as v0.14.0; deploy
  ROLLED BACK at production proof (gate F6)** (PR #78, merged
  f4437192; merged tree d55376ce == gated tree): multi-tenancy
  — tenant registry (GUARDIAN_MESH_TENANTS env), per-tenant
  policy bundles, ML-DSA key bindings, rate budgets and
  hash-chained audit partitions; handshake carries tenant_id
  (proto fields appended only); cross-tenant reads require
  ≥2 confirmations (BM-3) and leak zero numbers on refusal;
  new TenantStatus RPC; WebUI Multi-tenancy section;
  docs/MULTI_TENANCY.md. DC-15/DC-16 [TARGET] → [PARTIAL].
  Declared v1 limits: single-node in-process; budgets and
  partitions in-memory (reset on restart); no process
  isolation (CP-14 SC-39 not claimed); no tenant-policy
  admin RPC. Release gate: PASS WITH FINDINGS (F1 lane tree
  did not compile — fixed in Wright's carry, honestly
  reported by the lane; F2 gmClient tenantId — GMSI-98;
  F3 audit-partition appends on BLOCK/THROTTLE paths —
  GMSI-99; F4 bogus-session budget burn, OPEN fodder;
  F5 in-memory tenant state, OPEN declared). Wright-verified:
  cargo 213/213 (148 lib + 65 bin; baseline 193, +20 WO-15),
  WebUI build (drift guard 15 versions) + lint, raw
  gRPC-web wire proof 10/10 against a two-tenant daemon.
  Deployed via the gm-deploy sequence executed on the box
  (this VM's sandbox denies zig file writes — a
  VM-replacement policy change; the aarch64 binary,
  sha256 00f9a4e7…, was cross-built on the owner's laptop
  from merged main, and gm-deploy's own build leg remains
  broken — standing fodder): direct production proof of
  v0.14.0 was clean (Health SERVING, build_commit
  f4437192, binary_sha256 == installed, fingerprint
  dd2cf1a3… unchanged, TenantStatus summary [default]) BUT
  the box E2E scored 14/16 — PF-18 burst FAILED
  (allowed=89 throttled=0 other=26 vs v0.13.0's 100/15/0):
  the tenant budget runs before the Gatekeeper and converts
  burst excess into resource_exhausted errors, breaking the
  WO-5 THROTTLE-verdict contract (gate F6, GMSI-100).
  Production rolled back the same night to v0.13.0
  (guardian-meshd.bak-v0130 + webui-dist.bak-v0130
  restored; post-rollback E2E 15/16, PF-18 PASS, Health
  0.13.0/f604dd67…, Access 302). v0.14.0 is NOT deployed,
  NOT attested, NOT certified, no RC entry; v0.13.0's soak
  still graduates 2026-11-05. Standing corrections: PR #51
  merged before this run (main bf6126c8); dependabot PR #77
  (fast-uri + serialize-javascript) is the open one, outside
  the work orders — owner's call pending. Part C continues
  (WO-19, WO-10, WO-11, WO-12, WO-14, WO-13 done; WO-15
  merged, completion pending WO-15.1). Next: WO-15.1 (P1 —
  tenant-budget ordering fix, completes WO-15).

- 2026-11-02 — **WO-15.1 shipped as v0.14.1** (PR #81, merged b8d5d067):
  tenant-budget ordering fix completing WO-15 (gate F6 / GMSI-100),
  plus a defect the ordering fix exposed: WO-15's budget was a
  LIFETIME quota whose default (100) matched a per-second rate, so
  Gatekeeper-allowed calls permanently drained the tenant. RateBudget
  is now a true per-window rate budget (default window 1000 ms,
  GUARDIAN_MESH_TENANT_BUDGET_WINDOW_MS / tenant_budget_window_ms);
  TenantStatus used/remaining report the current window. The budget
  check runs AFTER Gatekeeper evaluation and gates only allowed
  requests; THROTTLE and BLOCK verdicts never consume budget and are
  never converted to resource_exhausted. F4 proven closed: a request
  with an unknown session id is rejected permission_denied with
  budget_used unchanged (regression test in tree). Wright-verified:
  cargo test 216/216 (baseline 213, +3), WebUI build + lint green,
  production harness twice at PF-18 PASS allowed=100 throttled=15
  other=0 (the exact v0.13.0 mix). Release gate: PASS WITH FINDINGS
  (F1 lane burst test flaky by construction — replaced with a
  deterministic ordering test, fixed; F2 the lifetime-quota defect,
  fixed; F3 stale Health check in the box harness, OPEN standing;
  F5 tenant state in-memory only, OPEN declared). Deployed to
  guardian.aimlds.org the same night via gm-deploy --binary
  (aarch64 sha256 4afff018…, cross-built on Wright's VM from
  merged main — the VM image lacks protoc, fetched 25.1 into
  the run dir; rollback guardian-meshd.bak-v0130 +
  webui-dist.bak-v0130 kept, bak-v0130 sha256 == the v0.13.0
  binary): box E2E 15/16 with PF-18 PASS (100/15/0) — gm-deploy
  exited "NOT certified" on the F3 stale check alone, and
  certification rests on the direct proof (Health SERVING,
  build_version 0.14.1, build_commit b8d5d067, binary_sha256
  == installed; TenantStatus summary [default]; both services
  active; Access 302; box dist asset == Wright's build ==
  Pages asset); attestation package VALID against the
  installed binary, signer fingerprint == the pinned
  dd2cf1a3…, published on the box; self-certification
  cert-20261103-000042 ACTIVE (evidence = gate verdict
  sha256 e2be4d42…), superseding cert-20261030-000041.
  v0.14.1 RC graduates 2026-11-09 on a clean week. WO-15 is
  COMPLETE. Standing fodder unchanged: PR #77 (dependabot)
  open — owner's call. Part C continues (WO-19, WO-10,
  WO-11, WO-12, WO-14, WO-13, WO-15 done). Next: WO-16 (P2,
  Part C eighth — clustered verdicts + degraded modes).

GMSI filed by this run's own gate: GMSI-112 — wall-clock-window
contracts (rate limiters, budget windows, freshness windows) must be
tested by controlling the window or the clock, never by racing real
time from a unit test; scale/volume contracts belong to the
production harness, unit tests prove ordering deterministically.
(Tonight's lane burst test failed exactly this way: sequential
pre-signed envelopes aged past the PF-15 5 s window before reaching
the rate window, and a concurrent variant raced the 1 s window
under full-suite CPU contention.)

WO-16 v1 slice run (2026-11-03, ninth nightly entry in this
ledger's run history): pack refreshed first (PR #83, GMSI-113…116).
Sources: no open issues; PR #77 (dependabot) open, owner's call.
WO-16 built on the laptop in a fresh clone (lane: OpenCode
big-pickle; lane's first completion claim overclaimed a commit —
caught by tree inspection, finished by a continuation pass,
commit 24d45f3). Wright verification: cargo 223/223 at v0.15.0
(227/227 at the v0.15.1 carry), WebUI build + lint green, normal
wire proof 3/3, degraded wire proof 8/8 (BLOCK rule DC-4, proof
issuing_node == Health node_id), DC-5 entry/exit proof on the
wire incl. marker lifecycle, audit-chain trigger proven by
single-byte log corruption. Gate PASS WITH FINDINGS
(guardian-mesh-wo16-2026-11-03): F1 PF-18 local environmental
(A/B-proven against a v0.14.1-base binary on the same VM —
production proof governs); F2 pre-auth DC-4 BLOCKs → GMSI-117;
F3 box-e2e stale Health check (OPEN, 8th occurrence); F4 (gate
addendum) the production audit history's 2026-10-26/27
concurrent-writer interleave (OPEN standing; never rewritten).
Shipped: PR #84 merged e741ca35 (v0.15.0) — deployed and ROLLED
BACK the same night (startup full-chain check vs the production
archive; box restored to v0.14.1, E2E 15/16 PF-18 PASS); fix
PR #85 merged 12212cce (v0.15.1, startup check scoped to the
live tail segment, proven against a copy of the real production
log before redeploy) — deployed, box E2E 15/16 PF-18 PASS
(100/15/0), Health SERVING / degraded=false / node_id
node-dd2cf1a350e0, binary sha256 02350e06… == installed ==
attested; attestation VALID signer == pin (one wrong-key
package caught by the pin check and re-signed; throwaway key
removed, never used by the daemon); self-cert
cert-20261104-000044 ACTIVE (evidence verdict+addendum
eb8fda18…). RC entry filed; v0.15.1 in soak to 2026-11-10;
v0.15.0 never entered soak. NOT RUN: cargo audit (tool absent),
Kali/Arch benches (not built, standing). Standing fodder carried:
PR #77 (owner's call); F3 stale harness check; gm-attest
--key-file parent-dir trap (it takes a key FILE path and uses
its parent — passing a directory silently generates a new key
one level up); WO-15 F5 in-memory tenant state. Next: WO-17
(P2, Part C ninth — conformance suite + chaos drills). WO-16
stays open for the DC-1/DC-3 cluster slice.

GMSI filed by this run's own gate: GMSI-117 (pre-authentication
degraded/BLOCK verdicts are a declared policy surface) and
GMSI-118 (startup/deploy integrity gates proven against the
production data they will judge).

WO-17 v1 run (2026-11-04, tenth nightly entry in this ledger's
run history): pack refreshed first (PR #87, GMSI-119). Sources:
no open issues; PR #77 (dependabot) open, owner's call. WO-17
built on the laptop in a fresh clone (lane: OpenCode big-pickle;
first session died on a TLS handshake error after editing, before
committing — a continuation pass reconciled the tree against the
task and committed 1005ccb; the continuation's own summary
overstated the file set and was corrected by Wright's direct diff
read: 8 files, +961/-3, main.rs +855/-0 tests-only). Wright
verification: cargo 240/240 (baseline 227, +13 conformance),
conformance filter 13/13, WebUI build + lint green, process-level
SIGKILL chaos proof 7/7 (restart SERVING, node_id stable;
corrupted-tail process leg NOT RUN — a Health-only workspace
holds no persisted audit log; proven in-suite), local box-e2e
14/16 (PF-18 local-environmental; stale Health check). Gate PASS
WITH FINDINGS (guardian-mesh-wo17-2026-11-04): F1 PF-18 local
environmental; F2 box-e2e stale Health check (OPEN, 9th
occurrence); F3 no per-request escalation approval path exists
(-> GMSI-120); F4 PF-15 exact 5000/5001 ms edge unexercised
(accepted, GMSI-112). Shipped: PR #88 merged 1aee18bc (v0.16.0);
box E2E 15/16 with PF-18 PASS (100/15/0) — gm-deploy's "NOT
certified" rests on F2 alone, as in the three prior releases;
production proof governs. Live: Health SERVING, degraded=false,
node_id node-dd2cf1a350e0, build 0.16.0@1aee18bc, binary sha256
a4f0cd98... == installed == attested; attestation VALID, signer
== pin dd2cf1a3...; self-cert cert-20261105-000045 ACTIVE
(evidence a851062b...); box dist asset index-DMSGxZF5.js ==
merged build == Pages asset; guardian.aimlds.org unauthenticated
302. RC entry filed; v0.16.0 in soak to 2026-11-11. NOT RUN:
cargo audit (tool absent), Kali/Arch benches (not built,
standing). Standing fodder carried: PR #77 (owner's call); F2
stale harness check; gm-attest --pin flag (WO-13 F3); WO-15 F5
in-memory tenant state; laptop->box bundle scp has no trust route
(base64-over-lane file recovery used instead). Next: WO-18 (P3,
Part C tenth — deployment matrix, sidecar form first). WO-17
stays open for the cluster chaos + CM-8 extensions (WO-27).

GMSI filed by this run's own gate: GMSI-120 (an escalated verdict
must have a provable resolution path, or be declared terminal).

WO-18 profile 1 retry run (2026-11-06, eleventh nightly entry):
the 2026-11-05 BLOCKED gate's single missing leg — the built
image — was produced and behaviour-proved, clearing the way to
ship v0.17.0. Sources: pack unchanged on main; the day's other
main commits (CI workflows, NOTICE, TEST-PLAN.md, one WebUI
page) carry no daemon-code delta — guardian-meshd/src verified
byte-identical between the gated tree and the merged tree. No
new Guardian Mesh Spec Inputs arrived; no pack refresh was
needed ahead of the build. Venue: the laptop's Docker Desktop
pulls fail identically from the SSH lane (interactive-session
credential binding; zero cached images), so the image was
built on Wright's VM with podman 4.9.3 (nested user namespace:
crun + cgroupfs manager + host networking; registry pulls via
the egress proxy's mirror cache; the proxy CA was
volume-mounted into the builder stage only — a build-time
mount, not a Dockerfile change and not in the image). Container
proof: guardian-mesh:0.17.0, 83.2 MB; Health SERVING, PF
18/18, build 0.17.0@9bda0b22; signed Evaluate ALLOW, proof
VALID; container box-e2e 15/16 fresh-boot (sole miss PF-18
burst timing on the contended sandbox VM); restart on the
same volume kept fingerprint e329cadb.../node and the
pre-restart proof verifies VALID after it; daemon uid 10001;
image env carries no secret. Wright re-verification on the
gated tree and again on the stamped tree: cargo 240/240,
conformance_ 13/13, WebUI ci+build+lint green; scanner PASS
(0 secrets, 0 vulns). Gate PASS WITH FINDINGS
(guardian-mesh-wo18-retry-2026-11-06): F1 PF-18
local-environmental (standing class); F2 base-image tags
float (low, standing); F3 one podman restart cycle SIGKILLed
under sandbox memory pressure (exit 137, OOMKilled=false, no
daemon error; plain start stable — environmental, not a
product finding); F4 the v0.16.0 public release-log entry
still carried TBD stamps on main — filled from its gate pack
in the same stamp carry. Stamps: CHANGELOG [0.17.0] dated
2026-11-06 (the ship date; the 2026-11-05 gate was BLOCKED,
so the lane's 2026-11-05 date would have been a false claim)
with tests + gate lines; release-log entries for 0.17.0 and
0.16.0 stamped. Shipped: PR #91 merged 3dd6aeb9 (CI green
incl. CodeQL; require-pr fails on the merge commit itself, as
it is not a PR — it passed on the PR pre-merge); cross-built
aarch64 via cargo-zigbuild (zig 0.13.0 fetched to the run dir;
gm-deploy's in-process build step cannot run its shell-string
command in this sandbox — the standing --binary route was
used); box E2E 15/16 with PF-18 PASS (100/15/0) — gm-deploy's
"NOT certified" rests on the stale Health-fields check alone,
as in prior releases; production proof governs. Live: Health
SERVING, degraded=false, node_id node-dd2cf1a350e0, build
0.17.0@3dd6aeb9, binary sha256 a2374b93... == installed ==
attested; attestation VALID, signer == pin dd2cf1a3...,
package at /opt/guardian-mesh/guardian-meshd-0.17.0.
attestation.json; self-cert cert-20261107-000046 ACTIVE
(evidence = retry verdict sha256 69629475...); box dist asset
index-m1MnmXPN.js (sha256 030f0f09...) == merged build ==
Pages asset; guardian.aimlds.org unauthenticated 302. RC
entry filed; v0.17.0 in soak to 2026-11-13. NOT RUN: kubectl
dry-run (no cluster context), cargo audit (tool absent; OSV
covered), Kali/Arch benches (not built, standing). Standing
fodder carried: PR #77 (owner's call); stale harness check
(10th occurrence); base-image digest pinning for the sidecar
form. Next: WO-18 profile 2 (DP-6 edge profile). WO-18 stays
open for profiles 2-4; WO-17 stays open for the cluster chaos
+ CM-8 extensions (WO-27); WO-16 stays open for DC-1/DC-3.

Guardian Mesh Spec Inputs filed by this run: none.

WO-18 profile 2 run (2026-11-07, twelfth nightly entry):
WO-18 profile 2 (DP-6 edge profile) built, verified, gated
and shipped as v0.18.0. Sources: main at run start 3d38e0c7
(unchanged since the 2026-11-06 ledger merge); pack 138,866 B
identical; open PRs only #77 (dependabot, owner's call,
untouched); no open issues; the day's four gate filings
(linktary-internal, verdict-internal, sovereign-internal,
play-mirror) grep-verified to carry no Guardian Mesh Spec
Inputs — no pack refresh was needed ahead of the build.
Build: laptop ONLINE (OpenCode 1.19.5); fresh clone
D:\guardian-mesh-work\wo18edge at 3d38e0c7, branch
wright/wo18-edge-profile; lane (free Zen big-pickle) produced
one commit, 9 files +409/-3, zero Rust files; tree recovered
by bundle, pushed tree 03f1da1b == lane tree asserted. The
lane's result file is honest and substantive: no daemon
ceiling setting exists (ceilings stay with the runtime), the
unset-port fallback is find_free_port() (the artifacts set
50051 explicitly), and the env example keeps the handshake
secret comment-only because an empty assignment would set an
empty secret. Wright verification on the pushed tree: cargo
240/240 (workspace root), conformance_ 13/13, WebUI
ci+build+lint green; scanner PASS (0 secrets, 0 vulns) on
the gated and stamped trees; systemd unit parse-verified
(systemd-analyze), compose YAML-verified. Behaviour proof:
image from the shipped Dockerfile unmodified (83.2 MB,
binary sha256 bcf9167d... == self-reported); container
Health SERVING 0.18.0@53cafe11, Evaluate ALLOW + proof
VALID, box-e2e 14/16; same-volume re-run kept fingerprint
589493fa... and the pre-restart proof verifies VALID (the
podman restart verb itself fails in this sandbox on a
user-lookup defect — remove+run on the same volume is the
equivalent leg). Offline: the image binary in a loopback-only
network namespace — egress to 1.1.1.1:443 and to the sandbox
proxy both "Network is unreachable" — Health SERVING,
Evaluate ALLOW, proof VALID. Footprint: RSS 5.8-10.2 MB,
peak VmHWM 10.6 MB after the burst suite, 6 threads. Gate
PASS WITH FINDINGS (guardian-mesh-wo18-edge-2026-11-07):
F1 PF-18 local-environmental (standing); F2 stale
Health-fields harness check (standing); F3 ceiling
enforcement NOT RUN (sandbox cgroup controllers not
delegated; knobs read/parse-verified, viability proven by
measured headroom) — GMSI-122 filed by this run; F4
base-image tags float (low, standing). NOT RUN also: cargo
audit (tool absent; OSV covered), Kali/Arch (not built).
Stamps carried (2111bfcf): CHANGELOG [0.18.0] tests + gate
lines, EDGE.md release record (measured footprint, offline
proof, the F3 naming), releases.ts verdict/tests — the
lane's "no measured numbers" honesty lines amended to point
at the release record they now live in. Shipped: PR #94
merged 6107c602 (CI all green incl. CodeQL on the stamped
head); cross-built aarch64 via cargo-zigbuild with
GUARDIAN_MESH_GIT_COMMIT=6107c602; gm-deploy --binary route
(first execute aborted cleanly on the missing merged-tree
WebUI dist — built, re-executed); box E2E 15/16 with PF-18
PASS (100/15/0), sole miss the standing stale Health-fields
check (11th occurrence) — gm-deploy's "NOT certified" rests
on that check alone, as in prior releases. Live: Health
SERVING, degraded=false, node node-dd2cf1a350e0, build
0.18.0@6107c602, binary sha256 3083e08d... == installed ==
attested; attestation VALID, signer == pin dd2cf1a3...,
package at /opt/guardian-mesh/guardian-meshd-0.18.0.
attestation.json; self-cert cert-20261108-000047 ACTIVE
(evidence = gate verdict sha256 a2385166...); box dist asset
index-BMYIWh8F.js (sha256 7c754e70...) == merged build ==
Pages asset; guardian.aimlds.org unauthenticated 302. RC
entry filed; v0.18.0 in soak to 2026-11-14. Standing fodder
carried: PR #77 (owner's call); stale harness check; base-
image digest pinning. Next: WO-18 profile 3 (CC-4 CLI).
WO-18 stays open for profiles 3-4; WO-17 stays open for the
cluster chaos + CM-8 extensions (WO-27); WO-16 stays open
for DC-1/DC-3.

Guardian Mesh Spec Inputs filed by this run: GMSI-122
(ceiling-enforcement venue), recorded in Part B above.

WO-18 profile 3 run (2026-11-08, thirteenth nightly entry):
WO-18 profile 3 (CC-4 CLI) built, verified, gated and shipped
as v0.19.0. Sources: main at run start 39bb194e — the only
movement since the 2026-11-07 ledger merge was PR #77
(dependabot webui npm group), merged by the OWNER himself
2026-11-08T18:55:49Z; the standing "owner's call" item is
closed by his own hand. Open PRs at start: none; open issues:
none. The day's four gate filings (linktary-checkfix,
linktary-magic-link-ttl, linktary-walkfix,
linktary-signin-mechanics) were grep-verified: only
linktary-magic-link-ttl carried a Guardian Mesh Spec Input
(counter-only, no-identifier metric for expired/used/invalid
auth callback outcomes). Filed as GMSI-123 by pack-refresh
draft PR #96 (commit d8e1a920, one-file diff verified), merged
d8e6b232; pack read-back on main: blob 680b3fea == pushed
blob, 144,905 B. (One early check-runs response for PR #96
showed a phantom failing JavaScript CodeQL run; the repo has
no JavaScript CodeQL workflow — three direct reads showed the
PR genuinely green.)
Build: laptop ONLINE (OpenCode 1.19.5); fresh clone
D:\guardian-mesh-work\wo18cli at d8e6b232, branch
wright/wo18-cli-profile. Lane run 1 died ~2 min in hunting the
tonic client API in the cargo registry (external_directory
permission auto-rejected by design; no files changed). Run 2
carried Wright's authoritative client-API reference in the
task (GuardianMeshClient::connect, proto field shapes, the
sealed-envelope/HMAC/seed idioms, "do not read outside the
project root") and completed: lane commit 439cd6b, 8 files
+1504/-4 (new gm.rs 1128 lines + docs/CLI.md; Cargo.toml
[[bin]] gm + version, VERSION, README, CHANGELOG, releases.ts,
edge compose tag; sidecar tags stayed 0.17.0 — they name their
introducing release). Lane tree 6afc2c50 == pushed tree
asserted via the bundle; the 3 apparent SFTP diffs were pure
CRLF. Lane result is candid (session-file endpoint precedence,
verify/audit sessionless, proof-file hex encoding all
disclosed). gm's contract: a verdict RETURNED in a response
(ALLOW/BLOCK/THROTTLE/ESCALATE) prints JSON and exits 0 — the
daemon's envelope-stage BLOCKs on real evaluates arrive as
permission_denied RPC errors and exit 1; simulate CODE_EXECUTE
returns its BLOCK in-response (both legs proven live).
Wright verification on the pushed tree (fresh tarball
checkout): the lane's code DID NOT COMPILE — build.rs had
.build_client(false) (server-only stubs, no client the CLI
could call), one ambiguous encode call, one unused import.
Carry fixes 91a53eeb + 1017fc42 (build_client(true); the
sealed_envelope encode idiom; import dropped) — the lane's
"no daemon change needed" note falsified by the compile
evidence, recorded on the PR and in the gate pack. After the
carry: cargo 246/246 (240 baseline + gm's 6 unit tests),
conformance_ 13/13, WebUI ci+build+lint green; scanner PASS
(0 secrets, 0 vulns, 0 must-gate failures) on the gated and
final trees. Behaviour proof (fresh local daemon on
127.0.0.1:50061, driven only through the built gm): health
SERVING 0.19.0; handshake exit 0, session file mode 600, no
session_key/seed in stdout; evaluate TOOL_CALL ALLOW + proof
saved; verify VALID; one flipped payload byte -> invalid exit
1 (CRC reason); audit 1 entry chain verified; no-session
evaluate exit 2 (empty stdout, stderr names handshake);
simulate CODE_EXECUTE BLOCK JSON exit 0 and its proof verifies
VALID; real CODE_EXECUTE BLOCK JSON exit 0 (Arbiter-stage);
unreachable health exit 2 empty stdout.
Gate PASS WITH FINDINGS (guardian-mesh-wo18-cli-2026-11-08):
F1 compile carry (High, fixed, above); F2 (Low, open)
evaluate stdout does not name the proof file; F3 base-image
tags float (low, standing). NOT RUN: cargo audit (tool
absent; OSV covered), Kali/Arch (not built).
Stamps carried (923c7073): CHANGELOG [0.19.0] tests + gate
lines, releases.ts tests + gateVerdict — the lane's
unverified numbers replaced with the verified ones; CI on
the stamped head all green (PR Gate, Rust CI, WebUI CI,
CodeQL Rust). Shipped: PR #97 merged f25cfd51; merged-tree
gm.rs + build.rs sha256-identical to the gated tree;
cross-built aarch64 via cargo-zigbuild with
GUARDIAN_MESH_GIT_COMMIT=f25cfd51 (the gm binary cross-built
in the same invocation — CC-4's acceptance includes the CLI
artefact itself); gm-deploy --binary route; box E2E 15/16
with PF-18 PASS (100/15/0), sole miss the standing stale
Health-fields check (12th occurrence) — gm-deploy's "NOT
certified" rests on that check alone, as in prior releases.
Live: Health SERVING, degraded=false, node
node-dd2cf1a350e0, build 0.19.0@f25cfd51, binary sha256
e280e5c8... == built == installed == attested; attestation
VALID, signer == pin dd2cf1a3..., package at
/opt/guardian-mesh/guardian-meshd-0.19.0.attestation.json
(signed on the box with the production key under
/home/ubuntu/guardian-mesh-data/workspace/keys/); self-cert
cert-20261109-000048 ACTIVE (evidence = gate verdict sha256
b93b379c...); gm (aarch64, sha256 e37a8455...) proven against
the production daemon on the box: health/handshake/evaluate
ALLOW/verify VALID; audit read reports the standing F4
interleave at entry 557 (documented since v0.15.1; live tail
clean). Box dist asset index-D1IKKPA3.js == merged build ==
Pages asset; guardian.aimlds.org unauthenticated 302. RC
entry filed; v0.19.0 in soak to 2026-11-15. Standing fodder
carried: stale harness check; base-image digest pinning; the
F4 production audit-history interleave (never rewritten, by
design). Next: WO-18 profile 4 (CC-5 MCP server surface) —
the LAST WO-18 profile; WO-18 closes when it ships.
WO-18 stays open for profile 4; WO-17 stays open for the
cluster chaos + CM-8 extensions (WO-27); WO-16 stays open
for DC-1/DC-3.

Guardian Mesh Spec Inputs filed by this run: GMSI-123
(auth-callback outcome counters, via the refresh PR) and
GMSI-124 (operator-surface smoke proof), recorded in Part B
above.

WO-18 profile 4 run (2026-11-09, fourteenth nightly entry):
WO-18 profile 4 (CC-5 MCP server surface) built, verified,
gated and shipped as v0.20.0 — WO-18 COMPLETE. Sources: main
at run start c7336781, identical to the 2026-11-08 ledger
merge; open PRs none; open issues none. Gate filings since
2026-11-08: eight packs dated 2026-11-09, grep-verified —
four Conduit packs carried nine Guardian Mesh Spec Inputs
(buyerfix 2, buyerfix2 2, buyerfix3 1, conduit-credits 4);
the gate-agent and axiomcode packs filed none. Filed as
GMSI-125..133 by pack-refresh draft PR #99 (one-file diff
verified, 59 lines), merged 1601ba77; pack read-back on main:
blob a9a8789c == pushed blob, 157,828 B.
Build: laptop ONLINE (OpenCode 1.19.5; the lane ran via the
fdroid-venv python after the VM refresh dropped system
paramiko); fresh clone D:\guardian-mesh-work\wo18mcp at
1601ba77, branch wright/wo18-mcp-profile. Lane run 1 died
~10 min in on a lane TLS error (EPROTO) after writing
gm-mcp.rs (1,048 lines) and the Cargo.toml bump. Run 2
reviewed both, completed the remaining deliverables
(docs/MCP.md, scripts/smoke.sh + smoke_mcp.py, version
surfaces, CHANGELOG, CLI.md sentences, RESULT) and committed
b7d3ae6 (11 files +2036/-8) — but its git push FAILED: the
fresh clone carries no GitHub credentials. Wright carried
the push: bundle from the laptop, git-data API push, then a
mode-fix commit restoring the two scripts' 100755 bits —
final pushed tree 41ce166c == lane tree exactly, commit
ca0f73e4 (gate F1, process class; a credentialed push route
for fresh laptop clones is the structural fix owed).
Wright verification (fresh checkout of the pushed tree):
cargo test 257/257 (154 lib + 86 bin + 6 gm + 11 gm-mcp —
the lane's code compiled and passed AS WRITTEN, contrast
the 2026-11-08 compile carry), conformance_ 13/13, WebUI
ci+build+lint green; scanner PASS (0 secrets / 0 vulns /
0 must-gate). Behaviour proof: the in-repo GMSI-124 smoke
(scripts/smoke.sh) against a local daemon built from the
verified tree — 9/9 PASS; Wright's direct stdio probe:
malformed line -> -32700 (id null) and the server continues,
unknown method -> -32601, initialize echoes 2025-03-26 with
serverInfo version 0.20.0, simulate evaluate -> ALLOW with
the proof_envelope round-tripping into guardian_verify, one
flipped payload byte -> valid=false, missing action_type ->
isError naming the field, ping answers last. Deep review:
exactly the 11 named files; no daemon source, no gm.rs, no
main.rs touched; no new dependencies; session key/seed have
no print/log path (three eprintln sites are startup/IO
diagnostics); licence named "Apache License 2.0 plus the
Payment Rider" (the word "unmodified" appears only inside
the prohibition sentence in docs/MCP.md).
Gate PASS WITH FINDINGS (guardian-mesh-wo18-mcp-2026-11-09):
F1 lane push carry (above); F2 base-image tags float (low,
standing). GMSI-134 filed (panel-action smoke — the last
unabsorbed GMSI-124 surface). Verdict + counts stamped into
CHANGELOG [0.20.0] and releases.ts before merge (commit
1956b7fe); CI on the stamped head all green (PR Gate, Rust
CI, WebUI CI, CodeQL Rust).
Shipped: PR #100 merged 6f107e4f55ef882414c74ff53a50b4a019d26cb5.
Cross-built aarch64 (cargo-zigbuild, GUARDIAN_MESH_GIT_COMMIT=
6f107e4f): daemon sha256 0503ce5d..., gm c3afa235...,
gm-mcp c866fd55.... gm-deploy --binary route: backup
.bak-v0190 taken, both services active, box E2E 15/16 with
PF-18 PASS (100/15/0); sole miss the standing stale
Health-fields harness check (13th occurrence) — gm-deploy's
"NOT certified" rests on that check alone, as in prior
releases. Direct production proof: Health SERVING,
fingerprint == pin dd2cf1a3..., degraded=false, node
node-dd2cf1a350e0, build 0.20.0@6f107e4f, binary sha ==
built == installed. Self-cert cert-20261110-000049 ACTIVE
(evidence = gate verdict sha256 93478f4c...), superseding
cert-20261109-000048. Attestation: statement built against a
real clone at 6f107e4f with the cross-build Cargo.lock
(0465d039...); signed on the box with the production key;
ATTESTATION VALID, signer == pin; installed at
/opt/guardian-mesh/guardian-meshd-0.20.0.attestation.json.
gm AND gm-mcp proven against the production daemon on the
box: gm health/handshake/evaluate ALLOW/verify VALID;
gm-mcp live legs 6/6 via the shipped smoke driver. gm audit
reports the standing F4 interleave (first break at entry
557; live tail clean by design since v0.15.1). Pages parity:
box dist asset index-Ckz33qtb.js == merged build == GitHub
Pages asset; guardian.aimlds.org unauthenticated 302. RC
entry filed; v0.20.0 in soak to 2026-11-16.
Run incident (Wright's, disclosed): a `--version` probe
against the installed daemon binary accidentally BOOTED a
second daemon instance on the box (the binary has no
--version flag) on a loopback ephemeral port; discovered
within ~2 minutes and killed by PID; no writes from it
appear in the production workspace (audit dir mtime predates
it) and the production proof above is clean. Lesson filed:
never probe the daemon binary with flags it does not have.
Standing fodder carried: stale harness check; base-image
digest pinning; the F4 production audit-history interleave
(never rewritten, by design); the credentialed-push-route
fix owed (F1). Next: WO-18 is CLOSED. The pack's next
highest-priority unfinished work follows Part C/D order —
WO-19 (firewall session eviction + measured Health
counters) heads Part C; WO-17 stays open for the cluster
chaos + CM-8 extensions (WO-27); WO-16 stays open for
DC-1/DC-3.

Guardian Mesh Spec Inputs filed by this run: GMSI-125..133
(2026-11-09 Conduit gate rounds, via the refresh PR) and
GMSI-134 (panel-action smoke proof), recorded in Part B
above.
- 2026-11-10 (daytime) — **WO-19 COMPLETE as v0.21.0**
  (PR #102, merged 003524e1; daytime instance of the nightly
  program, owner-directed "Continue"): the WO-19 completion
  slice — GMSI-7 pf_outcomes wiring. Note on work-order
  determination: the pack's 2026-11-09 "Next: WO-19" line
  named work this same pack records as SHIPPED 2026-10-24
  (v0.8.5, eviction + Health counters); that entry's own
  named follow-up — wiring the measured counters into WO-6
  certificates (GMSI-7) — is what this run built. Built on
  the laptop lane (claude-sonnet-4-5, commit 51a8d557 tree
  1f5c1ecd); carried by Wright (git-data API, tree equality
  asserted) as 229797f1 + verification stamp 2f44f850.
  Change: ProtocolFirewall::pf_outcomes_string() (None on
  empty counters; canonical BTreeMap-ordered string),
  issue_certificate pf_outcomes parameter sealed + stored,
  IssueCertificate handler snapshot; schema doc updated,
  schema_version stays 1 (reserved-field population);
  pf_outcomes=None omits the field (pre-0.21.0 payload
  shape preserved). Wright independent verification (fresh
  checkout, never the lane's numbers): cargo 261/261 (257
  baseline + 4 new), conformance_ 13/13, WebUI ci/build/
  lint + check:releases green. Wire proof 18/18 against a
  local daemon from the verified tree: unmeasured-daemon
  certificate carries NO pf_outcomes; after 3 real gm
  evaluates the next certificate's sealed pf_outcomes
  equals the Health counters exactly; fingerprint,
  ML-DSA-65, supersession, tamper legs pass. Gate (pack
  guardian-mesh-wo19-pf-2026-11-10): scanner PASS (0/0/0);
  verdict PASS WITH FINDINGS — F1 = GMSI-135 filed (stale
  repo-root Python stubs); F2 CodeQL 2 new cleartext-
  logging alerts in the new certificate tests (panic-path
  formatting of issuance results), fixed in-run by Wright
  (match-binding + static panic messages; assertions
  unchanged; pattern for future lanes: certificate tests
  never format issuance results/reasons into panics);
  final head 396f527f all checks green incl. CodeQL.
  Production v0.21.0 live 2026-11-10: binary sha256
  715092644689afb9df71e874bdf1a127821e52fee974af66b87
  d22c3d06723eb (cross-built from merged main), backup
  .bak-v0200 taken, both services active; box E2E 15/16
  (sole miss the standing stale Health-fields harness
  expectation — gm-deploy therefore stopped at NOT
  certified and certification proceeded on direct
  production proof, per standing practice). Direct proof
  (box client): Health SERVING 0.21.0@003524e1, binary sha
  match, degraded=false, fingerprint == pin dd2cf1a3…;
  cert-20261110-000051 ACTIVE (a first issuance,
  cert-20261110-000050, completed server-side during a
  proof-client parse crash — multi-byte protobuf tag —
  and was superseded by 000051; both carry identical
  verdict/evidence): 000051's sealed pf_outcomes equals
  the production Health counters exactly (9 rules,
  incl. failures: PF-1 125/1 … POLICY_RATE 104/15;
  totals 1061/1083), evidence = gate verdict sha256
  fdb873a494…; VerifyProof VALID. Attestation installed
  /opt/guardian-mesh/guardian-meshd-0.21.0.attestation.json,
  gm-attest verify VALID, signer == pin. Public
  unauthenticated 302; Pages parity: box-served asset ==
  merged build asset == GitHub Pages asset
  (index-DTZk_2JI.js). PR Gate failure on the merge push
  is the require-pr job asserting PR context on a push —
  structural, passed on the PR itself. Tooling findings
  for the gm-deploy route: its --source build step is
  broken (shell=False on a `cd … && …` string — use
  --binary with a Wright-built binary), and cargo-zigbuild
  needs ~/.cargo/bin + the zig dir on PATH. NOT RUN
  (standing): cargo audit (tool absent), Kali/Arch
  benches, ceiling enforcement (GMSI-122), authenticated
  panel click-through (GMSI-134). v0.21.0 is a RELEASE
  CANDIDATE (one-week soak; graduates 2026-11-17).
  GMSI-7 CLOSED by this run. **WO-19 is CLOSED.** Next:
  WO-30 (P1, docs-only threat model) heads Part D, then
  WO-22, WO-20 in pack order; WO-17 stays open for the
  cluster chaos + CM-8 extensions (WO-27); WO-16 stays
  open for DC-1/DC-3.

Guardian Mesh Spec Inputs filed by this run: GMSI-135
(repo-root Python client stubs stale), recorded in §7
above.
- 2026-11-10 (nightly) — **WO-30 SHIPPED as v0.22.0**
  (PR #105, merged c6ef0cd1; merge tree e04ca49d == the
  stamped PR head tree): the threat model of record (SG-1).
  specs/THREAT_MODEL.md (new): assets A-1..A-12, adversaries
  ADV-1..ADV-7 (SG-1's five named — malicious agent,
  compromised tenant, rogue administrator, supply-chain
  attacker, network attacker — plus hostile guarded resource
  and coercive/careless operator), the BM-1..BM-8 boundary
  map in shipped form, and threat register TM-01..TM-25,
  every countermeasure mapped to requirement IDs with honest
  [SHIPPED]/[PARTIAL]/[TARGET] status + residual risk +
  closing work order; §6 lists all 12 open risks in one
  table; TM-21 (signing key is a host file; host compromise
  is key compromise until SG-5/WO-23 and the HSM ladder/
  WO-35) is named the highest carried risk. Revised spec:
  SG-1 status [TARGET] -> [SHIPPED] (the document's
  existence; maintained per release), no other status
  changed. Version 0.22.0 on the standing surfaces. No
  daemon code, no proto, no verdict behaviour change, no
  new dependencies. Lane: the pack marks WO-30 docs-only,
  Wright lane acceptable — authored by Wright (the laptop
  was probed ONLINE at run start, LAPTOP-HTA1H418;
  availability was not the reason). Wright verification
  (authoring tree == pushed head for all 8 files, blob
  hashes asserted at push): cargo 261/261 (identical to
  the v0.21.0 baseline, as a docs-only change must
  produce), conformance_ 13/13, WebUI ci/build/lint +
  check:releases green (25 versions). Mechanical
  acceptance: 84 distinct requirement IDs cited in the
  model, 0 missing from the revised/formal specs;
  TM-01..TM-25 each exactly once; every SG-1 adversary
  carries >= 1 threat (ADV-6 treated inside TM-04/TM-05/
  TM-17, cross-referenced in §5); status claims
  spot-checked against shipped code (the WO-14
  authenticators.rs honesty header among them). Pack
  refresh first: PR #104 (merged e81a6b28; landed pack
  blob af0b784b read back byte-identical, 175,918 B)
  filed GMSI-136..142 from the 2026-11-10 gate rounds
  (Codetopo v0.9.1 GMSI-1..5 -> 136..139; Gate Agent
  v0.1.0 GMSI-GA-1..3 -> 140..142). Gate (pack
  guardian-mesh-wo30-2026-11-10): scanner PASS (0/0/0);
  verdict PASS WITH FINDINGS — F1 = GMSI-143 filed
  (revised-spec status labels lag shipped releases in at
  least seven places; the model follows the release
  record and notes the lag). Production v0.22.0 live
  2026-11-10: binary sha256 a0904704d0c37a327de95a25
  005dde7af3700e888820391870849de5bf7b1fd1 (cross-built
  from merged main c6ef0cd1, cargo-zigbuild + zig 0.14.1
  + ~/.cargo/bin on PATH, as recorded), backup
  .bak-v0210 taken, both services active; box E2E 15/16
  (PF-18 PASS 100/15/0; sole miss the standing stale
  Health-fields harness expectation, 15th occurrence —
  gm-deploy stopped at NOT certified on that bar and
  certification proceeded on direct production proof,
  per standing practice). Direct proof (Wright's own box
  client, written from the proto for this run): Health
  SERVING, 0.22.0@c6ef0cd1, binary sha == built ==
  installed, degraded=false, fingerprint == pin
  dd2cf1a3...; self-cert cert-20261111-000052 ACTIVE,
  verdict PASS WITH FINDINGS, evidence = gate verdict
  sha256 069f3204..., its sealed pf_outcomes == the
  production Health counters exactly (9 rules; totals
  1061/1083), payload fingerprint recomputes,
  VerifyProof VALID — superseding cert-20261110-000051.
  Attestation: statement built against a real clone at
  c6ef0cd1 (public-repo clone; the merge commit carries
  a GitHub gpgsig header, so the object is not
  reconstructible from the API record — the clone route
  is the reliable one) with the cross-build Cargo.lock
  (1f2c1a61...); installed
  /opt/guardian-mesh/guardian-meshd-0.22.0.attestation.json,
  gm-attest verify VALID, signer == pin, package
  fingerprint 4d734592.... Pages parity: box-served
  asset == merged build == GitHub Pages asset
  (index-C9iYm8q-.js); public unauthenticated 302. Run
  notes: (1) this VM's shell/python text writes were
  intermittently dropped to 0 bytes for ~15 min mid-run
  (binary-tool writes — cargo, npm, the gate scanner —
  unaffected; the pack read-back during the window was
  verified in-memory by blob hash, af0b784b == pushed);
  (2) a pre-existing stray /home/ubuntu/guardian-meshd
  .v080 process (PID 794125, an October binary) sits on
  the box — not the production daemon (PID 4114455),
  not touched. NOT RUN (standing): cargo audit (tool
  absent), Kali/Arch benches, ceiling enforcement
  (GMSI-122), authenticated panel click-through
  (GMSI-134). v0.22.0 is a RELEASE CANDIDATE (one-week
  soak; graduates 2026-11-17). **WO-30 is CLOSED; SG-1
  is satisfied** (maintained per release from here;
  WO-32's risk register builds on this file). Next:
  WO-22 (P1, secure by default, SG-4), then WO-20 in
  pack order; WO-17 stays open for the cluster chaos +
  CM-8 extensions (WO-27); WO-16 stays open for
  DC-1/DC-3.

Guardian Mesh Spec Inputs filed by this run: GMSI-136..142
(pack refresh, from the 2026-11-10 Codetopo + Gate Agent
gate rounds) and GMSI-143 (spec↔release status
reconciliation), recorded in Part B above.

- 2026-11-11 (nightly) — **WO-22 SHIPPED as v0.23.0**
  (PR #109, merged 0f840222; merge tree 4263f8f4 == the
  stamped PR head tree; the build commit's tree 7e9c03f2 ==
  the laptop lane's commit tree, bundle-proven): secure by
  default (SG-4). config.rs gains Posture (Production /
  Demo; GUARDIAN_MESH_POSTURE unset = production, invalid
  values fail closed and are recorded), the
  DEFAULT_HANDSHAKE_SECRET constant as the single source for
  the demo fallback + default detection (unset / empty /
  literal), posture_findings() (invalid posture blocking
  everywhere; default secret blocking in production, warning
  in demo; short secret, non-loopback production bind,
  degraded mode, SPIFFE-not-required as named warnings) and
  validate_posture(). main.rs real_main refuses to start on
  blocking findings (FATAL naming each setting, exit 1,
  before ensure_dirs); GuardianMeshService::new is NOT gated.
  gm gains the doctor subcommand (local env only, contacts
  no daemon; BLOCKING/warning lines; exit 0 / 2). Revised
  spec: SG-4 [TARGET] -> [SHIPPED] (v0.23.0 scope note); no
  other status changed. THREAT_MODEL.md unchanged — SG-1
  maintenance review performed this run: no SG-4 /
  default-secret row exists in the model. docs/CLI.md doctor
  section; env example documents GUARDIAN_MESH_POSTURE and
  the production refusal. Version 0.23.0 on the standing
  surfaces. No new dependencies; no verdict path, firewall,
  handshake-session, signing-key, or proto change. Lane:
  laptop OpenCode (fresh clone D:\guardian-mesh-work\wo22 at
  the refreshed main abe413cd; OpenCode now reports 1.19.5);
  the lane's push failed on the clone's missing credentials
  (standing pattern) and Wright carried it via bundle +
  git-data API with the pushed tree proven identical to the
  lane's commit tree. Wright verification (fresh checkout of
  the pushed branch): cargo 268/268 (165 lib + 86 bin + 11
  gm-mcp + 6 gm; baseline 261, +7 = exactly the new config
  tests), conformance_ 13/13, WebUI ci/build/lint +
  check:releases green (26 versions); behaviour proof 9/9 on
  the built binaries (production+unset refused, FATAL names
  GUARDIAN_MESH_HANDSHAKE_SECRET; production+literal
  refused; unset-posture+unset refused; invalid posture
  refused naming GUARDIAN_MESH_POSTURE; demo+default serves
  Health; production+custom serves; gm doctor exit 2/0/0
  across production-default / production-custom /
  demo-default). Pack refresh first: PR #108 (merged
  abe413cd; landed pack blob 85811161 read back
  byte-identical, 182,821 B) filed GMSI-144 from the
  2026-11-11 Conduit Router v1.5.0 gate round (the AxiomCode
  slice-2 certification of the same day files no GMSI,
  grep-verified). Gate (pack guardian-mesh-wo22-2026-11-11):
  scanner PASS (0/0/0); verdict PASS WITH FINDINGS — F1
  (Low, informational) the doctor warns SPIFFE-not-required
  against the current production configuration (the shipped
  deliberate posture; observed live on the box post-deploy:
  doctor OK exit 0 with that single warning); F2 standing
  GMSI-143 lag outside this WO. Production v0.23.0 live
  2026-11-11: production env gained
  GUARDIAN_MESH_POSTURE=production explicitly (backup
  /etc/guardian-mesh/env.bak-v0220; the box already ran a
  real 64-char handshake secret — name+length verified, the
  value never read — so no rotation was needed); binary
  sha256 3c63a7e6865933c14ade23e2451b1fd7402350f04110c307
  34cf6243b7814b21 (cross-built from merged main 0f840222,
  cargo-zigbuild 0.23.4 + zig 0.14.1 + ~/.cargo/bin on
  PATH); backup .bak-v0220 taken, both services active; box
  E2E 15/16 (PF-18 PASS 100/15/0; sole miss the standing
  stale Health-fields harness check, 16th occurrence) —
  gm-deploy stopped at NOT certified on that bar and
  certification proceeded on direct production proof, per
  standing practice. Direct proof (Wright's own box
  client): Health SERVING, 0.23.0@0f840222, binary sha ==
  built == installed, degraded=false, fingerprint == pin
  dd2cf1a3...; self-cert cert-20261112-000053 ACTIVE, PASS
  WITH FINDINGS, evidence = gate verdict sha256
  cfca8ad2..., its sealed pf_outcomes == the production
  Health counters exactly (9 rules; totals 1061/1083),
  payload fingerprint recomputes, VerifyProof VALID —
  superseding cert-20261111-000052. Attestation: statement
  built against a real clone at 0f840222 with the
  cross-build Cargo.lock (6646ab62...); installed
  /opt/guardian-mesh/guardian-meshd-0.23.0.attestation.json,
  gm-attest verify VALID, signer == pin, package
  fingerprint 12ad49a5.... Pages parity: box dist asset ==
  merged build == GitHub Pages asset (index-C5ZoEGUM.js);
  public unauthenticated 302. NOT RUN (standing): cargo
  audit (tool absent), Kali/Arch benches, ceiling
  enforcement (GMSI-122), authenticated panel click-through
  (GMSI-134). v0.23.0 is a RELEASE CANDIDATE (one-week soak;
  graduates 2026-11-18). **WO-22 is CLOSED; SG-4 is
  satisfied.** Next: WO-20 (P1, complete-mediation core) in
  pack order; WO-17 stays open for the cluster chaos +
  CM-8 extensions (WO-27); WO-16 stays open for DC-1/DC-3.

Guardian Mesh Spec Inputs filed by this run: GMSI-144
(pack refresh, from the 2026-11-11 Conduit Router v1.5.0
gate round) and GMSI-145 (negative-start proof), recorded
in Part B above.
- 2026-11-12 (daytime, Director-pulled) — **WO-DCR SHIPPED
  as v0.25.0** (PR #112, merged c8dd6ab0; merge tree
  0e43610e == the stamped PR head tree): Guardian Mesh's
  first behaviour-proof (gap-closure directive W2 / Gap 5).
  Policy content rule DCR-REDIRECT-FRAGMENT: an evaluation
  whose context JSON describes an OAuth client registration
  (redirect_uris array and/or redirect_uri string, RFC 7591)
  is BLOCKED when any redirect URI carries a fragment ('#'),
  per RFC 6749 §3.1.2 (a redirection endpoint URI MUST NOT
  include a fragment component). The verdict reason names
  the rule, the field, and the RFC basis — never the URI
  value — and the rule id rides the structured reasons into
  the sealed AuditProof.rule_ids. Arbiter precedence: below
  a type-level policy BLOCK, above ESCALATE/ALLOW; the rule
  is posture-independent (it refuses in demo and production
  alike). policy.rs gains check_content_rules (context-JSON
  inspection; unparseable context and non-registration
  payloads are untouched; no payload-shape denial exists in
  the protocol firewall to reuse — PF-21 was verified a
  queue name only, no rule). No proto change, no new
  dependencies, no signing / handshake / firewall change.
  Lane DISCLOSURE: built on Wright's VM, not the laptop
  lane — the WO-20 nightly held the laptop (a bounded lane
  probe timed out); the Director's 2026-11-03 infra-fallback
  grant covers it, and the WO-20 lane keeps the laptop.
  Sequencing: WO-20's task file claimed 0.24.0; the dated
  behaviour-proof shipped first as 0.25.0 (readiness-early:
  due 2026-11-13, landed 2026-11-12) and WO-20 re-stamps
  upward. Wright verification (fresh checkout of the pushed
  branch): cargo 280/280 (baseline 268 + exactly 12 new:
  6 policy content-rule, 4 arbiter, 2 integration incl.
  rule-inside-the-sealed-proof + VerifyProof VALID), WebUI
  ci/build/lint + check:releases green (27 versions); local
  wire rehearsal 4/4 legs PASS on the built binaries. Gate
  (pack guardian-mesh-dcr-behaviour-proof-2026-11-12):
  scanner PASS (0/0/0); cargo audit --no-fetch clean
  (174 deps, 1490 advisories); verdict PASS WITH FINDINGS —
  both findings are scope boundaries, filed as GMSI-150
  (content rules inspect context only) and GMSI-151
  (sibling DCR validations + a revised-spec row for the
  rule family). Production v0.25.0 live 2026-11-12: binary
  sha256 a5b3d22174d65e0dc6c9d162cbae4461bcadcab00bb2ea
  ec09d1ca29839b06f3 (cross-built from merged main
  c8dd6ab0, cargo-zigbuild 0.23.4 + zig 0.14.1); backup
  .bak-v0230 taken, both services active; box E2E 15/16
  (PF-18 PASS 100/15/0; sole miss the standing stale
  Health-fields harness check, 17th occurrence) —
  gm-deploy stopped at NOT certified on that bar and
  certification proceeded on direct production proof, per
  standing practice. Direct proof (Wright's own box
  client): Health SERVING, 0.25.0@c8dd6ab0, binary sha ==
  built == installed, degraded=false, fingerprint == pin
  dd2cf1a3...; self-cert cert-20261113-000054 ACTIVE, PASS
  WITH FINDINGS, evidence = gate verdict sha256
  15205c50..., its sealed pf_outcomes == the production
  Health counters exactly (9 rules; totals 1061/1083),
  payload fingerprint recomputes, VerifyProof VALID —
  superseding cert-20261112-000053. Attestation: statement
  built against the merged clone (cross-build Cargo.lock
  a117c6aa...), signed on the box with the production key
  (the key never left the box); installed
  /opt/guardian-mesh/guardian-meshd-0.25.0.attestation.json,
  gm-attest verify VALID, signer == pin, package
  fingerprint 3c26c379.... Pages parity: box dist asset ==
  merged build == GitHub Pages asset (index-BN0DNU4x.js);
  public unauthenticated 302. **THE BEHAVIOUR PROOF**
  (production, against the shipped build; driver + shipped
  gm CLI on the box): (A) fragment registration — Conduit
  POST https://mcp.pipavia.com/oauth/register answered 400
  invalid_redirect_uri; GM verdict BLOCK naming
  DCR-REDIRECT-FRAGMENT; the sealed proof contains the
  rule id; VerifyProof VALID. (B) tampered sealed payload
  (the first BLOCK verdict bytes replaced) — VerifyProof
  NOT VALID. (C) clean registration — Conduit 201 (client
  cndc_59ea109f27d0343f11eb2e08ae90312d, recorded per the
  October precedent); GM ALLOW; proof VALID. (D)
  no-answer (dead endpoint) — driver decision BLOCK,
  nothing sent. 4/4 legs PASS; evidence in the gate pack's
  production/ directory. GAPS.md Gap 5 + the directive's
  W2 row move to PROVEN-PENDING-GATE-JUDGMENT (the gate
  thread judges closure; this run does not self-close).
  v0.25.0 is a RELEASE CANDIDATE (one-week soak; graduates
  2026-11-19). Next: WO-20 (P1, complete-mediation core)
  in pack order — unchanged by this run; WO-17 stays open
  for the cluster chaos + CM-8 extensions (WO-27); WO-16
  stays open for DC-1/DC-3.

Guardian Mesh Spec Inputs filed by this run: GMSI-150 and
GMSI-151 (WO-DCR gate scope boundaries), recorded in
Part B above.

- 2026-11-13 (nightly) — **WO-20 SHIPPED as v0.26.0**
  (PR #115, merged 7510e30f; merge tree 6a10c109 == PR
  head tree): complete-mediation core. Every real
  (non-simulation) ALLOW now issues a one-time,
  ML-DSA-65-signed execution token in the pre-existing
  EvaluateResponse field 5 (handshake_token; name, type
  and number unchanged): GMET1 payload (token id, action
  hash = SHA-256 over the canonical length-prefixed
  action encoding, session, tenant, issued-at,
  expires-at), TTL 120 s, wire form u32-BE payload
  length || payload || signature. The resource-side
  ExecutionChecker refuses missing / malformed /
  bad-signature / action-mismatch / expired / replayed
  tokens with named errors and consumes the token id
  only on a fully successful check; its escrow store
  releases a credential for the action target only
  after a valid check (check_and_release); credential
  bytes never print (manual Debug = counts only).
  Escrow mode (GUARDIAN_MESH_ESCROW_MODE, default off;
  production does not enable it): an action presenting
  a credential-named metadata key is BLOCKed
  daemon-side with rule CM-1 before the Sentinel
  pipeline, the reason naming the key, never the value.
  Spec: CM-2 [SHIPPED] (v0.26.0 scope); CM-1 [PARTIAL]
  (remainder: daemon-side credential vault injection);
  CM-3 [PARTIAL] (remainder: mTLS / network-policy
  lockdown, deployment-side; conformance in WO-27).
  Threat model: TM-04's countermeasure names CM-2
  shipped, residual reduced not closed where a resource
  does not embed the checker; TM-05 stays open with
  CM-3 partial. docs/MEDIATION.md (new) carries the
  format, the checker API and an explicit not-claimed
  list. No new dependencies, no new RPCs, no CLI
  commands, no verdict-logic change beyond the CM-1
  escrow BLOCK.
  Lane + sequencing DISCLOSURE: built by OpenCode
  (big-pickle) on the owner's laptop in a fresh clone
  at refreshed main 1e9cc7f5 (lane commit 4a121f6; the
  lane's push failed on the clone's missing GitHub
  credentials and Wright carried it via bundle +
  git-data API, tree-identical). Two lane sessions died
  researching the ML-DSA signature length (registry
  reads are permission-auto-rejected and end the
  session with zero files written); Wright amended the
  task with the self-delimiting wire format and the
  third session completed — filed as GMSI-152. The
  lane's delivered code did not compile (4 × E0502:
  token issuance used the ctx-borrowed session_id after
  the enclave mutations); Wright's fix (an owned copy
  taken before the pipeline) rides the release,
  disclosed in PR #115 and gate finding F1. While WO-20
  was in verification, WO-DCR shipped as v0.25.0
  (PR #112) and its ledger PR #114 merged; WO-20's
  first PR (#113, as v0.24.0) went stale, was closed
  unmerged, and the WO was rebased onto the new main
  and renumbered v0.26.0 (main.rs three-way merge
  clean; the #114 releases.ts fold-in preserved).
  Wright verification (fresh checkouts, never the
  lane's own run): pre-rebase branch cargo 286/286
  (268 baseline + exactly the 18 WO-20 tests); rebased
  tree cargo 298/298 (188 lib + 93 bin + 11 gm-mcp
  + 6 gm = the 280-test v0.25.0 suite + the 18), WebUI
  ci/build/lint clean, check:releases green
  (28 versions); Wright's own behaviour proof (own
  keypair and vectors) 8/8 legs on both trees
  (exact-action validation + escrow release, replay
  refused, metadata-change action-mismatch,
  trailing-bytes and length-prefix tampers refused,
  expiry boundary valid-at / expired-after,
  wrong-target escrow returns none). Gate (pack
  guardian-mesh-wo20-2026-11-12, verdict + 2026-11-13
  rebase addendum): scanner PASS (0/0/0); cargo audit
  --no-fetch clean (174 deps); verdict PASS WITH
  FINDINGS — F1 the lane compile fix above; F2 (Low)
  issue_token ignores a SysRng failure minting the
  token id, fail-closed direction, noted for a future
  hardening pass; F3 standing GMSI-143 lag outside
  this WO.
  Production v0.26.0 live 2026-11-13: binary sha256
  9c392c78f0423e63360b27b917318a30e419ac954ac41df8d8
  fd0ef2a43bddcc (cross-built from merged main
  7510e30f, cargo-zigbuild 0.23.4 + zig 0.14.1,
  GUARDIAN_MESH_GIT_COMMIT=7510e30f); backup
  .bak-v0250 taken, both services active; box E2E
  15/16 (sole miss the standing stale Health-fields
  harness check, 18th occurrence) — gm-deploy stopped
  at NOT certified on that bar and certification
  proceeded on direct production proof, per standing
  practice. Direct proof (Wright's own box client):
  Health SERVING, 0.26.0@7510e30f, binary sha == built
  == installed, degraded=false, fingerprint == pin
  dd2cf1a3...; self-cert cert-20261113-000055 ACTIVE,
  PASS WITH FINDINGS, evidence = gate verdict sha256
  4a44fffdcb3b4b4030b6e4ebbc6a267af4d0a107bd4a49f7a107
  dd89a828b6a0, its sealed pf_outcomes == the
  production Health counters exactly (9 rules; totals
  1061/1083), payload fingerprint recomputes,
  VerifyProof VALID — superseding cert-20261113-000054.
  Attestation: statement built against the merged
  clone (cross-build Cargo.lock f96da63b...), signed
  on the box with the production key (the key never
  left the box); installed
  /opt/guardian-mesh/guardian-meshd-0.26.0.attestation.json,
  gm-attest verify VALID, signer == pin, package
  fingerprint 21acdd55.... Pages parity: box dist
  asset == merged build == GitHub Pages asset
  (index-CxLoUcEp.js); public unauthenticated 302.
  Main-push CI note: the PR Gate workflow fails on
  push events (identically on c8dd6ab0 and 43804982 —
  it requires a PR context); PR-event checks on the
  merged head were all green, and Rust CI / WebUI CI /
  CodeQL on the merge commit are green. NOT RUN:
  authenticated panel click-through (GMSI-134);
  Kali/Arch for this delta (no new network surface;
  bench lineage proven 2026-11-12); live token
  observation on the production daemon (the shipped gm
  CLI does not surface field 5; issuance is proven
  against the byte-identical binary by the suite +
  Wright's proof harness); cross-process one-time
  enforcement (by design in-memory per checker, stated
  on the face of the docs). v0.26.0 is a RELEASE
  CANDIDATE (one-week soak; graduates 2026-11-20).
  **WO-20 is CLOSED; CM-2 is satisfied, CM-1/CM-3
  stand PARTIAL with named remainders.** Next: WO-32
  (P1, AI risk register + process, docs-only — Wright
  lane acceptable) as the highest-priority unfinished
  work order; WO-27 (P2, mediation conformance)
  follows in pack order; WO-17 stays open for the
  cluster chaos + CM-8 extensions (WO-27); WO-16
  stays open for DC-1/DC-3.

Guardian Mesh Spec Inputs filed by this run: GMSI-146
to GMSI-149 (pre-build pack refresh, from the
2026-11-12 bench-backed gate run) and GMSI-152
(WO-20 gate, self-contained lane tasks), recorded in
Part B above.
- 2026-11-14 (nightly) — **WO-32 SHIPPED as v0.27.0**
  (PR #117, merged 51f71f24; stamped head tree
  cd08c6f5 == the locally verified tree): AI risk
  register + process per ISO/IEC 23894 (compliance
  plan item 1.3). NEW specs/RISK_REGISTER.md: the
  23894-shaped process (context from the threat
  model; identification via the threat model, gate
  GMSI opening a threat entry first; 5x5 anchored
  likelihood x impact; bands Low 1-4 / Medium 5-9 /
  High 10-16 / Critical 17-25; acceptance rule —
  Critical residual blocks unless the product owner
  consciously accepts it in the gate verdict, High
  named in every verdict, acceptance per cycle
  never perpetual; treatments mitigate / accept /
  avoid / transfer-never-claimed) and the register
  itself: RR-01..RR-25, exactly one per TM-01..
  TM-25, scored inherent + residual, owned by one
  accountable role each, tied to the shipped
  mitigations with their honest statuses and the
  closing WO. Residual headline: RR-05 guardian
  bypass 20 Critical (sole Critical); RR-07 / RR-17
  16 High; RR-21 signing-key compromise 15 High
  (the threat model's highest carried risk). Docs-
  only, authored on the Wright lane per the pack
  (laptop online; availability was not the reason);
  no daemon code, no proto, no verdict behaviour.
  specs/THREAT_MODEL.md header + review log updated
  (v0.27.0 row: reviewed, no status changes);
  specs/STANDARDS_COMPLIANCE_REVIEW.md ISO/IEC
  23894 row PARTIAL -> ALIGNED (guidance alignment,
  never certification). Verification (Wright,
  independent, fresh checkout of the pushed branch):
  cargo test 298/298 (188 lib + 93 bin + 11 gm-mcp
  + 6 gm — the v0.26.0 baseline, as a docs-only
  change must produce); WebUI ci + build + lint
  clean, check:releases green (29 versions);
  mechanical acceptance — RR-01..RR-25 each once,
  every TM link valid, all scores arithmetically
  correct, the at-a-glance table consistent on all
  11 High/Critical entries, licence wording exact.
  Gate: PASS WITH FINDINGS (pack guardian-mesh-
  wo32-2026-11-13) — scanner PASS 0/0/0; cargo
  audit clean (174 deps); F1 = standing GMSI-143
  spec-label lag outside this WO. Register review
  recorded in the verdict: RR-04 recorded
  MITIGATED in the v0.26.0 cycle (CM-2 shipped,
  residual 15 High; closes WO-27); RR-05 (20
  Critical) and RR-21 (15 High) CONSCIOUSLY
  ACCEPTED for this cycle by the product owner via
  the verdict, treatments named (WO-21/WO-27;
  WO-23/WO-35), re-acceptance due next cycle —
  the item-1.3 acceptance evidence. SG-1 threat-
  model review performed: no status changes. No
  pack refresh was needed before the build: main
  unchanged since the WO-20 ledger, 0 open PRs /
  issues; the codetopo v0.9.1 soak-watch filed
  2026-11-13 reported no new failure at any level
  and no new GMSI (its GMSI-1..5 were absorbed as
  GMSI-136..139). Production v0.27.0 live
  2026-11-14: binary sha256 fc4534dd11cd9806540f
  ec9c290d495cc8b08cadb4d993157f19cbe21be065ca
  (cross-built from merged main 51f71f24,
  cargo-zigbuild 0.23.4 + zig 0.14.1,
  GUARDIAN_MESH_GIT_COMMIT=51f71f24); backup
  .bak-v0260 taken, both services active; box E2E
  15/16 (sole miss the standing stale Health-fields
  harness check, 19th occurrence) — gm-deploy
  stopped at NOT certified on that bar and
  certification proceeded on direct production
  proof, per standing practice. Direct proof
  (Wright's own box client): Health SERVING,
  0.27.0@51f71f24, binary sha == built ==
  installed, degraded=false, fingerprint == pin
  dd2cf1a3...; self-cert cert-20261114-000056
  ACTIVE, PASS WITH FINDINGS, evidence = gate
  verdict sha256 7b831f18d4bd2e5fb66bc593de3d8120
  fcb08cc5084050b920a5504c69ee4422, its sealed
  pf_outcomes == the production Health counters
  exactly, payload fingerprint recomputes,
  VerifyProof VALID — superseding
  cert-20261113-000055. Attestation: statement
  built against the merged clone (cross-build
  Cargo.lock 20b98366...), signed on the box with
  the production key (the key never left the box;
  signer asserted == pin before install); installed
  /opt/guardian-mesh/guardian-meshd-0.27.0.attestation.json,
  gm-attest verify VALID, signer == pin, package
  fingerprint d85a1dd5.... Pages parity: box dist
  asset == merged build == GitHub Pages asset
  (index-DT_25PVA.js); public unauthenticated 302.
  NOT RUN: authenticated panel click-through
  (GMSI-134); Kali/Arch for this delta (no code or
  network surface changed; bench lineage proven
  2026-11-12); local wire proof against a locally
  built daemon (docs-only; production proof
  exercised the live wire on the shipped binary).
  v0.27.0 is a RELEASE CANDIDATE (one-week soak;
  graduates 2026-11-21). **WO-32 is CLOSED;
  compliance plan item 1.3 is satisfied.** Next:
  WO-37 (P1, touchpoint wiring program — one
  touchpoint per run in map order, T1 first) as
  the highest-priority unfinished work order;
  WO-33 (P2, NIST AI RMF profile, after WO-32) and
  WO-27 (P2, mediation conformance) follow in pack
  order; WO-17 stays open for the cluster chaos +
  CM-8 extensions (WO-27); WO-16 stays open for
  DC-1/DC-3.

Guardian Mesh Spec Inputs filed by this run: GMSI-153
(WO-32 gate — the GMSI-143 reconciliation proof also
covers register accuracy), recorded in Part B above.

- 2026-11-15 — **WO-37 touchpoint T1 (release
  gate) WIRED as v0.28.0** (PR #120, merge
  88ae3e6a; pack refreshed first by PR #119:
  GMSI-154 + GMSI-155 from the Gate Agent v0.1.0
  adjudication). The gm CLI gains the full
  certificate lifecycle over the existing WO-6
  RPCs — `gm certificate issue|status|verify|
  revoke` (issue computes the evidence SHA-256
  itself; refusal writes no file, exit 1; cert
  files share the ProofFile shape `gm verify`
  reads); specs/TOUCHPOINTS.md opens the coverage
  register (T1 WIRED; T4/T5/T8 PARTIAL; T2/T3/
  T6/T7 NAMED NOT WIRED); docs/
  RELEASE_GATE_TOUCHPOINT.md states the operator
  protocol. No daemon/proto/policy/dependency
  changes; no Evaluate call added — the gate's
  own verdict is what issuance binds and
  enforces. Built on the laptop lane (OpenCode
  1.19.5, fresh clone at refreshed main 8af88eaf;
  lane commit tree fc8a44f4 carried by Wright via
  bundle + git-data API after the lane push
  failed on missing credentials — pushed tree ==
  lane tree). Wright verified independently:
  cargo 308/308 (baseline 298 + exactly the 10
  new gm tests), WebUI clean, check:releases 30
  versions; Wright behaviour proof on a locally
  built daemon (own key) 15/15 legs. Gate PASS
  WITH FINDINGS (verdict sha256 a7388343...):
  F1 standing GMSI-143 lag; F2 the effective
  evidence bound is the gRPC transport 4 MB
  limit, below the daemon's 10 MB cap
  (pre-existing, fail-closed) — filed as
  GMSI-156. Register review: no score changes;
  RR-05 (20 Critical) + RR-21 (15 High)
  consciously re-accepted for this cycle,
  treatments unchanged. Deployed: binary sha256
  87449b78..., backup .bak-v0270, both services
  active, box E2E 15/16 (sole miss the standing
  stale Health-fields harness check, 20th
  occurrence) — gm-deploy stopped at NOT
  certified on that bar; certification proceeded
  on direct production proof. Direct proof
  (Wright's own box client): Health SERVING,
  0.28.0@88ae3e6a, binary sha == built ==
  installed, degraded=false, fingerprint == pin
  dd2cf1a3.... Self-cert cert-20261115-000057
  ACTIVE, PASS WITH FINDINGS, evidence = gate
  verdict sha256 a7388343... — the FIRST
  certificate issued through the shipped
  `gm certificate issue` path (gm also installed
  on the box at /usr/local/bin/gm); sealed
  pf_outcomes == production Health counters
  exactly; payload fingerprint recomputes;
  VerifyProof VALID — superseding
  cert-20261114-000056 (read back SUPERSEDED).
  Attestation: statement against the merged
  clone (cross-build Cargo.lock 9fdc1015...),
  signed on the box with the production key
  (signer asserted == pin before install);
  installed /opt/guardian-mesh/
  guardian-meshd-0.28.0.attestation.json,
  gm-attest verify VALID, package fingerprint
  1bcb1fbe.... Pages parity: box dist asset ==
  merged build == GitHub Pages asset
  (index-Bc9gf_U-.js); public unauthenticated
  302. NOT RUN: authenticated panel
  click-through (GMSI-134); Kali/Arch for this
  delta (no daemon or network surface changed).
  v0.28.0 is a RELEASE CANDIDATE (one-week soak;
  graduates 2026-11-22). **WO-37 stays OPEN —
  T1 is wired; the next touchpoint is T2
  (publishing pipeline) in map order.**
  WO-33 (P2, NIST AI RMF profile) and WO-27
  (P2, mediation conformance) follow in pack
  order; WO-17 stays open for the cluster chaos
  + CM-8 extensions (WO-27); WO-16 stays open
  for DC-1/DC-3.

Guardian Mesh Spec Inputs filed by this run: GMSI-156
(WO-37 gate — declared bound == enforced bound,
end-to-end), recorded in Part B above.

- 2026-11-15 — **WO-37 touchpoint T2 (publishing
  pipeline) WIRED as v0.29.0** (PR #123, merge
  3784e68f; pack refreshed first by PR #122:
  GMSI-157..181 intake from the 2026-11-15 atoms
  gate runs, with the duplicate "GMSI-175"
  renumbered GMSI-177 on intake). The daemon's
  default policy gains the PUBLISH rule (allow,
  priority 50; unknown action types still block),
  and the shipped gm CLI gains `publish check` /
  `publish verify`: check reads the content file
  and computes its SHA-256 itself, calls a REAL
  Evaluate (never Simulate) for action type
  PUBLISH with the hash in the action metadata,
  saves the sealed proof and writes a receipt
  pairing proof, content hash, destination and
  channel; exit 0 iff ALLOW, exit 1 on a non-ALLOW
  verdict (receipt still written, naming the
  verdict), exit 2 on usage / session / transport
  / RPC refusal including a pre-proof
  permission_denied, with nothing written. Verify
  re-checks the proof via VerifyProof and, with
  --content-file, recomputes the artifact hash
  against the receipt. specs/TOUCHPOINTS.md marks
  T2 WIRED; docs/PUBLISHING_TOUCHPOINT.md (new)
  states the operator protocol; docs/CLI.md
  documents the subcommand. Verified independently
  by Wright (fresh checkout; lane tree ==
  pushed tree): cargo test 315/315 on the lane
  tree and on the Wright-stamped head (308
  baseline + exactly the lane's 7 new tests);
  WebUI build + lint + check:releases green (31
  versions). Wright carry (disclosed): the
  genesis rule-count expectation in the daemon
  bin tests asserted 11 default rules — the lane
  missed it because the assertion lives in
  main.rs, outside its file list, and its result
  note wrongly reported no such assertion
  existed; Wright fixed it to 12, suite green.
  Wright behaviour proof (own harness, locally
  built daemons, own keys): 17/17 legs — ALLOW
  with the receipt hash == Wright's own SHA-256;
  proof VALID via gm verify and gm publish
  verify; the audit trail carries the
  PUBLISH/ALLOW entry; tampered content and
  tampered proof fail verify; usage errors name
  the flag; dead endpoint writes nothing; an
  escalated PUBLISH returns ESCALATE; a persisted
  bundle denying PUBLISH returns BLOCK. Gate
  verdict PASS WITH FINDINGS (scanner PASS;
  cargo audit clean, 174 deps): F1 = standing
  GMSI-143 lag outside this WO; F2 = the
  genesis-count lane defect (fixed in-run); F3
  = cosmetic BOM / em-dash drift (fixed in the
  Wright stamp). Register review: no score
  changes; RR-05 (20 Critical) + RR-21 (15 High)
  CONSCIOUSLY RE-ACCEPTED for this cycle,
  treatments unchanged; SG-1 review: no status
  changes (no new RPC or network surface).
  Judgment differential in scoped form (identical
  content under ALLOW / ESCALATE / BLOCK through
  the shipped CLI). Deployed: daemon sha256
  96a65784..., backup .bak-v0280, both services
  active; box E2E 15/16 (sole miss = the standing
  stale Health-fields harness check, 21st
  occurrence; certification proceeded on direct
  production proof per standing practice).
  Direct production proof: Health SERVING,
  0.29.0 @ 3784e68f, binary sha == built ==
  installed, degraded=false, fingerprint == pin
  dd2cf1a3.... Self-certification via the shipped
  gm certificate issue: cert-20261116-000059
  ACTIVE (PASS WITH FINDINGS; evidence = the
  WO-37 T2 gate verdict, sha256 311eb785...),
  superseding cert-20261115-000057 (read back
  SUPERSEDED); disclosed: the ceremony's first
  pass issued cert-20261116-000058, superseded
  minutes later by 000059 on the rerun after a
  CLI flag fix — 000059 is the release
  certificate. T2 first exercise: this release's
  own release-log publish checked through the
  shipped gm publish check against production —
  ALLOW, receipt content hash 3bc1b714... (the
  stamped CHANGELOG); gm publish verify valid
  with content_hash_matches=true; Wright's wire
  client independently VerifyProof'd the publish
  proof VALID. One proof nuance recorded: the
  cert's sealed pf_outcomes are the at-issuance
  snapshot; live counters read one higher on the
  action-driven families because the publish
  exercise ran between issuance and the wire
  proof. Attestation: statement against the
  merged clone (cross-build Cargo.lock
  2913a0d1...), signed on the box with the
  production key (signer asserted == pin before
  install); installed /opt/guardian-mesh/
  guardian-meshd-0.29.0.attestation.json,
  gm-attest verify VALID, package fingerprint
  a8a82f26.... gm 0.29.0 installed on the box at
  /usr/local/bin/gm. Pages parity: box dist asset
  == merged build == GitHub Pages asset
  (index-Bt2gqryy.js); public unauthenticated
  302. NOT RUN: authenticated panel click-through
  (GMSI-134); Kali/Arch for this delta (no daemon
  network surface changed); universal assurance
  checks (the repo carries no assurance: gate
  block). v0.29.0 is a RELEASE CANDIDATE (one-week
  soak; graduates 2026-11-22). **WO-37 stays
  OPEN — T2 is wired; the next touchpoint is T3
  (Conduit) in map order.** WO-33 (P2, NIST AI RMF
  profile) and WO-27 (P2, mediation conformance)
  follow in pack order; WO-17 stays open for the
  cluster chaos + CM-8 extensions (WO-27); WO-16
  stays open for DC-1/DC-3.

Guardian Mesh Spec Inputs filed by this run: GMSI-182
(WO-37 T2 gate — content-binding proofs), recorded
in Part B above.
